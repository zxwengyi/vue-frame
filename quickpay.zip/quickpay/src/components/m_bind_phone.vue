<template>
  <!-- 个人中心绑手机号 height: '50%', -->
  <div class="m-bind-phone" v-if="showView">
    <div>
      <v-dialog v-show="showView" :dialog-wrap-style="{left: '13px', right: '13px', width: 'unset'}">
        <div class="dialog-title">
          <div class="text">请验证手机号</div>
          <span class="sch5-icon sch5-tc-guanbi" @click="close"></span>
        </div>
        <div class="dialog-content">
          <m-weixin-phone @next="ok" :btn-disabled="isBind" :code-tips-just-num="true" class="s-wx-phone">
            <img slot="phoneLabel" src="~/assets/img/icon-phone.png" width="22" height="22" style="margin-right:8px;">
            <img slot=codeLabel src="~/assets/img/icon-key.png" width="22" height="22" style="margin-right:8px;">
          </m-weixin-phone>
        </div>
        <!-- <div class="dialog-footer">
          <span class="close" @click="close"></span>
        </div> -->
      </v-dialog>
    </div>
  </div>
</template>

<script>
import MWeixinPhone from '@/components/m_weixin_phone'
import VDialog from '@/components/v_dialog'
import { getSessionStorage, setSessionStorage, setLocalStorage, getLocalStorage, setCache } from 'sa-common'
import * as _api from '@/api/user'
import { handleRedirect, loginSuccess } from '@/utils/common'

export default {
  name: 'm-bind-phone',
  components: {
    VDialog,
    MWeixinPhone
  },
  data() {
    return {
      isBind:false
    }
  },
  props: {
    showView: {
      type: Boolean,
      default() {
        return false
      }
    }
  },
  created() {},
  methods: {
    close() {
      this.$emit('on-close')
    },
    ok(opt) {
      let _this = this
      if(_this.isBind){
        return
      }
      _this.isBind = true
      _api.wxpubApiverifySms({
        wxToken: getLocalStorage('jyToken'),
        phoneNo: opt.username,
        verifyCode: opt.validate
      }).then((res) => {
        if (res.result === '000000') {
          // 注册
          _api.userregister({
            wxToken: getLocalStorage('jyToken'),
            mobilePhone: opt.username
          }).then((res) => {
            if (res.result === '000000') {
              if (res.data && res.data.userId) {
                let userinfo = getLocalStorage('userinfo')
                userinfo.userId = res.data.userId
                setLocalStorage('userinfo', userinfo)
              }
              if (res.data && res.data.glToken) {
                console.log('替换token')
                setCache('wxToken', res.data.glToken)
              }
              _api.info().then((res) => {
                if (res.result === '000000') {
                  setCache('information', res.data)
                  this.$emit('on-close', 1)
                  // location.reload()
                }
              })
            } else {
              if (res.description) {
                this.$toast.show({
                  text: res.description,
                  position: 'center'
                })
              }
              _this.isBind = false
            }
          })
        } else {
          if (res.description) {
            this.$toast.show({
              text: res.description,
              position: 'center'
            })
          }
          _this.isBind = false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.m-bind-phone {
  text-align: center;
}
.dialog-title {
  position: relative;
  background-color: #fff;
  font-size: 18px;
  color: #333;
  padding: 30px 0 0 36px;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
  text-align:left;
  .sch5-tc-guanbi {
    position: absolute;
    font-size: 36px;
    z-index:99;
    right:5px;
    top:5px;
  }
}
.dialog-content {
  padding: 15px 32px 30px 32px;
  overflow: scroll;
  -webkit-overflow-scrolling: touch;
  background-color: #fff;
  border-bottom-left-radius: 18px;
  border-bottom-right-radius: 18px;
}
.dialog-footer {
  padding: 20px 0;
}
.close{
  width: 30px;
  height: 30px;
  display: inline-block;
  background: url(~@/assets/img/icon_close.png) no-repeat;
  background-size: contain;
  margin: 10px auto 0;
}
.dialog-content-wrap {
    left: 13px;
    right: 13px;
    width: unset;
}
</style>


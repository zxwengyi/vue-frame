<template>
  <!-- 个人中心绑定手机号弹窗 -->
  <div class="m-phonevalidate">
    <div class="input-cell m-phone-number">
      <slot name="phoneLabel"></slot>
      <div class="input-wrap">
        <input
          v-model="username"
          maxlength="11"
          keyboard="number"
          :placeholder="showPlaceholder?'请输入手机号' : ''"
          ref="phoneId"
          @blur="onBlurFn"
        />
      </div>
    </div>
    <div class="input-cell m-phone-code">
      <slot name="codeLabel"></slot>
      <div class="input-wrap">
        <input
          v-model="validate"
          :placeholder="showPlaceholder ? '请输入验证码' : ''"
          maxlength="6"
          ref="verifId"
          @blur="onBlurFn"
        />
        <div class="verification-btn" @click="getValidate">{{ sendStateText }}</div>
      </div>
    </div>
      
    <div class="errors">{{ errors }}</div>
    <div @click="validateLogin" class="validateLoginBtn" :class="{'disabled': disabled}">确定</div>
    <div class="tips-barr">
      <v-confirm v-model="show" title="操作提示" @on-cancel="onCancel" @on-confirm="onConfirm">
        <p style="text-align:center;">该手机号已经注册给乐账号，如绑定将会与现有账号进行数据合并，请确定是否绑定</p>
      </v-confirm>
    </div>
  </div>
</template>

<script>
import { getLocalStorage, setLocalStorage } from 'sa-common'
import VConfirm from '@/components/v_confirm'
import * as _api from '@/api/user'

import { setTimeout } from 'timers'
const regMobile = /^[1][1,2,3,4,5,6,7,8,9][0-9]{9}$/
const regValidate = /^[0-9]{4}$/
const ok = '000000'

export default {
  name: 'm-phonevalidate',
  props: {
    type: [String, Number],
    btnDisabled: {
      type: Boolean,
      default() {
        return false
      }
    },
    showPlaceholder: {
      type: Boolean,
      default() {
        return true
      }
    },
    codeTipsJustNum: {
      type: Boolean,
      default() {
        return false
      }
    }
  },
  data() {
    return {
      single: true,
      errors: null,
      show: false,
      username: null,
      validate: null,
      sendVerifyState: false,
      sendStateText: '获取验证码',
      time: 60,
      puzzleText: '请滑动拼图至指定区域',
      pactState: false,
      mPhone: '',
      timeOut: null
    }
  },
  computed: {
    disabled() {
      let bool = true
      let mobile = this.username && this.username.replace(/\s+/g, '')
      if (!this.btnDisabled && regMobile.test(mobile) && this.validate && this.validate.length == 6) {
        bool = false
      }
      return bool
    }
  },
  components: {
    VConfirm,
  },
  methods: {
    /*解决ios虚拟键盘不弹回问题*/
    onBlurFn() {
      let _this = this
      let u = navigator.userAgent
      var iPhone = u.indexOf('iPhone') > -1 && u.indexOf('11_2_6') > -1
      if (this.$client.IOS === true) {
        if (!iPhone) {
          this.$nextTick(() => {
            setTimeout(() => {
              const scrollHeight = document.documentElement.scrollTop || document.body.scrollTop || 0
              window.scrollTo(0, Math.max(scrollHeight - 1, 0))
            }, 100)
          })
        }
      }
    },
    onCancel() {
      console.log('on cancel')
    },
    onConfirm() {
      _api.sendSms({
        phoneNo: this.mPhone,
        businessType: 7
      }).then((res) => {
        if (res.result === ok) {
          this.sendVerifyState = true
          this.settime()
        }
      })
    },
    getValidate() {
      if (this.time > 0 && this.time < 60) {
        return
      }
      this.errors = null
      if (!this.username) {
        this.errors = '手机必填'
        return
      }
      let mobile = this.username.replace(/\s+/g, '')
      if (!regMobile.test(mobile)) {
        this.errors = '手机号格式不正确'
        return
      }
      _api.wxpubApisendSms({
        phoneNo: mobile
      }).then((e) => {
        if (e.result === ok) {
          setLocalStorage('jyToken', e.data.wxToken)
          this.sendVerifyState = true
          this.settime()
        }
      })
    },
    // 倒计时
    settime() {
      if (this.time == 0) {
        this.sendStateText = '获取验证码'
        //this.sendVerifyState = false
        this.time = 60
        clearTimeout(this.timeOut)
      } else {
        this.sendStateText = this.codeTipsJustNum ? this.time + 's' :'重新发送(' + this.time + ')'
        this.time = this.time - 1
        this.timeOut = setTimeout(this.settime, 1000)
      }
    },
    // 校验验证码
    validateLogin() {
      this.errors = null
      if (!this.username) {
        this.errors = '手机必填'
        return
      }
      if (!this.validate) {
        this.errors = '验证码必填'
        return
      }
      let mobile = this.username.replace(/\s+/g, '')
      if (!regMobile.test(mobile)) {
        this.errors = '手机号格式不正确'
        return
      }
      // 如果为注册类型
      if (this.type === 0 && !this.pactState) {
        this.errors = '请查阅协议内容并勾选'
        return
      }
      // 验证码发送成功方可登录
      if (!this.sendVerifyState) {
        this.errors = '请发送验证码'
        return
      }

      let opt = {
        username: mobile,
        validate: this.validate
      }
      this.$emit('next', opt)
    }
  }
}
</script>

<style lang="scss" scoped>
.tips-barr {
  position: relative;
  top: -60%;
  left: 0;
  z-index: 9999;
  .weui-dialog {
    position: fixed;
    display: table;
    z-index: 5000;
    width: 80%;
    max-width: 80vw;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    margin: auto;
    background-color: #fff;
    text-align: center;
    border-radius: 0.8vw;
    overflow: hidden;
  }
}
.input-cell{
  display: flex;
  align-items: center;
  width: 100%;
  // background: #f8f8f8;
  // border-radius: 20px;
  .input-wrap {
    width: 100%;
    height: 40px;
    line-height: 40px;
    align-items: center;
    position: relative;
    border-bottom: solid 1px #eaeaea;
  }
  input{
    flex: 1;
    border: none;
    // background: #f8f8f8;
    // padding: 0 14px;
    font-size: 15px;
    color: #000;
    width: 100%;
    // height: 40px;
    // line-height: 40px;
  }
}
.m-phonevalidate {
  font-size: 12px;
  color: #000;
  .validateLoginBtn {
    background: linear-gradient(270deg, rgba(255, 129, 0, 1) 0%, rgba(255, 175, 92, 1) 100%);
    border-radius: 30px;
    height: 42px;
    line-height: 42px;
    color: #fff;
    font-size: 16px;
    &.disabled{
      opacity: .5;
    }
  }
  .verification-btn {
    width: 84px;
    height: 26px;
    font-size: 14px;
    color: #ff9a40;
    text-align: center;
    line-height: 26px;
    display: inline-block;
    border-radius: 2px;
    margin-right: 4px;
    min-width: 60px;
    text-align: right;
    position: absolute;
    right: 0;
    top: 6px;
  }
  .weui-cell {
    padding-left: 14px;
    padding-right: 0;
    background: #f8f8f8;
    border-radius: 20px;
    opacity: 0.9;
  }
  .m-phone-code {
    margin-top: 15px;
    input{
      min-width: 120px;
    }
  }
  .weui-cell::before {
    left: 0;
  }
  .weui-cell:nth-child(2):after {
    -webkit-transform: scaleY(0.5);
    -webkit-transform-origin: 0 0;
    border-top: 1px solid #d9d9d9;
    color: #d9d9d9;
    content: ' ';
    height: 1px;
    left: 0;
    position: absolute;
    right: 0;
    bottom: 0;
    transform: scaleY(0.5);
    transform-origin: 0 0;
  }
  .errors {
    font-size: 12px;
    color: #ff8100;
    padding: 6px 0 14px 0;
    min-height: 24px;
    line-height: 24px;
    text-align: left;
    padding-left: 14px;
    box-sizing: border-box;
  }
  .pact-box {
    padding: 10px 0;
  }
}
</style>
<style lang="scss">
.verify-wrapper {
  position: fixed !important;
  padding-bottom: 12px;
  font-size: 13px;
  color: #828282;
  background: rgba(255, 255, 255, 0.98);
  z-index: 999;
  position: absolute;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  .verify-box {
    padding: 0 5%;
    .verify-img-panel {
      border: 1px solid #fff;
      background-color: #f5f5f5;
    }
    .verify-bar-area {
      background-color: #f7f9fa;
      border-radius: 2px;
      border: 1px solid #d8d8d8;
      font-size: 13px;
      color: #828282;
      box-sizing: content-box;
      .verify-left-bar {
        top: 0;
        left: 0;
        border: 0;
        .verify-move-block {
          width: 38px !important;
          height: 38px !important;
          background: #fff;
          box-shadow: 1px 1px 2px 1px #dcdcdc;
          border: 1px solid #f7f9fa;
        }
      }
    }
  }
  .verify-btn {
    display: none !important;
  }
}

.m-phonevalidate {
  .weui-cells_checkbox:before {
    height: 0 !important;
    border: 0 !important;
  }
  .weui-check_label {
    font-size: 11px;
    color: #828282;
    padding-left: 0 !important;
  }
}
</style>
<style lang="scss">
.s-wx-phone {
  &.m-phonevaladate {
    .input-cell {
      height: 42px;
      line-height: 42px;
      background: #fff;
      input{
        height:42px;
        line-height: 42px;
      }
    }
  }
}
</style>
<template>
  <!-- 支付方式 -->
  <div class="m-pay-method">

    <!-- 畅由分支付 -->
    <div class="s-row bean-pay" v-if="showBeanPay && isCyuUser">
      <div class="surplus">
        <img class="i-changyou fl" src="~/assets/img/changyoyoLogo.png" alt="" />
        <div class="fl">
          <p>畅由分支付（余额：{{_multiplicationFn(ledouBalance, 100) || 0}}畅由分）</p>
          <slot name="deductTips">
            <p class="tip" slot="deductTips">100畅由分价值1元，</p>
          </slot>
        </div>
      </div>
      <v-switch :value="switchVal" class="vswitch" :handle="true" :disabled="cardSwitchVal" @changeSwitch="switchChange"></v-switch>
    </div>

    <!-- 乐豆支付 -->
    <div class="s-row bean-pay" v-if="showBeanPay && !isCyuUser">
      <div class="surplus">
        <img class="i-geile fl" src="~/assets/img/icon_geile@2x.png" alt="" />
        <div class="fl">
          <p>乐豆支付（余额：{{ledouBalance || 0}}乐豆）</p>
          <slot name="deductTips">
            <p class="tip" slot="deductTips">1乐豆价值1元</p>
          </slot>
        </div>
      </div>
      <v-switch :value="switchVal" class="vswitch" :handle="true" :disabled="cardSwitchVal" @changeSwitch="switchChange"></v-switch>
    </div>

    <!-- 储蓄卡支付 -->
    <div class="s-row card-pay" v-if="showCardPay">
      <div class="surplus">
        <img class="i-card fl" src="~/assets/img/icon_card@2x.png" alt="">
        <div class="fl">
          <p>储值卡支付（余额：{{cardBalance || 0}}元）</p>
          <slot name="recharge"></slot>
        </div>
      </div>

      <v-switch :value="cardSwitchVal" class="vswitch" :handle="true" :disabled="switchVal" @changeSwitch="cardSwitchChange"></v-switch>
    </div>

    <div class="cash-pay">钱包支付</div>

    <!-- 微信支付 -->
    <div class="s-row wx-pay" @click="changeType(1)" v-if="!$client.ALIPAY && !$client.UnionPay">
      <div class="left">
        <span class="sch5-icon sch5-weixin"></span>微信支付
      </div>
      <div class="check-wrap" :class="{active: !cardSwitch && type == 1}">
        <i class="i-circle"></i>
        <i class="i-checked"></i>
      </div>
    </div>

    <!-- 支付宝支付 -->
    <div class="s-row ali-pay" @click="changeType(2)" v-if="!$client.WEIXIN && !$client.UnionPay">
      <div class="left">
        <span class="sch5-icon sch5-alipay"></span>支付宝支付
      </div>
      <div class="check-wrap" :class="{active: !cardSwitch && type == 2}">
        <i class="i-circle"></i>
        <i class="i-checked"></i>
      </div>
    </div>

    <!-- 银联云闪付 -->
    <div class="s-row ysf-pay" @click="changeType(3)" v-if="$client.UnionPay">
      <div class="left">
        <span class="sch5-icon sch5-ysf"></span>银联云闪付
      </div>
      <div class="check-wrap" :class="{active: !cardSwitch && type == 3}">
        <i class="i-circle"></i>
        <i class="i-checked"></i>
      </div>
    </div>
  </div>
</template>
<script>
import VSwitch from '@/components/v_switch'
export default {
  name: 'mPayMethod',
  components: {
    VSwitch
  },
  props: {
    ledouBalance: [Number, String], // 乐豆余额
    cardBalance: [Number, String], // 储值卡余额
    switchValue: { // 乐豆开关状态
      type: Boolean,
      default() {
        return true
      }
    },
    cardSwitch: { // 储值卡开关状态
      type: Boolean,
      default() {
        return false
      }
    },
    payMethod: { // 1|微信 2|支付宝
      type: Number,
      default() {
        return 1
      }
    },
    showBeanPay: { // 是否显示乐豆支付
      type: Boolean,
      default() {
        return true
      }
    },
    showCardPay: {
      type: Boolean,
      default() {
        return false
      }
    },
    isCyuUser: [Boolean, Number] // 是否为联合用户
  },
  data() {
    return {
      cardSwitchVal: false, // 储蓄卡支付开关
      switchVal: false, // 乐豆开关
      type: this.payMethod || 1 // 支付方式
    }
  },
  watch: {
    cardSwitch(val) {
      this.cardSwitchVal = val
    },
    switchValue(val) {
      this.switchVal = val
    },
    payMethod(val) {
      this.type = val
    }
  },
  methods: {
    switchChange(val) { // 乐豆开关
      this.$emit('switch-change', val)
    },
    cardSwitchChange(val) {
      this.$emit('switch-card', val)
    },
    changeType(val) { // 支付方式修改
      if (!this.cardSwitchVal) {
        this.type = val
        this.$emit('paymethod-change', val)
      }
    },
    // closeExchange(type) {
    //   this.$emit('close-exchange', type)
    // },
    // bindPhoneSuccess() {
    //   this.$emit('bind-phone-success') // 绑定手机成功,需要重新请求获取乐豆余额
    // }
  }
}
</script>
<style lang="scss" scoped>
// 支付方式
.m-pay-method{
  font-size: 14px;
  padding: 0 15px;
  background: #fff;
  p{
    margin: 0;
  }
  .fl{
    float: left;
  }
  .bor-top{
    border-top:solid 1px #eee;
  }
  .s-row{
    display: flex;
    background: #fff;
    padding: 15px 0;
    .right{
      flex: 1;
      text-align: right;
    }
  }
  .bean-pay{
    padding: 10px 0;
  }
  .card-pay{
    padding: 12px 0;
    align-items: center;
    border-top: solid 1px #eee;
    border-bottom: solid 1px #eee;
    .i-card{
      width: 20px;
      height: 14px;
      margin-top: 6px;
      margin-right: 12px;
    }
  }
  .i-geile, .i-alipay, .i-changyou{
    width: 20px;
    height: 20px;
    margin-right: 12px;
  }
  .tip{
    font-size: 12px;
    color: #ff6a00;
  }
  .sch5-weixin{
    font-size: 20px;
    vertical-align: middle;
    margin-right: 8px;
    display: inline-block;
    width: 20px;
    height: 20px;
    background: url(~@/assets/img/icon_wechat@2x.png) no-repeat;
    background-size: contain;
    vertical-align: middle;
  }
  .sch5-alipay{
    display: inline-block;
    width: 20px;
    height: 20px;
    background: url(~@/assets/img/icon_zhifubao@2x.png) no-repeat;
    background-size: contain;
    vertical-align: middle;
    margin-right: 8px;
  }
  .sch5-ysf{
    display: inline-block;
    width: 20px;
    height: 20px;
    background: url(~@/assets/img/ysf_unionpay.png) no-repeat;
    background-size: contain;
    vertical-align: middle;
    margin-right: 8px;
  }
  .cash-pay{
    padding-top: 4px;
  }
  // 剩余乐豆
  .surplus{
    flex: 1;
  }
  .btn-switch{
    &:checked {
      border-color: #ff6a00;
      background-color: #ff6a00;
    }
  }
  .check-wrap{
    position: relative;
    .i-radio{
      display: none;
      font-size: 20px;
      position: absolute;
      top: 4px;
      right: 0px;
      &.weui-icon-success{
        color: #ff6a00;
        &:before{
          margin: 0;
        }
      }
    }
    .i-checked{
      width: 20px;
      height: 20px;
      display: none;
      font-size: 20px;
      position: absolute;
      background: url('~assets/img/checked.png');
      background-repeat: no-repeat;
      background-size: contain;
      top: 2px;
      right: 0px;
    }
    .i-circle{
      width: 18px;
      height: 18px;
      border-radius: 50%;
      display: inline-block;
      background: #EFF0F5;
      border: solid 1px #E3E3E3;
      position: absolute;
      top: 2px;
      right: 0px;
    }
    &.active{
      .i-checked{
        display: inline-block;
      }
      .i-circle{
        display: none;
      }
    }
  }
  .left{
    flex: 1;
  }
}
</style>

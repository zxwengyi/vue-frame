<template>
  <div class="input-money">
    <NumericInput
					:placeholder="placeholder"
					:layout="layoutKeyboard"
					:maxlength="maxlength"
					:autofocus="autofocus"
          :decimals="2"
          :name="name"
					v-model="inputValue"
					entertext="确认"
          @enterpress="enterPress"
          @blur="blur"/>
  </div>
</template>

<script>

import { NumericInput, Keys as keys } from 'numeric-keyboard'

const layoutKeyboard = [
  [
    {
      key: keys.ONE
    },
    {
      key: keys.TWO
    },
    {
      key: keys.THREE
    },
    {
      key: keys.DEL,
      rowspan: 1,
    },
  ],
  [
    {
      key: keys.FOUR
    },
    {
      key: keys.FIVE
    },
    {
      key: keys.SIX
    },
    {
      key: keys.ENTER,
      rowspan: 3,
    },
  ],
  [
    {
      key: keys.SEVEN
    },
    {
      key: keys.EIGHT
    },
    {
      key: keys.NINE
    },
  ],
  [
   {
      key: keys.ESC
    },
    {
      key: keys.ZERO
    },
    {
      key: keys.DOT
    },
  ],
]
export default {
  name: 'numericKeyboard',
  components: {
    NumericInput
  },
  props: {
    value: {
      type: [String, Number],
      default: ''
    },
    autofocus: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: '请输入消费金额'
    },
    maxlength: {
      type: Number,
      default: 6
    },
    name: String
  },
  data() {
    return {
      layoutKeyboard,
      inputValue: this.value
    }
  },
  watch: {
    inputValue(newValue) {
      // todo:控制长度不生效
      newValue = newValue.toString()
      //  if (newValue.split('.')[0].length >= this.maxlength) {
      //     this.inputValue = newValue.substr(0, this.maxlength);
      //  }
      this.$emit('change', this.inputValue)
    },
    value(newValue) {
      this.inputValue = newValue
    }
  },
  methods: {
    enterPress() {
      this.$emit('press', this.inputValue)
    },
    blur() {
      this.$emit('blur')
    }
  }
}
</script>

<style lang="scss">
.numeric-input-cursor {
  // left: auto;
  // right: 0;
}
.numeric-input-placeholder {
  white-space: nowrap;
  font-size:20px;
  font-family:Verdana;
  font-weight:400;
  line-height:24px;
  color:rgba(204,204,204,1);
}
.numeric-input {
  width: 100%;
  height: 54px;
  border:2px solid rgba(253,107,0,1);
  border-radius:10px;
  padding-right: 18px;
  font-size: 22px;
  text-align: right;
  box-sizing: border-box;
  color: #fe6900;
  outline: none;
  &>div {
    display: flex;
    align-items: center;
  }
}
.numeric-keyboard-key {
  font-size:18px;
  font-family:Verdana;
  font-weight:400;
  color:rgba(102,102,102,1);
}
.numeric-keyboard-key[data-key=enter] {
  background: linear-gradient(270deg,#ff8f40,#ffbd40);
}
</style>

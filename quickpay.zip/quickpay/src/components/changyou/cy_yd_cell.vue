<template>
  <!-- 收银台 移动 积分当钱花 -->
  <div class="cy-yd-cell">
    <div class="s-row yd-row">
      <div class="left">
        <img class="i-yidong fl" src="~/assets/img/ydLogo.png" alt="">
        <div class="fl">
          <p>中国移动</p>
          <p v-show="!isCYUnionUSer" class="cy-ld-tips">100畅由分 = 1乐豆</p>
        </div>
      </div>
      <div class="yd-tips" @click="onClick">积分当钱花</div>
    </div>
    <!-- 绑定手机号 -->
    <m-bind-phone :show-view="showBindPopup" @on-close="bindPopupClose"></m-bind-phone>

    <!-- 畅由账户首次使用授权弹窗 -->
    <cy-first-auth ref="cyFirstAuth" :on-show="showAuthPopup" :cy-info="cyInfo" :ledou-balance="ledouBalance" @close-auth="showAuthPopup = false" @bind-success="bindSuccessFn"></cy-first-auth>

    <!-- 畅由分兑换弹窗 -->
    <cy-exchange :on-show="showExchangePopup" :cy-info="cyInfo" @close-exchange="closeExchange"></cy-exchange>
  </div>
</template>

<script>
import MBindPhone from '@/components/m_bind_phone'
import CyFirstAuth from '@/components/changyou/cy_first_auth'
import CyExchange from '@/components/changyou/cy_exchange'
import { queryCmccPoints, notifyCyUserBind, beanAmount } from '@/api/changyou'
import { returnCyRegisterLink } from '@/utils/common'
import { getCache } from 'sa-common'
import { saBs } from '@/utils/base'
// import { mapState, mapMutations } from 'vuex'
export default {
  name: 'cy-yd-cell',
  components: {
    MBindPhone,
    CyFirstAuth,
    CyExchange
  },
  props: {
    isLogined: Boolean,
    cyinfoReflash: Number,
    // ledouBalance: {
    //    type: [Number, String],
    //    default() {
    //      return 0
    //    }
    // }
  },
  data() {
    return {
      cyRequestError: false, // 请求畅由接口报错
      cyInfo: {},
      isCYUnionUSer: false, // 是否是联合用户
      showBindPopup: false, // 显示绑定手机弹窗
      showAuthPopup: false, // 显示首次授权弹窗
      showExchangePopup: false, // 显示畅由分兑换弹窗
      ledouBalance: '', // 纯乐豆余额
    }
  },
  watch: {
    cyinfoReflash() { // cyinfo 刷新 收银台底部绑定手机入口绑定成功后，如果是联合用户刷新数据
      this.queryCyInfo()
    },
    isLogined() {
      let _this = this
      this.queryCyInfo(res => {
        if (_this.$route.fullPath.indexOf('cyregister=1') > -1) { // 移动注册绑定完跳转回收银台  
          if (res.result && res.result != '000000') { // 接口异常
            if (res.description) {
              _this.$toast.show({
                text: res.description,
                position: 'center'
              })
            }
            return
          }
          if (res.isConection === 'true') { // 账户已关联畅由
            notifyCyUserBind().then(() => {}) // 通知后端绑定畅由会员成功
          }
          if (res.isBingding == 1) { // 用户已绑定移动,弹出积分兑换弹窗
            _this.showExchangePopup = true
          } else if (res.isBingding == 2) { // 被冻结需要用户先去移动解绑
            // _this.$toast.show({
            //   text: '您的手机号被移动冻结，请到畅由APP进行激活后再试',
            //   position: 'center'
            // })
          } else if (res.isBingding == 4) { // 查询移动状态失败
            _this.$toast.show({
              text: '您的手机号状态，查询失败请稍后再试',
              position: 'center'
            })
          }
        }
      }, 1)
      this.getBeanAmount()
    },
    showBindPopup(val) {
      this.popupWatch(val)
    },
    showAuthPopup(val) {
      this.popupWatch(val)
    },
    showExchangePopup(val) {
      this.popupWatch(val)
    }
  },
  created() {
    // let _this = this
    // if (this.$route.fullPath.indexOf('cyregister=1') > -1) { // 移动注册绑定完跳转回收银台，弹出积分兑换弹窗&&通知后端绑定畅由会员成功   
    //   this.$nextTick(() => {
    //     let returnStr = this.$route.query.cyrReturn
    //     if (returnStr && returnStr.indexOf('response=') > -1) {
    //       let strArr = returnStr.split('response=')
    //       let obj = strArr[1] ? JSON.parse(strArr[1]) : {}
    //       if (obj.resultCode == '0000') {
    //         _this.showExchangePopup = true
    //         notifyCyUserBind().then(() => {})
    //       }
    //     }
    //   })
    // }
    // this.queryCyInfo(null, 1)
  },
  // computed: {
  //   ...mapState(['isCYUnionUSer'])
  // },
  methods: {
    bindSuccessFn() { // 移动绑定成功
      this.queryCyInfo((res) => {
        if (res.isBingding == 1) {
          this.$emit('bind-phone-success', 1) // 为了刷新收银台的数据
          this.showAuthPopup = false;
          this.showExchangePopup = true;
        } else if (res.isBingding == 4) {
          this.$toast.show({
            text: '您的手机号状态，查询失败请稍后再试',
            position: 'center'
          })
        }
      });
    },
    popupWatch(type) { // 监听弹窗是否弹出
      this.$emit('popup-watch', type)
    },
    getBeanAmount(fn) { // 获取纯乐豆余额
      this.bus.$emit('loading', true)
      beanAmount().then(res => {
        this.bus.$emit('loading', false)
        if (res.result === '000000') {
          this.ledouBalance = res.data || 0
          fn && fn(res)
        }
      })
    },
    queryCyInfo(fn, type) { // 查询移动积分,畅由积分,兑换比例,是否已绑定移动,是否已关联畅由 type: 1|初始化数据 如果接口报错不提示（防止畅由接口出问题初始化报错）
      let info = getCache('information') || {}
      let queryBind = getCache('queryBindData') || {}
      if (info.mobilePhone || queryBind.mobilePhone) {
        this.bus.$emit('loading', true)
        queryCmccPoints().then(res => {
          if (!type) this.bus.$emit('loading', false)
          if (res.result == '000000') {
            this.cyRequestError = false
            this.cyInfo = res.data
            this.isCYUnionUSer = res.data && res.data.isConection === 'true'
            this.cyInfo.mobilePhone = info.mobilePhone
            fn && fn(res.data)
          } else {
            if (type) fn && fn(res)
            this.cyRequestError = true
            if (!type && res.description) {
              this.$toast.show({
                text: res.description,
                position: 'center'
              })
            }
          }
        })
      }
    },
    onClick() { // 点击积分当钱花
      if (this.cyRequestError || this.cyInfo.isBingding == 4) { // 畅由请求报错，重新请求数据
        let _this = this
        this.queryCyInfo(res => {
          if (res.isBingding != 4) {
            _this.onClick()
          } else {
            _this.$toast.show({
              text: '您的手机号状态，查询失败请稍后再试',
              position: 'center'
            })
          }
        })
        return
      }
      if (this.isCYUnionUSer) { // 联合用户
        if (this.cyInfo.isBingding == 1) { // 用户是否已绑定移动
          this.showExchangePopup = true // 弹出兑换积分弹窗
        } else if (this.cyInfo.isBingding == 4) { // 查询移动状态失败
          this.$toast.show({
            text: '您的手机号状态，查询失败请稍后再试',
            position: 'center'
          })
        } else if (this.cyInfo.isBingding !== undefined) {
          let link = returnCyRegisterLink(this, this.ledouBalance)
          location.href = link
        } else {
          this.queryCyInfo()
        }
      } else { // 普通用户
        let info = getCache('information') || {}
        let queryBind = getCache ('queryBindData') || {}
        if (info.mobilePhone && queryBind.bind) { // 已绑定手机号
          if (info.cyProtocolFlag != 1) { // cyProtocolFlag：用户是否已接受畅由用户协议（首次授权）  0|未授权 1|已授权
            this.showAuthPopup = true // 未授权过，弹出首次授权弹窗
          } else { // 已授权过，调cyFirstAuth组件中checkUser方法，是畅由用户调关联接口，不是畅由用户跳转至畅由注册页
            this.$refs.cyFirstAuth.checkUser()
          }
        } else {
          this.showBindPopup = true// 绑定手机号
        }
      }
    },
    closeExchange(type) { // 关闭积分兑换弹窗 type 1|兑换积分成功
      this.showExchangePopup = false
      this.$emit('close-exchange', type)
      if (type) this.queryCyInfo()
    },
    bindPopupClose(type) { // 关闭绑定手机弹窗 type 1|手机绑定成功
      this.showBindPopup = false
      let _this = this
      if (type == 1) {
        this.queryCyInfo((res) => {
          _this.getBeanAmount(() => { // 重新获取用户乐豆余额
            if (res.isConection !== 'true') { // 不是畅由用户
              _this.showAuthPopup = true // 弹出首次授权弹窗
            } else { // 是畅由用户 确认是否已绑定移动，已绑定移动弹出积分兑换弹出，未绑定跳转链接去绑定
              this.$refs.cyFirstAuth.checkUser()
            }
            _this.$emit('bind-phone-success', res.isConection === 'true') // 绑定手机成功,需要重新请求获取乐豆余额,并刷新成联合用户样式
          })
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.cy-yd-cell {
  font-size: 14px;
  background: #fff;
  padding: 0 15px;
  .fl{
    float: left;
  }
  .s-row{
    display: flex;
    background: #fff;
    padding: 15px 0;
    .left {
      flex: 1;
      p{
        margin: 0;
      }
    }
    .i-yidong {
      width: 20px;
      height: 20px;
      margin-right: 12px;
      position: relative;
    }
  }
  .cy-ld-tips {
    font-size: 12px;
  }
  .yd-row {
    padding: 12px 0;
    align-items: center;
    border-bottom: 1px solid #eee;
    .yd-tips{
      background: #D3302B;
      border-radius:4px;
      padding: 3px 9px;
      color: #fff;
    }
  }
}
</style>


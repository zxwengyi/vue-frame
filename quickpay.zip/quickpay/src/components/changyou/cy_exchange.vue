<template>
  <!-- 畅由分兑换弹窗 -->
  <div class="cy-exchange">
    <div>
      <v-dialog
        class="x-dialog"
        v-show="onShow"
        :dialog-wrap-style="{ borderRadius:'15px', 'max-width': 'unset', width: '88%', background: '#fff'}"
      >
        <span class="sch5-icon sch5-tc-guanbi" @click="onClose"></span>
        <!-- 移动积分信息 -->
        <div class="cy-exchange-content" v-show="currentStep === 1">
          <div class="integral-info">
            <div>您当前有<span class="s-ydf">{{cyInfo.cmccPoints || 0}}</span> 移动积分</div>
            <div>单笔最高可使用19920移动积分</div>
            <div class="s-proportion">（兑换比例：{{cyInfo.cyExchangeRate}}）</div>
          </div>
          <div class="need-tips">使用移动积分:</div>
          <div class="m-input">
            <a @click="sub" class="vux-number-selector-sub" :class="{usable: subUsable}"></a>
            <numeric-keyboard
              name="exchange-input"
              v-if="reflashInput"
              placeholder=""
              :autofocus="false"
              v-model="number"
              @change="numberChange"
              @blur="numberBlur"
            />
            <a @click="add" class="vux-number-selector-plus" :class="{usable: addUsable}"></a>
          </div>
          <div class="error-tips" :style="{visibility: errorTips != '--' ? 'visible' : 'hidden'}">{{errorTips}}</div>
          <div>获得畅由分：{{consume}}<span v-show="consume != '--'">（价值{{consume != '--' ? consume/100 : ''}}元）</span></div>
          <div class="m-button" :class="{disabled: consume == '--'}" @click="stepOneConfirm">确定</div>
        </div>

        <!-- 短信验证 -->
        <div class="cy-verify-content" v-show="currentStep === 2">
          <div>已发送验证码至</div>
          <div class="input-cell">
            <img src="~/assets/img/icon-phone.png" width="22" height="22" style="margin-right:8px;">
            <div class="cmcc-mobile">{{cmccMobile}}</div>
          </div>
          <div class="m-verify">
            <img src="~/assets/img/icon-key.png" width="22" height="22" style="margin-right:8px;">
            <input v-model="smsCode" placeholder="请输入验证码" maxlength="6"  @blur="onBlurFn"/><span class="right" @click="sendMsg">{{sendStateText}}</span>
          </div>
          <div class="m-button" :class="{disabled: smsCode.length != 6}" @click="stepTwoConfirm">确定</div>
        </div>
      </v-dialog>
    </div>
  </div>
</template>

<script>
import NumericKeyboard from '@/components/numeric-keyboard'
import VDialog from '@/components/v_dialog'
// import { XDialog, TransferDomDirective as TransferDom } from 'vux'
import { cmccSmsOrder, sendCmccSms, addPoints } from '@/api/changyou'
import { getCache } from 'sa-common'

export default {
  name: 'cy-exchange',
  // directives: {
  //   TransferDom
  // },
  components: {
    NumericKeyboard,
    VDialog
    // XDialog,
  },
  props: {
    onShow: { // 畅由分兑换弹窗显示
      type: Boolean,
      default() {
        return false
      }
    },
    cyInfo: {
      type: Object,
      default() {
        return {
          points: '', // 用户畅游分
          cmccPoints: '', // 用户移动积分
          cyExchangeRate: '', // 畅游兑换比例
          isBingding: '', // 用户是否已绑定移动 0|未绑定，1|正常，2|被冻结需要用户先去移动解，3| 解除绑定，4|查询移动状态失败
          isConection: '' // 用户是否已关联畅由
        }
      }
    },
  },
  data() {
    return {
      reflashInput: true,
      currentStep: 1,
      number: 0,
      sendStateText: '获取验证码',
      timeOut: null,
      time: 60,
      phoneNumber: '',
      orderId: '', // 兑换订单号
      smsCode: '', // 短信验证码
      // convertible: '', // 可兑换畅由分
      consume: '--', // 消耗移动积分
      ydRate: '', // 移动比例
      cyRate: '', // 畅由比例
      cmccMobile: '', // 兑换扣除移动积分的手机号
      addUsable: false, // 加号可点击
      subUsable: false, // 减号可点击
      errorTips: '--',
      errTime: ''
    }
  },
  watch: {
    onShow() {
      this.currentStep = 1
      this.number = 0
      this.smsCode = ''
      this.consume = '--'
    },
    cyInfo(val) {
      let rate = val.cyExchangeRate || ''
      if (rate.indexOf(':')> -1) {
        let arr = rate.split(':')
        this.ydRate = parseFloat(arr[0])
        this.cyRate = parseFloat(arr[1])
        // this.convertible = this._multiplicationFn(parseInt(this.cyInfo.cmccPoints/this.ydRate), this.cyRate)
      }
      if (val.cmccPoints) this.btnStatusCompute()
    },
    errorTips(val) {
      clearTimeout(this.errTime)
      if (val != '--') {
        let _this = this
        this.errTime = setTimeout(() => {
          _this.errorTips = '--'
        }, 2000)
      }
    }
  },
  created() {
    let info = getCache('information') || {}
    let queryBind = getCache('queryBindData') || {}
    this.phoneNumber = info.mobilePhone || queryBind.mobilePhone
  },
  methods: {
    /*解决ios虚拟键盘不弹回问题*/
    onBlurFn() {
      let _this = this
      let u = navigator.userAgent
      var iPhone = u.indexOf('iPhone') > -1 && u.indexOf('11_2_6') > -1
      if (this.$client.IOS === true) {
        if (!iPhone) {
          this.$nextTick(() => {
            setTimeout(() => {
              const scrollHeight = document.documentElement.scrollTop || document.body.scrollTop || 0
              window.scrollTo(0, Math.max(scrollHeight - 1, 0))
            }, 100)
          })
        }
      }
    },
    btnStatusCompute() { // 加减号按钮状态计算
      let sublastNum = this._subtractionFn(this.number, this.ydRate)
      let addlastNum = this._additionFn(this.number, this.ydRate)
      let max = parseFloat(this.cyInfo.cmccPoints)
      if (max > 19920) max = 19920
      let isMultiple = this.number ? parseFloat(this.number) % 120 == 0 : true
      if (sublastNum > 0 && isMultiple) {
        this.subUsable = true
      } else {
        this.subUsable = false
      }
      if (addlastNum <= max && isMultiple) {
        this.addUsable = true
      } else {
        this.addUsable = false
      }
    },
    computeCyf(num, type) { // type 默认转换成畅由分 1|转换成人民币价值
      let str = ''
      str = this._multiplicationFn(parseInt(num/this.ydRate), this.cyRate)
      if (type) str = str/100
      return str
    },
    numberBlur(){ // 输入框失去焦点
      this.numberVaildate()
      this.consume = this.computeCyf(this.number) || '--'
      this.btnStatusCompute()
    },
    numberChange(val) {
      this.number = val
    },
    numberVaildate(number) { // 兑换数值校验
      let num = number || this.number
      let max = this._multiplicationFn(parseInt(this.cyInfo.cmccPoints/this.ydRate), this.ydRate) // 当前用户最多可兑换移动分
      num = parseFloat(num)
      if (num) {
        if (num > 19920 && parseFloat(this.cyInfo.cmccPoints) >= 19920) {
          // 移动单次兑换不超过20000移动分，所以做多能对19920移动分
          this.errorTips = '本次最高可兑换19920'
          this.number = 19920
          this.reflashInputFn()
        } else if (num > max) { // 输入框兑换值大于可兑换移动分
          this.errorTips = '您的移动积分不足'
          this.number = max
          this.reflashInputFn()
        } else if (parseFloat(num) % 120 != 0) { // 输入框兑换值不是120的倍数
          this.errorTips = '只能输入120的整数倍'
          let ableNum = this._multiplicationFn(parseInt(num/this.ydRate), this.ydRate)
          let lastNum = this._additionFn(ableNum, this.ydRate)
          if (lastNum <= max) {
            this.number = lastNum
          } else if (ableNum <= max) {
            this.number = ableNum
          } else {
            this.number = max
          }
          this.reflashInputFn()
        }
      }
    },
    onClose() { // 关闭弹窗
      this.$emit('close-exchange', 0)
    },
    stepOneConfirm() { // 积分兑换下单，并发送短信验证码
      if (this.consume == '--') return
      if (this.number) {
        this.bus.$emit('loading', true)
        // 移动兑换下单
        cmccSmsOrder({
          mobile: this.phoneNumber,
          points: String(this.number) // 扣减移动积分
        }).then(res => {
          this.bus.$emit('loading', false)
          if (res.result === '000000') {
            this.cmccMobile = res.data && res.data.cmccMobile
            this.orderId = res.data.orderId
            this.currentStep = 2
            this.time = 60
            this.settime()
          } else {
            if (res.description) {
              this.$toast.show({
                text: res.description,
                position: 'center'
              })
            }
          }
        })
      }
    },
    stepTwoConfirm() { // 验证兑换验证码
      if (this.smsCode) {
        this.bus.$emit('loading', true)
        addPoints({
          orderId: this.orderId,
          smsCode: this.smsCode
        }).then(res => {
          this.bus.$emit('loading', false)
          if (res.result === '000000') {
            this.$emit('close-exchange', 1)
          } else {
            if (res.description) {
              this.$toast.show({
                text: res.description,
                position: 'center'
              })
            }
          }
        })
      }
    },
    add () { // 加号计算
      if (!this.addUsable) {
        return
      }
      let num = this._additionFn(this.number, this.ydRate)
      if (parseFloat(this.number || 0) < parseFloat(this.cyInfo.cmccPoints)) {
        this.errorTips = '--'
        this.number = num
        this.consume = this.computeCyf(num)
        this.reflashInputFn()
      }
    },
    sub () { // 减号计算
      if (!this.subUsable) {
        return
      }
      let num = this._subtractionFn(this.number, this.ydRate)
      if (this.number && (num) >= 0) {
        this.errorTips = '--'
        this.number = num
        this.consume = this.computeCyf(num) || '--'
        this.reflashInputFn()
      }
    },
    reflashInputFn() { // 刷新数据（如果不做这一步，在点加减号时，数字有可能会不刷新）
      this.btnStatusCompute()
      this.reflashInput = false
      let _this = this
      this.$nextTick(() => {
        _this.reflashInput = true
      })
    },
    sendMsg() {
      // 重新发送移动短信验证码
      if (this.sendStateText === '获取验证码') {
        sendCmccSms({
          orderId: this.orderId
        }).then(res => {
          this.bus.$emit('loading', false)
          if (res.result === '000000') {
            this.settime()
            if (flag === 1) this.currentStep = 2
          } else {
            if (res.description) {
              this.$toast.show({
                text: res.description,
                position: 'center'
              })
            }
          }
        })
      }
    },
    // 倒计时
    settime() {
      if (this.time == 0) {
        this.sendStateText = '获取验证码'
        this.time = 60
        clearTimeout(this.timeOut)
      } else {
        this.sendStateText = this.time + 's'
        this.time = this.time - 1
        this.timeOut = setTimeout(this.settime, 1000)
      }
    },
  }
}
</script>

<style lang="scss" scoped>
  .sch5-tc-guanbi {
    position: absolute;
    font-size: 36px;
    z-index: 99;
    right: 5px;
    top: 5px;
  }
  .cy-exchange-content {
    padding: 25px 40px;
    text-align: left;
    font-size: 14px;
    color: #333;
    .integral-info {
      text-align: center;
      margin-bottom: 20px;
    }
    
    .s-ydf{
      font-size: 28px;
    }
    .s-cyf {
      color: #D3302B;
    }
    .s-proportion {
      color: #707070;
      padding-top: 3px;
    }
    .m-input {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 20px;
      // input{
      //   width: 116px;
      //   height: 44px;
      //   background: #f0f0f0;
      //   border-radius: 22px;
      //   border: unset;
      //   text-align: right;
      //   padding: 0 18px;
      //   font-size: 20px;
      //   margin: 0 14px;
      // }
      // .vux-number-selector{
      //   // float: left;
      //   display: inline-block;
      //   height: 30px;
      //   font-size: 25px;
      //   line-height: 30px;
      //   border-radius: 15px;
      //   border: solid 1px #ccc;
      //   width: 30px;
      //   text-align: center;
      //   padding: 0;
      //   svg {
      //     fill: #ccc;
      //     // position: relative;
      //     // top: 1px;
      //   }
      // }
      
      .vux-number-selector-sub {
        width: 32px;
        height: 32px;
        display: inline-block;
        background-size: contain;
        background-image: url('~@/assets/img/icon_minus_gary@2x.png');
        &.usable{
          background-image: url('~@/assets/img/icon_minus@2x.png');
        }
      }
      .vux-number-selector-plus {
        width: 32px;
        height: 32px;
        display: inline-block;
        background-size: contain;
        background-image: url('~@/assets/img/icon_plus_gray@2x.png');
        &.usable{
          background-image: url('~@/assets/img/icon_plus@2x.png');
        }
      }
    }
    .error-tips {
      font-size: 10px;
      height: 22px;
      line-height: 22px;
      color: #fe8102;
      text-align: center;
    }
  }
  .cy-verify-content {
    font-size: 18px;
    padding: 30px 34px;
    text-align: left;
    .input-cell {
      display: flex;
      align-items: center;
      margin-top: 15px;
      .cmcc-mobile {
        font-size: 15px;
        flex: 1;
        border-bottom: 1px solid #eaeaea;
        padding: 8px 0;
      }
    }
    .m-verify {
      // border-bottom: solid 1px #EAEAEA;
      margin-bottom: 25px;
      margin-top: 6px;
      display: flex;
      align-items: center;
      width: 100%;
      position: relative;
    }
    input {
      border: none;
      border-bottom: solid 1px #EAEAEA;
      font-size: 15px;
      padding: 12px 0;
      flex: 1;
    }
    .right {
      font-size: 14px;
      color: #FF9A40;
      position: absolute;
      right: 0;
      top: 10px;
    }
  }
  .m-button {
    background:linear-gradient(270deg,rgba(255,143,64,1) 0%,rgba(255,189,64,1) 100%);
    border-radius: 20px;
    color: #fff;
    text-align: center;
    height: 40px;
    line-height: 40px;
    font-size: 14px;
    margin-top: 10px;
    &.disabled{
      opacity: .5;
    }
  }

</style>

<style lang="scss">
  .exchange-input {
      &.numeric-input{
        width: 116px;
        height: 44px;
        background: #f0f0f0;
        border-radius: 22px;
        border: unset;
        text-align: right;
        padding: 0 18px;
        font-size: 20px;
        margin: 0 14px;
        color: #333;
        box-sizing: unset;
        .numeric-input-cursor{
          background: #333;
          top: 20%;
          height: 60%;
        }
      }
    }
</style>
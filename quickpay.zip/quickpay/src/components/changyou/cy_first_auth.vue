<template>
  <div class="cy-first-auth">
    <v-dialog
      v-show="showConfirm"
      :dialog-wrap-style="{ borderRadius:'15px', 'max-width': 'unset', width: '88%', background: '#fff'}"
    >
      <!-- 畅由账户首次使用授权 -->
      <!-- <confirm v-model="showConfirm"
        :title="'账户首次使用授权'"
        :show-cancel-button="false"
        :show-confirm-button="false"> -->
        <!-- :confirm-text="'确认'"
        @on-confirm="onConfirm"> -->
        <div class="title">账户首次使用授权</div>
        <div class="content">
          <div>确认使用【手机号：{{phoneNumber | telHandle}}】关联畅由积分账户。</div>
          <div v-if="cyInfo.points && parseFloat(cyInfo.points) > 0">当前畅由分为：{{cyInfo.points}}</div>
          <div class="tips">授权后您将可以更快速地积攒畅由积分,并享受更多更丰富的权益和消费场景。</div>
          <div v-if="parseFloat(ledouBalance)">您当前【{{ledouBalance}}乐豆】将兑换成{{_multiplicationFn(ledouBalance, 100)}}畅由分</div>
          <div class="agreement">我已阅读并同意<span class="link" @click="showUserAgreement = true">《用户协议》</span>和<span class="link" @click="showPrivacyPolicy = true">《隐私协议》</span></div>
        </div>
        <div class="btn" @click="onConfirm">确定</div>
      <!-- </confirm> -->
      </v-dialog>
      <cy-user-agreement v-show="showUserAgreement" @on-close="showUserAgreement = false"></cy-user-agreement>
      <cy-privacy-policy v-show="showPrivacyPolicy" @on-close="showPrivacyPolicy = false" :is-cy-user="cyInfo && cyInfo.isConection === 'true'"></cy-privacy-policy>
    </div>
</template>

<script>
import VLoading from '@/components/v_loading'
import VDialog from '@/components/v_dialog'
// import { Confirm, TransferDomDirective as TransferDom } from 'vux'
import CyUserAgreement from '@/components/changyou/cy_user_agreement'
import CyPrivacyPolicy from '@/components/changyou/cy_privacy_policy'
import { updateCyFlag, cyUserRegister } from '@/api/changyou'
import { returnCyRegisterLink } from '@/utils/common'
import { getCache, setCache } from 'sa-common'
export default {
  name: 'cy-first-auth',
  components: {
    VLoading,
    VDialog,
    CyUserAgreement,
    CyPrivacyPolicy
    // Confirm
  },
  // directives: {
  //   TransferDom
  // },
  props: {
    onShow: {
      type: Boolean,
      default() {
        return false
      }
    },
    cyInfo: {
      type: Object,
      default() {
        return {
          points: '', // 用户畅游分
          cmccPoints: '', // 用户移动积分
          cyExchangeRate: '', // 畅游兑换比例
          isBingding: '', // 用户是否已绑定移动 0|未绑定，1|正常，2|被冻结需要用户先去移动解，3| 解除绑定，4|查询移动状态失败
          isConection: '', // 用户是否已关联畅由
        }
      }
    },
    ledouBalance: {
      type: [Number, String],
      default() {
        return 0
      }
    }
  },
  data() {
    return {
      showConfirm: false,
      phoneNumber: '',
      showUserAgreement: false, // 显示用户协议
      showPrivacyPolicy: false // 显示隐私政策
    }
  },
  watch: {
    onShow(val) {
      this.showConfirm = val
      if (!this.phoneNumber) {
        let info = getCache('information') || {}
        let queryBind = getCache('queryBindData') || {}
        this.phoneNumber = info.mobilePhone || queryBind.mobilePhone
      }
    }
  },
  created() {
    let info = getCache('information') || {}
    let queryBind = getCache('queryBindData') || {}
    this.phoneNumber = info.mobilePhone || queryBind.mobilePhone
    this.queryIsFirstAuth()
  },
  filters: {
    telHandle(tel) {
      let str = ''
      if (tel) str = tel.substring(0, 3)+"****"+tel.substr(tel.length-4)
      return str;
    }
  },
  methods: {
    queryIsFirstAuth() { // 查询用户是否是首次授权
      let info = getCache('information') || {}
      if (info.cyBindFlag == 1 && info.cyProtocolFlag == 0) { // cyBindFlag：是否未联合用户 0|否 1|是；cyProtocolFlag：用户是否已接受畅由用户协议（首次授权）  0|未授权 1|已授权
        this.showConfirm = true
      }
    },
    onConfirm() {
      // 用户首次授权修改后台标志
      this.bus.$emit('loading', true)
      updateCyFlag({
        updateType: 0,
        updateFlag: 1
      }).then(res => {
        this.bus.$emit('loading', false)
        if (res.result === '000000') {
          let info = getCache('information') || {}
          info.cyProtocolFlag = 1
          setCache('information', info)
          this.$emit('close-auth')
          this.checkUser()
          // this.$emit('on-confirm')
          // this.showConfirm = false
        }
      })
    },
    checkUser() { // 检查用户类型
      if (this.cyInfo.isRegister === 'true' && this.cyInfo.isConection === 'true' && this.cyInfo.isBingding == 1) { // 畅由关联用户且移动已绑定
        this.$emit('bind-success', true)
      } if (this.cyInfo.isRegister === 'true' && this.cyInfo.isConection === 'true' && this.cyInfo.isBingding == 4) { // 畅由关联用户，移动状态查询失败
        this.$toast.show({
          text: '您的手机号状态，查询失败请稍后再试',
          position: 'center'
        })
      } else if (this.cyInfo.isRegister === 'true' && this.cyInfo.isConection != 'true') { // 是畅由用户
        this.cyRelation() // 调接口关联畅由用户
      } else if (this.cyInfo.isRegister !== undefined) { // 其他情况 （不是畅由用户、是畅由用户移动未绑定或者冻结状态）跳转至畅由注册页
        let link = returnCyRegisterLink(this, this.ledouBalance)
        location.href = link
      } else {
        this.$toast.show({
          text: '服务异常',
          position: 'center'
        })
      }
    },
    cyRelation() { // 畅由用户关联
      this.bus.$emit('loading', true)
      cyUserRegister({
        mobile: this.phoneNumber
      }).then(res => {
        this.bus.$emit('loading', false)
        if (res.result === '000000') {
          if (res.data && res.data.isBingding == 1) { // 已绑定移动
            this.$emit('bind-success', true)
          } else { // 未绑定移动 跳转链接去绑定
            let link = returnCyRegisterLink(this, this.ledouBalance)
            location.href = link
          }
        } else {
          if (res.description) {
            this.$toast.show({
              text: res.description,
              position: 'center'
            })
          }
        }
      })
    }
  }
}
</script>
<style lang="scss" scope>
.cy-first-auth {
  .title {
    padding: 18px 0 25px;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
  }
  .content {
    color: #333;
    font-size: 14px;
    text-align: left;
    line-height: 22px;
    padding: 0 28px 12px;
    .tips {
      font-size: 11px;
      color: #999;
    }
    .agreement {
      text-align: center;
      padding-top: 25px;
      font-size: 12px;
      color: #666666;
    }
    .link {
      color: #3CB3F3;
    }
  }
  .btn {
    text-align: center;
    font-size: 14px;
    height: 40px;
    line-height: 40px;
    font-size: 14px;
    color: #fff;
    margin: 0 40px 20px;
    border-radius: 50px;
    background: linear-gradient(270deg,rgba(255,143,64,1) 0%,rgba(255,189,64,1) 100%);
  }
}
</style>

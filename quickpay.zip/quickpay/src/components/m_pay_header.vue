<template>
  <div class="m-pay-header">
    <!-- 头部 -->
    <header class="localPay-header">
      <div class="localPay-header-div">
        <div class="header-left-box" :style="{visibility: fromScan != 1 ? 'hidden' : 'visible'}">
          <span class="header-left sch5-icon sch5-back-g" @click="goBack"></span>
        </div>
        <p class="header-center">{{shopName}}</p>
        <div class="header-left-box">
          <span class="header-left"></span>
        </div>
      </div>
    </header>
    <!-- tab切换 -->
    <div class="tab-wrapper" v-if="showTab">
      <ul class="tabBox">
        <li @click="onItem(0)" :class="{'selected' : index === 0}">
          个人买单
          <span></span>
        </li>
        <li @click="onItem(1)" :class="{'selected' : index === 1}">
          乐拼单
          <span></span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MPayHeader',
  props: {
    index: Number,
    shopName: String,
    fromScan: Number,
    showTab: Boolean // 是否显示tab
  },
  data() {
    return {}
  },
  created() {},
  methods: {
    onItem(num) {
      this.$emit('tab-change', num)
    },
    goBack () {
      window.location.href = window.location.origin
    }
  }
}
</script>
<style lang="scss">
.m-pay-header {
  // 头部
  .localPay-header {
    width: 100%;
    height: 38px;
    line-height: 38px;
    background: #fff;
    .localPay-header-div {
      padding: 0 14px;
      display: flex;
      .header-left-box {
        float: left;
        .header-left {
          width: 48px;
          display: inline-block;
          text-align: center;
          height: 40px;
          line-height: 40px;
        }
        .sch5-back-g{
          font-size: 26px;
        }
      }
      .header-center {
        flex: 1;
        text-align: center;
        font-size: 18px;
        font-weight: bold;
        color: #212121;
        margin: 0;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        vertical-align: middle;
      }
    }
  }
  // 头部tab
  .tab-wrapper {
    width: 100%;
    background: #fff;
    height: 35px;
    .tabBox {
      background: #fff;
      display: flex;
      &::after {
        display: block;
        content: '';
        clear: both;
      }
      li {
        width: 100px;
        height: 24px;
        line-height: 24px;
        text-align: center;
        float: left;
        color: #333;
        font-size: 16px;
        font-weight: bold;
        position: relative;
        flex: 1;
      }
      .selected {
        color: #fd6900;
        span {
          position: absolute;
          width: 30px;
          height: 3px;
          border-radius: 3px;
          background: #fb6800;
          bottom: -10px;
          left: 43%;
        }
      }
    }
  }
}
</style>

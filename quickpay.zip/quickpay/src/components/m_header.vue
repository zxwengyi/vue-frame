<template>
  <div :class="'m-header ' + (type ? 'f-header' : '')" id="m-header">
    <!--<div class="m-header-state-height"></div>-->
    <div
      class="m-header-state-height"
      v-bind:style="{ height: statusBarHeight.h + 'px !important', backgroundColor: type ? 'rgba(0,0,0,0)' : '#fff' }"
    ></div>
    <div class="m-header-content" id="m-header-content" :style="{top: statusBarHeight.h + 'px'}">
      <div class="left">
        <slot name="left">
          <div v-on:click="back" class="left-box">
            <span class="sch5-icon sch5-back-g"></span>
          </div>
        </slot>
      </div>
      <div class="center">
        <slot name="center">
          <div class="center-box">{{ name || title }}</div>
        </slot>
      </div>
      <div class="right">
        <slot name="right">
          <div v-on:click="back" class="right-box"></div>
        </slot>
      </div>
    </div>
    <div class="m-header-height" :style="{height: type ? '0px' : (44 + statusBarHeight.h + 'px')}"></div>
  </div>
</template>

<script>
import { setLocalStorage, getLocalStorage, delLocalStorage, getSessionStorage, delSessionStorage } from 'sa-common'
export default {
  name: 'm-header',
  props: {
    name: {
      default: ''
    },
    type: {
      default: ''
    }
  },
  data() {
    return {
      title: '',
      statusBarHeight: ''
    }
  },
  created() {
    if (this.$route.meta.title) {
      this.title = this.$route.meta.title
    }
  },
  methods: {
    back() {
      console.log(this.$route)
      console.log(window.history)
      if (this.$client.GLSH_APP) {
        if (this.$store.state.appOpenPage.path !== 'undefined') {
          if (this.$store.state.appOpenPage.path === this.$route.path) {
            let idx = ''
            if(this.$route.path === '/userCenter/news'){
              idx = 2
            }
            if(idx){
              this.$cordova('closePage', [idx])
            }else{
              this.$cordova('closePage', [])
            }
            return
          }
        }
        if (this.$route.path === '/giftShare' || this.$route.path === '/giftShare/period' || this.$route.path === '/giftShare/offlineActivities') {
          this.$cordova('closePage', [])
          return
        }
      }
      if (this.$route.query.goindex === 'true') {
        this.$router.push('/')
        if (getSessionStorage('goodsId')) {
          delSessionStorage('goodsId')
        }
      } else if (this.$route.name === 'userCenter-myLove' && sessionStorage.getItem('mylove_goto_tab_store')) {
        sessionStorage.removeItem('mylove_goto_tab_store')
        this.$router.push({ name: 'userCenter' })
      } else {
        this.$router.back()
        if (getSessionStorage('goodsId')) {
          delSessionStorage('goodsId')
        }
      }
    }
  },
  mounted() {
    this.statusBarHeight = JSON.parse(sessionStorage.getItem('statusBarHeight')) || {}
    this.$client.IOS ? (this.statusBarHeight.toph = 44) : 0
  }
}
</script>

<style lang="scss" scoped>
/* .vux-header-title {
    color: #333 !important;
    font-size: 17px !important;
    font-weight: bold !important;
} */
.f-header{
  .m-header-content {
    position: absolute;
  }
}
.m-header-content {
  position: fixed;
  z-index: 999;
  display: flex;
  justify-content: space-between;
  line-height: 24px;
  height: 44px;
  text-align: center;
  background-color: #fff;
  /*border-bottom: 1px solid #eee;*/
  width: 100%;
  box-sizing: border-box;
  .left {
    .sch5-icon {
      font-size: 24px;
    }
    .sch5-icon:before {
      color: #333;
    }
  }
  .center {
    font-weight: bold;
    font-size: 17px;
    color: #333;
    height: 24px;
    flex: 1;
  }
}
.m-header-height {
  height: 44px;
}
.m-header-state-height {
  background-color: #fff;
  position: fixed;
  z-index: 999;
  width: 100%;
}
</style>

<style lang="scss">
.left-box,
.right-box {
  padding: 10px 4px;
  width: 48px;
  box-sizing: border-box;
  text-align: center;
}
.center-box {
  padding: 10px 0;
  height: 24px;
}
.f-header{
  .m-header-content {
    background-color: rgba(0,0,0,0);
    .center{
      color: #FFFFE0BF;
    }
    .left .sch5-icon:before{
      font-weight: 700;
      color: #FFFFE0BF;
    }
  }
}
</style>

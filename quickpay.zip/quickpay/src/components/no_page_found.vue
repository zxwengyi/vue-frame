<template>
  <div class="no-page-found">
    <m-header></m-header>
    <m-empty msg="很抱歉，您访问的页面不存在">
      <div slot="icon"><span class="sch5-icon sch5-404"></span></div>
      <x-button slot="custom" mini plain type="primary" v-on:click.native="toHome">回到首页</x-button>
    </m-empty>
  </div>
</template>

<script>
import MEmpty from '@/components/m_empty'
import MHeader from '@/components/m_header'
import { XButton } from 'vux'
export default {
  name: 'no-page-found',
  components: {
    MHeader,
    MEmpty,
    XButton
  },
  methods: {
    toHome() {
      this.$router.replace({ name: 'home' })
    }
  }
}
</script>

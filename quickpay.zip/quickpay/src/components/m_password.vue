<template>
  <div class="m-password">
    <div class="content">
      <!-- 输入框（表格） -->
      <div class="pay_number" v-on:click="setFocus" style="width:100%;height:50px;border-left: 0;">
        <div class="password_dot" v-for="(item, index) in opt.value_num" :key="index">
          <!-- 光标 -->
          <div v-if="opt.value_length == item - 1 && opt.focus_class" class="cursor"></div>
          <!-- 点样式 -->
          <div v-if="opt.value_length >= item" :class="[opt.see ? '' : 'dot']">{{ opt.see ? opt.val_arr[index] : '' }}</div>
        </div>
      </div>
      <!-- 输入框（隐藏） --><!--class='input-container'-->
      <input v-model="opt.input_value" ref="inputPassword" maxlength="6" pattern="[0-9]*" class="input-container" placeholder="" @input="getValue" @focus="focus" @blur="blur" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'm-password',
  props: ['show', 'options', 'value'],
  data() {
    return {
      timer: '',
      opt: {
        input_value: '', //输入框的初始内容
        value_length: 0, //输入框密码位数
        value_num: [1, 2, 3, 4, 5, 6], //输入框格子数
        see: false, //是否明文展示
        focus_class: true
      }
    }
  },
  watch: {
    show: function(n, o) {
      this.$refs.inputPassword.focus()
    },
    value: function() {
      this.opt.value_length = 0
      this.opt.input_value = ''
    }
  },
  created() {},
  methods: {
    // 获得焦点时
    focus() {
      this.opt.focus_class = true
    },

    // 失去焦点时
    blur() {
      this.opt.focus_class = false
    },

    // 点击聚焦
    setFocus() {
      this.$refs.inputPassword.focus()
    },

    // 获取输入框的值
    getValue(data) {
      if (/^[0-9]\d*$/.test(this.opt.input_value)) {
        if (data.target.value.length) {
          /*=== 6*/
          this.$emit('valueSix', this.opt.input_value)
        }
        // 设置空数组用于明文展现
        let val_arr = []
        // 获取当前输入框的值
        let now_val = data.target.value
        // 遍历把每个数字加入数组
        for (let i = 0; i < 6; i++) {
          val_arr.push(now_val.substr(i, 1))
        }
        // 获取输入框值的长度
        let value_length = data.target.value.length
        // 更新数据
        ;(this.opt.value_length = value_length), (this.opt.val_arr = val_arr), (this.opt.input_value = now_val)
      } else {
        this.opt.value_length = 0
        this.opt.input_value = ''
        this.$refs.inputPassword.focus()
        // this.$vux.toast.text('请输入数字')
        this.$toast.show({
          text: '请输入数字',
          position:'center'
        })
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      document.querySelector('.input-container').addEventListener('blur', function(event) {
        const scrollHeight = document.documentElement.scrollTop || document.body.scrollTop || 0
        window.scrollTo(0, Math.max(scrollHeight - 1, 0))
      })
    })
  },
  activated() {
    this.$refs.inputPassword.focus()
    this.timer = setTimeout(() => {
      this.$refs.inputPassword.focus()
    }, 500)
  },
  beforeRouteLeave(to, from, next) {
    // 销毁定时器
    this.timer = null
    next()
  }
}
</script>

<style scoped>
.m-password {
  background: rgba(0, 0, 0, 0);
}
.content {
  padding-top: 28px;
}
/* 支付密码框 */

.pay_number {
  margin: 0 auto;
  display: flex;
  flex-direction: row;
  border: 1px solid #cfd4d3;
  /* border-radius:10rpx; */
}

.pay_number_interval {
  margin: 0 auto;
  display: flex;
  flex-direction: row;
  border-left: 1px solid #cfd4d3;
  /* border:none; */
}

/* 第一个格子输入框 */
.content .noBorder {
  border-left: none;
}

/* 支付密码框聚焦的时候 */

.get_focus {
  border-color: #a9885a;
}

/* 单个格式样式 */

.password_dot {
  flex: 1;
  border-left: 1px solid #cfd4d3;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #fff;
}

.password_dot_interval {
  flex: 1;
  border: 1px solid #cfd4d3;
  margin-right: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 单个格式样式（聚焦的时候） */

.get_focus_dot {
  flex: 1;
  border-left: 1px solid #a9885a;
  display: flex;
  align-items: center;
  justify-content: center;
}

.get_focus_dot_interval {
  flex: 1;
  border: 1px solid orange;
  margin-right: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 模拟光标 */

.cursor {
  width: 1px;
  height: 15px;
  background-color: #a9885a;
  animation: focus 0.7s infinite;
}

/* 光标动画 */

@keyframes focus {
  from {
    opacity: 1;
  }

  to {
    opacity: 0;
  }
}

/* 格式中的点 */

.dot {
  width: 10px;
  height: 10px;
  background-color: #000;
  border-radius: 50%;
}

/* 输入框 */

.input-container {
  /*  height: 0;*/
  /* width: 0;*/
  /*min-height: 0;*/
  /*text-indent: -999em;*/
  position: relative;
  left: -100%;
  opacity: 0;
}
</style>

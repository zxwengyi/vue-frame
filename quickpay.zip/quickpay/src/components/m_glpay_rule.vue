<template>
  <!-- 乐拼单规则 -->
  <div class="m-glpay-rule">
    <v-dialog v-show="showView">
      <div>
        <div class="title">乐拼单规则</div>
        <div class="content">
          <p v-for="(item, index) in list" :key="index" v-html="item"></p>
        </div>
        <div class="footer">乐拼单最终解释权归深圳给乐信息科技有限公司所有</div>
      </div>
    </v-dialog>
    <div class="btn-close" @click="hide()" v-show="showView"></div>
  </div>
</template>
<script>
import VDialog from '@/components/v_dialog'
export default {
  name: 'm-cardpay-password',
  components: {
    VDialog,
  },
  data() {
    return {
      showView: false,
      list: [
        '1、乐拼单由一人发起，先选择商家设置乐拼单金额或扫描商家收款码，确认后发起乐拼单，其他人扫描乐拼单二维码参与。',
        '2、乐拼单人数最少2人，若发起人认领金额后则至少需要3人。',
        '3、乐拼单由发起者设置金额，金额不能低于10元。',
        '4、发起者可以设置乐拼单的认领金额，其中认领金额不低于乐拼单金额的11%，不高于90%。',
        '5、乐拼单的发起者点击“随机抽签”后所有人进入到随机抽签界面，系统按参与人数随机生成个人买单金额，乐拼单人员点击“欢乐逗地主”匹配相应的金额，若没有在60s内操作，则系统默认对人员和金额匹配。',
        '6、乐拼单的随机抽签匹配金额最高者获得“地主”称号，匹配金额最低者获得“幸运之星”称号。',
        '7、参与乐拼单的所有人与抽签金额相匹配后，发起者就可进行乐拼单支付，若有参与者未支付则由发起者补足参与者未支付的金额完成乐拼单。',
        '8、中途退出乐拼单后，若未进入随机抽签，参与者则可重新扫码加入；发起者可通过点击首页“未完成的乐拼单”重新进入。若已进入随机抽签，则发起者或参与者（使用给乐生活APP）都可通过点击首页“未完成的乐拼单”重新进入，或通过乐拼单记录重新进入；若参与者使用微信参与的乐拼单，可通过扫描其他人页面的二维码继续参与到乐拼单。',
        '9、乐拼单支持微信支付、乐豆支付，若个人买单金额小于1元时则不支持乐豆支付，若乐豆余额大于买单金额时则微信支付金额必须大于等于1元。',
        '10、乐拼单所有人支付后都可获得赠送乐豆，支付金额越大赠送乐豆越多，乐豆可在给乐生活联盟商家使用。',
        '&nbsp;&nbsp;（1）乐拼单完成之前由发起者发起，若参与者未付款，则乐拼单解散；若参与者正在支付或者支付完成时，则支付金额会在1-3个工作日返回到所使用支付账户。',
        '&nbsp;&nbsp;（2）乐拼单完成后，如要撤单，则需和商家协商后由商家发起撤单。'
      ]
    }
  },
  methods: {
    show() {
      this.showView = true
    },
    hide() {
      this.showView = false
    }
  },
}
</script>

<style lang="scss">
.m-glpay-rule{
  .dialog-content-wrap {
    bottom: 10%;
    overflow: scroll;
    background: #fff;
    top: 8%;
    margin: 0 5%;
    width: unset;
  }
  .title {
    font-size: 16px;
    padding: 20px 0 10px 30px;
  }
  .content{
    font-size: 14px;
    padding: 0 15px;
  }
  .footer{
    font-size: 12px;
    color: #95A1AB;
    text-align: center;
    padding: 10px 0 30px 0;
  }
}
  .btn-close{
    width: 30px;
    height: 30px;
    background: url(~@/assets/img/icon_close.png) no-repeat;
    background-size: contain;
    z-index: 999;
    left: 44%;
    bottom: 4%;
    position: absolute;
  }
</style>

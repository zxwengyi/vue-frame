<template>
  <v-dialog v-show="showView">
    <div class="m-cardpay-password">
      <!-- 需要输入支付密码 -->
      <div class="need-in">
        <div class="title">请输入6位支付密码</div>
        <m-password :show="showView" @valueSix="valueSix" :value="valueNull"></m-password>
        <span class="for-get-password" @click="forgetPassword">忘记密码？</span>
        <div @click="onConfirm" class="toShop">确认支付</div>
      </div>
    </div>
      <div class="close" @click="hide()"></div>
  </v-dialog>
</template>
<script>
import VDialog from '@/components/v_dialog'
import MPassword from '@/components/m_password'
import { getCheckToken } from '@/api/index'
import { getLocalStorage } from 'sa-common'
export default {
  name: 'm-cardpay-password',
  components: {
    VDialog,
    MPassword
  },
  // props: ['show'],
  data() {
    return {
      showView: false,
      password: '',
      valueNull: 1,
      checkToken: '',
    }
  },
  // watch: {
  //   show(val) {
  //     this.showView = val
  //   }
  // },
  methods: {
    forgetPassword() {
       window.location.href = '/userCenter/sysInfo/password?type=2'
    },
    show() {
      this.showView = true
    },
    hide() {
      this.showView = false
    },
    // closeDialog() {
    //   this.showView = false
    //   this.$emit('on-hide', this.showView)
    // },
    valueSix(v) {
      this.password = v
    },
    onConfirm() {
      getCheckToken().then(res => {
        if (res.result === '000000') {
          this.checkToken = res.data
          let userId = getLocalStorage('userinfo').userId
          let str = this.$md5(this.password + userId)
          let password = this.$md5(str + this.checkToken)
          this.$emit('on-confirm', {
            checkToken: this.checkToken,
            password: password // 密码加密方式：MD5(MD5(明文+userid)+checkToken)
          })
        }
      })
    }
  },
}
</script>

<style lang="scss">
.m-cardpay-password {
  padding: 0 15px 20px;
  background:#fff;
  text-align: center;
  .title {
    font-size: 18px;
    color: #6e6e6e;
    padding: 8px 0;
    border-bottom: 1px solid #e2e2e2;
  }
  .toShop {
    background: linear-gradient(270deg, rgba(255, 129, 0, 1) 0%, rgba(255, 175, 92, 1) 100%);
    border-radius: 30px !important;
    font-size: 14px;
    height: 40px;
    line-height: 40px;
    color: #fff;
  }
  .for-get-password {
    font-size: 12px;
    text-align: right;
    width: 100%;
    display: inline-block;
    line-height: 32px;
    color: #ff8305;
  }
}
  .close{
    width: 30px;
    height: 30px;
    background: url(~@/assets/img/icon_close.png) no-repeat;
    background-size: contain;
    margin: 10px auto 0;
  }
</style>

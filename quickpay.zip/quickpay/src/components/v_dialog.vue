<template>
  <transition name="dialog-fade">
    <div v-show="showDialog" class="my-dialog">
      <div class="dialog-content-wrap" @click.stop :style="dialogWrapStyle">
          <slot></slot>
      </div>
    </div>
  </transition>
</template>

<script type="text/ecmascript-6">
export default {
  props: {
    dialogWrapStyle: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data () {
    return {
      showDialog: false, // 用于控制整个窗口的显示/隐藏
    }
  },
  methods: {
    show () {
      this.showDialog = true
    },
    hidden () {
      this.showDialog = false
    }
  }
}
</script>

<style scoped>
  .my-dialog {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 998;
    /* 这里防止当用户长按屏幕，出现的黑色背景色块，以及 iPhone 横平时字体的缩放问题 */
    -webkit-text-size-adjust: 100%;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  }

  /* 进入和出去的动画 */
  .dialog-fade-enter-active {
    animation: opacity 0.3s;
  }
  .dialog-fade-enter-active .dialog-content-wrap {
    animation: scale 0.3s;
  }
  .dialog-fade-leave-active {
    animation: outOpacity 0.2s;
  }

  /* 包裹层容器样式 */
  .dialog-content-wrap {
    position: absolute;
    top: 28%;
    left: 0;
    right: 0;
    width: 280px;
    margin: 0 auto;
    /* background-color: #fff; */
    border-radius: 5px;
    z-index: 999;
    user-select: none;
  }

  /* 进来的动画 */
  @keyframes opacity {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  @keyframes scale {
    0% {
      transform: scale(0);
    }
    60% {
      transform: scale(1.1);
    }
    100% {
      transform: scale(1);
    }
  }

  /* 出去的动画 */
  @keyframes outOpacity {
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
  }
</style>
<template>

</template>

<script>
export default {
  name: 'keyboard',
  data() {
    return {

    }
  }

}
</script>

<style lang="scss" scoped>

</style>

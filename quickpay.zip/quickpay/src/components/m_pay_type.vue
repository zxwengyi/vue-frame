<template>
  <!-- 判断商户是否支持当前支付方式 -->
  <div class="m-pay-type">
    <v-confirm ref="VConfirm" @userBehavior="VConfirmClick"></v-confirm>
  </div>
</template>

<script>
import VConfirm from '@/components/v_confirm'
import { payType } from '@/api/index'
export default {
  name: 'MPayType',
  components: {
    VConfirm
  },
  methods: {
    getPayType(merchantNo) { //查询商家配置的支付渠道（weixin OR alipay）
      payType({merchantNo: merchantNo}).then(res => {
        if (res.result == '000000') {
          if ((this.$client.WEIXIN && res.data.indexOf('weixin') < 0) || (this.$client.ALIPAY && res.data.indexOf('weixin') < 0)) {
            this.confirmType = 1
            this.$refs.VConfirm.show('暂不支持该种支付方式，<br>请尝试其他支付方式。', {
                titleText: '',
                confirmText: '知道了',
                hideCancelBtn: true
            })
          } else {
            this.$emit('on-show')
          }
        }
      })
    },
    VConfirmClick() {
      if (this.$client.WEIXIN) {
        WeixinJSBridge.invoke('closeWindow', {}, function(res) {});
      } else if (this.$client.ALIPAY) {
        AlipayJSBridge.call('closeWebview')
      }
    }
  }
}
</script>
<style lang="scss">
.m-pay-type{
  .my-confirm{
    z-index: 1000;
  }
}
</style>
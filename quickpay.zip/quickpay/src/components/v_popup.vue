<template>
  <transition name="popup-fade">
    <div v-show="showPopup" class="my-popup">
      <div class="popup-content-wrap" @click.stop :style="popupWrapStyle">
          <slot></slot>
      </div>
    </div>
  </transition>
</template>

<script type="text/ecmascript-6">
export default {
  props: {
    popupWrapStyle: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data () {
    return {
      showPopup: false, // 用于控制整个窗口的显示/隐藏
    }
  },
  methods: {
    show () {
      this.showPopup = true
    },
    hidden () {
      this.showPopup = false
    }
  }
}
</script>

<style scoped>
  .my-popup {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 998;
    /* 这里防止当用户长按屏幕，出现的黑色背景色块，以及 iPhone 横平时字体的缩放问题 */
    -webkit-text-size-adjust: 100%;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  }

  /* 进入和出去的动画 */
  .popup-fade-enter-active {
    animation: opacity 0.3s;
  }
  .popup-fade-enter-active .popup-content-wrap {
    animation: translateX 0.3s;
  }
  .popup-fade-leave-active {
    animation: outOpacity 0.2s;
  }

  /* 包裹层容器样式 */
  .popup-content-wrap {
    position: absolute;
    /* top: 28%; */
    left: 0;
    right: 0;
    /* width: 280px; */
    margin: 0 auto;
    /* background-color: #fff; */
    border-radius: 5px;
    z-index: 999;
    user-select: none;
  }

  /* 进来的动画 */
  @keyframes opacity {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  @keyframes translateX {
    0% {
      transform: translateX(100%);
    }
    60% {
      transform: translateX(50%);
    }
    100% {
      transform: translateX(0%);
    }
  }

  /* 出去的动画 */
  @keyframes outOpacity {
    0% {
      transform: translateX(0%);
    }
    60% {
      transform: translateX(50%);
    }
    100% {
      transform: translateX(100%);
    }
  }
</style>
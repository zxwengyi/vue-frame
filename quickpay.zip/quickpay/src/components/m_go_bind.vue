<template>
  <!-- 去绑定手机号 -->
  <div class="bind-phone" v-show="!isBind">
      <span class="link" @click="goBindPhone()">绑定手机号码领取乐豆<i class="icon-arrow-right"></i></span>
      <m-bind-phone :show-view="showBindView" @on-close="onClose"></m-bind-phone>
  </div>
</template>
<script>
import { queryBind } from '@/api/index'
import { checkCyBind } from '@/api/changyou'
import MBindPhone from '@/components/m_bind_phone'
import { setCache, getCache } from 'sa-common'
export default {
  name: 'bind-phone',
  props: {
    openId: String,
    isCyUser: [Boolean, Number]
  },
  components: {
    MBindPhone
  },
  data() {
    return {
      isBind: true, // 是否绑定手机号
      showBindView: false
    }
  },
  watch: {
    isCyUser(val) {
      this.isBind = val
    },
    openId(val) {
      this.queryIsBind()
    },
    showBindView(val) {
      this.$emit('popup-watch', val)
    }
  },
  methods: {
    queryIsBind() { // 是否已绑定手机
      queryBind({
        openId: this.openId
      }).then(res => {
        if (res.result == '000000') {
          this.isBind = res.data.bind
          setCache('queryBindData', res.data)
        }
      })
    },
    goBindPhone() { // 去绑定手机
      // localStorage.setItem('bindPhoneBackUrl', location.href)
      // window.location.href = '/userCenter/userInfo/bindPhone?needBack=1'
      this.showBindView = true
    },
    onClose(type) { // type： 0|关闭绑定手机号弹窗 1|绑定成功，关闭弹窗
      this.showBindView = false
      if (type) {
        this.isBind = true
        let data = getCache('queryBindData')
        data.bind = true
        setCache('queryBindData', data)
        this.bus.$emit('loading', true)
        checkCyBind().then(res => { // 成功绑定手机号，查询用户是否为畅由用户
          this.bus.$emit('loading', false)
          if (res.result == '000000') {
            this.$emit('bind-phone-success', res.data == 1 ? 3 : 0)
          } else {
            this.$emit('bind-phone-success')
            if (res.description) {
              this.$toast.show({
                text: res.description,
                position: 'center'
              })
            }
          }

        })
      }
    }
    
  }
}
</script>

<style lang="scss">
.bind-phone{
  margin-top: 18px;
  margin-bottom: 20px;
  text-align: center;
  font-size: 14px;
  color: #FE6900;
  .link{
    position: relative;
    &:after {
      content: '';
      width: 100%;
      height: 1px;
      position: absolute;
      bottom: 1px;
      left: 0;
      background: #FE6900;
    }
  }
  .icon-arrow-right{
    margin-left: 5px;
    display: inline-block;
    width: 14px;
    height: 14px;
    background: url(~@/assets/img/icon_arrow_r.png) no-repeat;
    background-size: contain;
    position: relative;
    top: 2px;
  }
}
</style>
<template>
  <div class="localPay"> <!-- style="transform: translateX(0px)" -->
    <div class="m-view" v-show="showView" :style="{height: fullH || setH}">
      <!-- 头部 -->
      <m-pay-header :index="index" :shop-name="shopName" :fromScan="fromScan" @tab-change="onItem" :show-tab="!isCYUnionUSer && islogined"></m-pay-header>

      <!-- 消费金额输入框 -->
      <div class="localBox">
        <div class="inputBox" :class="{spell: index == 1}">
          <span class="input-title" v-show="index == 0">￥</span>
          <span class="spell-title" v-show="index == 1">消费总额（￥）</span>
          <template v-if="showView">
            <!-- $route.query.payType && $route.query.orderId，双渠道支付 -->
            <div
              v-if="$route.query.cash || $route.query.payType"
              class="input-readonly"
            >{{personalValue}}</div>
            <numeric-keyboard
              v-else
              placeholder="请输入消费金额"
              :autofocus="this.$route.fullPath.indexOf('cyregister=1') > -1 ? false : true"
              :maxlength="8"
              v-model="personalValue"
              @change="personalValueChange"
            />
          </template>
        </div>
        <div class="local-div" v-if="!isCYUnionUSer">
          <span class="local-tip">获赠乐豆</span>
          <span class="local-tip">消费金额的{{giftRate}}%</span>
          <div class="dou">
            <i>赠</i>
            <span>{{giftBean}}</span>
            <b>乐豆</b>
          </div>
        </div>
        <div class="local-div" v-if="isCYUnionUSer">
          <span class="local-tip">获赠畅由分</span>
          <span class="local-tip">消费金额的{{giftRate}}%</span>
          <div class="dou">
            <i>赠</i>
            <span>{{_multiplicationFn(parseFloat(giftBean), 100)}}</span>
            <b>畅由分</b>
          </div>
        </div>
      </div>
      <div style="height:10px;"></div>
      <!-- 中国移动 积分当钱花 -->
      <cy-yd-cell v-show="index === 0" @close-exchange="closeExchange" @bind-phone-success="bindPhoneSuccess" @popup-watch="popupWatch" :is-logined="islogined" :cyinfo-reflash="cyinfoReflash"></cy-yd-cell>
      <!-- 个人买单 -->
      <m-pay-method
        class="pay-method"
        v-show="index === 0"
        :card-balance="cardBalance"
        :card-switch="cardSwitch"
        :ledou-balance="ledouBalance"
        :switch-value="switchValue"
        :pay-method="payMethod"
        :show-card-pay="showCardPay"
        :is-cyu-user="isCYUnionUSer"
        @switch-card="cardSwitchFn"
        @switch-change="onSwitch"
        @paymethod-change="onChangeRadio"
      >
        <p class="tip" slot="deductTips"><span v-if="isCYUnionUSer">100畅由分价值1元，</span>本次抵扣{{deductible > 0 ? deductible : 0}}元</p>
        <span
          class="recharge"
          slot="recharge"
          :class="{hide: !showCardRecharge}"
          @click="goRecharge"
          v-show="cardId"
        >立即充值</span>
      </m-pay-method>

      <!-- 乐拼单 -->
      <div class="localBox localSpell" v-show="index === 1">
        <!-- 认领金额 -->
        <div class="renling-wrapper">
          <p class="local-checkbox">
            <label class="my_protocol">
              <input class="input_agreement_protocol" type="checkbox" @change="onChange" />
              <span></span>
              我要认领
            </label>
          </p>
          <!-- 认领金额 -->
          <div v-show="renling">
            <div class="input-wrap">
              <span class="input-title">认领金额（元）</span>
              <numeric-keyboard placeholder=" " v-model="claimAmount" @change="claimAmountChange" />
            </div>
          </div>
          <p
            class="localSpell-p"
          >*认领金额最小为乐拼单总金额的{{minClaimAmount * 100}}%，最大为乐拼单总金额的{{maxClaimAmount * 100}}%</p>
          <p class="localSpell-p">*发起认领后，您将不再参与拼单</p>
        </div>
      </div>

      <!-- 去绑定手机号 -->
      <m-go-bind :is-cy-user="isCYUnionUSer" :open-id="openId" @popup-watch="popupWatch" @bind-phone-success="bindPhoneSuccess"></m-go-bind>
    </div>
    <!-- 底部按钮 -->
    <div class="local-pay-btn" id="MFooter" v-show="showView">
      <p class="payMoney" v-show="index === 0">{{payBalance > 0 ? payBalance : 0}}元</p>
      <button @click="toGoPay" :class="{'disabled': btnDisabled}">{{index === 0 ? '确认买单' : '发起乐拼单'}}</button>
      <span class="lqd-tips" v-show="index === 1" @click="showRule">什么是乐拼单?</span>
    </div>
    <v-loading></v-loading>
    <v-confirm ref="VConfirm" @userBehavior="VConfirmClick"></v-confirm>
    <!-- 储值卡密码弹窗 -->
    <m-cardpay-password ref="cardPassword" @on-confirm="cardpayConfirm" @on-hide="passwordOnHide"></m-cardpay-password>
    <!-- 乐拼单规则 -->
    <m-glpay-rule ref="glpayRule"></m-glpay-rule>
    <!-- 判断商户是否支持当前支付方式 -->
    <m-pay-type ref="MPayType" @on-show="showView = true"></m-pay-type>
  </div>
</template>

<script>
import * as _api from '@/api/index'
import { saBs } from '@/utils/base'
import { info } from '@/api/user'
import { setCache, clearCache, setLocalStorage, setSessionStorage } from 'sa-common'
import VLoading from '@/components/v_loading'
import VConfirm from '@/components/v_confirm'
import MPayHeader from '@/components/m_pay_header'
import MCardpayPassword from '@/components/m_cardpay_password'
import MGlpayRule from '@/components/m_glpay_rule'
import NumericKeyboard from '@/components/numeric-keyboard'
import MPayMethod from '@/components/m_pay_method'
import MGoBind from '@/components/m_go_bind'
import MPayType from '@/components/m_pay_type'
import CyYdCell from '@/components/changyou/cy_yd_cell'

export default {
  name: 'localPay',
  components: {
    VLoading,
    VConfirm,
    MPayHeader,
    MCardpayPassword,
    MGlpayRule,
    NumericKeyboard,
    MPayMethod,
    MGoBind,
    MPayType,
    CyYdCell
  },
  data() {
    return {
      cyinfoReflash: 0,
      islogined: false,
      isCYUnionUSer: false, // 是否是畅由联合用户
      fullH: '', // height:100%; (为了解决弹出弹窗时样式异常的问题)
      setH: '',
      balanceIsInit: false,
      confirmType: 1, // 1|未设置密码
      isSetPassword: 0, // 是否设置了支付密码 0|未设置 1|已设置
      showView: false,
      isWeixin: false,
      isAlipay: false,
      payMethod: 0, // 1|微信 2|支付宝
      index: 0, // 0|个人买单 1|乐拼单
      scene: '17', // 17微信支付 20 支付宝支付
      paySence: '04', //04 微信公众号支付 07 支付宝公众号支付
      personalValue: '', //个人、拼单金额
      value: 'true',
      switchValue: false, //switch设置开关
      cardSwitch: false, // 储值卡开关
      renling: false, // 认领金额显示
      claimAmount: '', //认领金额
      totalAmountMin: 10, //认领金额最小数
      giftRate: 0, //交易金额的利率
      ledouBalance: 0, //乐豆余额
      cardBalance: '', // 储值卡余额
      showCardPay: false, // 是否显示储值卡
      deductible: '', //可抵扣金额
      payBalance: '', //支付金额
      minClaimAmount: '', //最小认领金额的百分比
      maxClaimAmount: '', //最大认领金额的百分比
      shopName: '', //店名
      merchantNo: '', //店名编号
      merchantImgUrl: '', //店铺头像
      terminal: '',
      openId: '',
      userId: '',
      unionId: '',
      operatorId: '',
      noBenefitAmount: '',
      alerttips: false,
      loadingStep: 0,
      fromScan: 0,
      defaultImg: '',
      countDownSec: '', //抽奖倒计时（毫秒）
      isHongkong: false, //是否为香港环境
      cardId: '', //储值卡goodsInfoId
      orderInfo: {} // C扫B查询订单信息
    }
  },
  computed: {
    btnDisabled() {
      // 底部按钮是否可点击
      let bool = false
      if (!this.personalValue) {
        // 没有消费金额
        bool = true
      } else {
        if (this.index === 0 && this.cardSwitch && this.cardBalance < this.personalValue) {
          // 选择储蓄卡支付&&余额小于消费金额
          bool = true
        }
      }
      return bool
    },
    showCardRecharge() {
      // 显示储值卡充值按钮
      let bool = false
      if (this.cardSwitch && (this.cardBalance < this.personalValue || !this.cardBalance)) {
        bool = true
      }
      return bool
    },
    giftBean() {
      // 计算获赠乐豆
      let num = 0
      if ((!this.cardSwitch && this.balanceIsInit) || this.index === 1) {
        num = (this.personalValue * (this.giftRate / 100)).toFixed(2)
      }
      return parseFloat(num).toFixed(2)
    }
  },
  watch: {
    personalValue() {
      // 选中switch时
      if (this.switchValue) {
        this.payMoney()
      } else {
        // switch未选中时
        this.payBalance = this.personalValue
      }

      // 计算认领金额
      this.claimAmount = Math.ceil(this.personalValue * this.minClaimAmount)
      console.log(this.claimAmount)
      if (this.personalValue === '') {
        this.claimAmount = ''
      }
    },
    ledouBalance() {
      if (this.switchValue) {
        this.payMoney()
      }
    }
  },
  created() {
    let query = this.$route.query
    if (query.cash) {
      this.personalValue = parseFloat(query.cash)
    }
    if (this.$client.ALIPAY) {
      this.payMethod = 2
      this.isAlipay = true
    } else if (this.$client.WEIXIN) {
      this.payMethod = 1
      this.isWeixin = true
    } else {
      this.payMethod = 3
    }
    clearCache('openId')
    clearCache('wxToken')
    clearCache('preBeanTotal')
    clearCache('buildGroupData')
    clearCache('information')
    clearCache('queryBindData')
    if (!this.switchValue) {
      this.deductible = this.ledouBalance
      this.payBalance = this.personalValue
    } else {
      this.payMoney()
    }
    this.getAuth()
    let bankUrl = location.href.split('?')[1]
    this.merchantNo = this.GetQueryString(bankUrl, 'merchantNo') ? this.GetQueryString(bankUrl, 'merchantNo') : this.GetQueryString(bankUrl, 'qrcode')
    this.fromScan = this.GetQueryString(bankUrl, 'fromScan') || 0
    this.getData()
    // todo 查询是否是联合用户
  },
  methods: {
    popupWatch(type) { // type 0|关闭弹窗 1|显示弹窗
      if (type) {
        this.fullH = '100%'
      } else {
        this.fullH = ''
      }
    },
    closeExchange(type) { // 畅由分兑换完成,重新请求获取余额 type:: 0|关闭畅由分兑换弹窗 1|兑换成功
      if (type) this.getBalanceFn()
    },
    bindPhoneSuccess(type) { // 绑定手机成功,重新获取乐豆余额 type: 3|底部绑定手机入口绑定成功，且是联合用户刷新cy-yd-cell中cyInfo的数据
      this.getBalanceFn()
      if (type) this.isCYUnionUSer = type
      if (type === 3) ++this.cyinfoReflash
    },
    cardSwitchFn(val) {
      // 储蓄卡支付开关
      this.cardSwitch = val
    },
    onChangeRadio(type) {
      // 现金支付方式切换 type 1|微信 2|支付宝
      this.payMethod = type
    },
    goRecharge() {
      // 去充值
      setSessionStorage('recharge', '')
      let url = localStorage.getItem('initUrl')
      let redirectUri = setSessionStorage('redirectUri', url)
      window.location.href = `${saBs.$locationLinkWX}/local/gooddetails/${this.cardId}?scProductDetailFrom=quickpay&redirectUri=quickpay`
    },
    cardpayConfirm(data) {
      // 储值卡输入密码确认支付
      this.checkToken = data.checkToken
      this.password = data.password
      this.getWxpub_prePay()
    },
    passwordOnHide(val) {
      // 隐藏密码弹窗
      this.$refs.cardPassword.hide()
    },
    VConfirmClick() {
      if (this.confirmType == 1) {
        // 去设置密码
        window.location.href = '/userCenter/sysInfo/password'
      }
    },
    hideLoading() {
      // 隐藏loading
      if (this.loadingStep) {
        this.bus.$emit('loading', false)
      } else {
        this.loadingStep = 1
      }
    },
    GetQueryString(url, name) {
      var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
      // FIX ME:
      var r = url.match(reg) //search,查询？后面的参数，并匹配正则
      if (r != null) return unescape(r[2])
      return null
    },
    onItem(index) {
      // this.personalValue = ''
      this.claimAmount = '' //认领金额为空
      if (index === 0) {
        this.index = 0
        //    this.renling = false
      } else {
        this.index = 1
        this.getRlAmountPro()
      }
    },
    getAuth() {
      // 登录
      let query = JSON.parse(JSON.stringify(this.$route.query))
      query.merchantNo = query.merchantNo || query.qrcode
      let code = ''
      if (this.$client.ALIPAY) {
        code = query.auth_code
      } else if (this.$client.WEIXIN) {
        code = query.code
      } else {
        code = query.userAuthCode  // 云闪付
      }
      // todo 云闪付登录
      if (code) {
        let getApi
        if (this.$client.UnionPay) { 
          getApi = _api.unionPayCredit({ code: code, officialAccountType: 'union', merchantNo: query.merchantNo })
        } else {
          getApi = _api.weChatCredit({ code: code })
        }
        getApi.then((res) => {
          let _data = res.data || { status: 0, data: {} }
          if (_data.status === 1 && _data.data) {
            query.openId = _data.data.openId
            if (this.$client.ALIPAY) {
              query.appId = saBs.$alipayAppid
            } else if (this.$client.WEIXIN){
              query.appId = saBs.$weixinAppid
            } else {
              query.appId = ''
            }
            // 这个服务后台是通过请求头的User-Agent判断是微信还是支付宝，所以调试时调用这个服务前，user-agent需要修改成相应的版本，否则会报错
            _api.wxauth(query).then((result) => {
              console.log(result)
              let userInfo = {
                token: result.data.token,
                userId: result.data.userId
              }
              this.openId = _data.data.openId
              this.userId = result.data.userId
              this.operatorId = result.data.operatorId
              this.unionId = result.data.unionId
              this.noBenefitAmount = result.data.noBenefitAmount
              this.terminal = result.data.terminal
              this.isCYUnionUSer = result.data.cyBindFlag // 是否为畅由联合用户
              setCache('openId', _data.data.openId)
              setCache('wxToken', result.data.token)
              setLocalStorage('userinfo', userInfo)
              info().then(res => {
                if (res.result === '000000') {
                  setCache('information', res.data)
                  this.islogined = true
                }
              })
              this.getEnableHappyCoin('1')
              this.getOrderInfo()
              this.hideLoading()
              this.getBalanceFn(1)
            })
          }
        })
      }
    },
    getData() {
      // 获取商家信息
      _api.merchantDetail({ merchantNo: this.merchantNo }).then((res) => {
        if (res.result === '000000') {
          this.shopName = res.data.merchantShortName
          this.giftRate = res.data.saleRate
          this.merchantImgUrl = res.data.mainImage
          this.merchantNo = res.data.merchantNo
          this.$refs.MPayType.getPayType(this.merchantNo)
        } else {
          this.$toast.show({
            text: res.description,
            position: 'center'
          })
        }
        this.hideLoading()
      })
    },
    getOrderInfo() {
      // 根据C扫B返回tokenId查询订单信息
      let query = this.$route.query
      if (query.orderId && query.payType) {
        // url上包含orderId&&payType=1
        _api
          .queryPayOrderInfo({
            outTokenId: query.orderId,
            outTokenType: 0
          })
          .then((res) => {
            if (res.result === '000000') {
              this.orderInfo = res.data
              this.personalValue = res.data.totalAmount
            }
          })
      }
    },
    getBalanceFn(flag) {
      // 获取乐豆/储值卡余额
      let _this = this
      _api.getBalance({ merchantNo: this.merchantNo }).then((res) => {
        if (res.result === '000000') {
          this.ledouBalance = res.data.amount
          this.cardBalance = res.data.depositBalance || 0
          this.showCardPay = res.data.depositAccountFlag
          if (flag === 1) this.initSwitch()
          _this.$nextTick(() => {
            let footerHeight = document.querySelector('#MFooter').clientHeight
            _this.setH = (window.innerHeight - footerHeight) + 'px'
          })
        }
      })
    },
    initSwitch() {
      // 乐豆/储值卡开关初始化
      if (this.showCardPay && this.cardBalance > 0) {
        // 有储值卡
        this.cardSwitch = true
        // 是否设置了密码
        _api.isPayPassword().then((res) => {
          if (res.result == '000000') {
            this.isSetPassword = res.data // 0|未设置密码 1|已设置密码
          }
        })
        this.getEnableHappyCoin(0)
        this.getCardId()
      } else {
        // 无储值卡
        this.switchValue = true
        this.payMoney()
        this.getEnableHappyCoin(1) // 打开乐豆开关
      }
      this.balanceIsInit = true
    },
    getRlAmountPro() {
      //    查询乐拼单认领金额占比
      _api.rlAmountPro().then((res) => {
        if (res.result === '000000') {
          this.minClaimAmount = res.data.min
          this.maxClaimAmount = res.data.max
          this.countDownSec = res.data.countDownSec
        }
      })
    },
    getWxpub_prePay() {
      // 个人买单确认支付
      let query = this.$route.query
      let orderInfo = this.orderInfo
      let params = {
        orderTitle: this.shopName + '_消费',
        totalAmount: this.personalValue,
        operatorId: query.operator || this.operatorId || '',
        noBenefitAmount: this.noBenefitAmount || '',
        merchantNo: this.merchantNo,
        paySence: 0,
        scene: this.paySence,
        terminal: orderInfo.terminal || this.terminal,
        openId: this.openId || query.openId,
        userId: this.userId || query.userId,
        payType: this.cardSwitch ? 'deposit' : this.payMethod == 1 ? 'weixin' : this.payMethod == 2 ? 'aliPay' : 'unionPay', // 支付方式 weixin|微信 aliPay|支付宝 deposit|储值卡 unionPay|云闪付
        checkToken: this.checkToken || '', // （储值卡支付）支付密码Token
        password: this.password || '', // （储值卡支付）支付密码
        orderId: query.orderId || '',
        merchentOrderDesc: orderInfo.merchentOrderDesc || '',
        notifyUrl: orderInfo.notifyUrl || '',
        attach: orderInfo.attach || '',
        outOrderNo: orderInfo.outOrderNo || '',
        settleCostAmount: orderInfo.settleCostAmount || '',
        source: orderInfo.source || ''
      }
      this.bus.$emit('loading', true)
      _api.prePay(params).then((res) => {
        this.bus.$emit('loading', false)
        if (res.result === '000000') {
          if (this.cardSwitch || this.payMethod == 3) {
            // 储值卡支付
            window.location.href = `${saBs.$locationLinkWX}/index1.html#/wx_pay_finish?orderNo=${res.data.orderNo}&isCYUnionUSer=${this.isCYUnionUSer? 'Y':''}`
            return
          }

          setCache('preBeanTotal', this.ledouBalance - this.deductible)
          let payInfo = JSON.parse(res.data.payInfo)
          payInfo['callback_url'] = `/index1.html?w=${saBs.$timeStr}${payInfo.callback_url}&isCYUnionUSer=${this.isCYUnionUSer? 'Y':''}`
          if (this.payMethod == 1) {
            // 微信支付
            this._weixinPayFn(payInfo)
          } else {
            // 支付宝支付
            this._aliPayFn(payInfo)
          }
        } else {
          this.$toast.show({
            text: res.description,
            position: 'center'
          })
        }
      })
    },
    gotoGroup() {
      // 发起乐拼单
      let param = {
        openId: this.openId,
        redirectUrl: '/buildGroup?'
      }
      _api.getCodeUrl4UserInfo(param).then((res) => {
        let myData = {
          imgUrl: res.data.headimgurl || this.defaultImg,
          merchantImgUrl: this.merchantImgUrl || this.defaultImg,
          merchantName: this.shopName,
          merchantNo: this.merchantNo,
          rlAmount: this.claimAmount && this.renling ? this.claimAmount : 0,
          totalAmount: this.personalValue,
          userName: res.data.nickname || '',
          saleRate: this.giftRate,
          terminal: this.terminal,
          apiVersion: 'V1.1.0'
        }
        console.log('myData', myData)
        setCache('buildGroupData', myData)
        window.location.href = res.data.url
      })
    },
    onChange(e) {
      // 我要认领checkbox事件
      if (this.personalValue === '' || this.personalValue == 0) {
        this.$toast.show({
          text: '请输入正确金额',
          position: 'center'
        })
        e.target.checked = false
        this.renling = false
        return
      }
      if (this.personalValue < 10) {
        this.$toast.show({
          text: '乐拼单金额不能小于10元',
          position: 'center',
          time: 3000
        })
        e.target.checked = false
        this.renling = false
        return
      }
      if (e.target.checked) {
        this.renling = true
        // 计算认领金额
        this.claimAmount = Math.ceil(this.personalValue * this.minClaimAmount)
      } else {
        this.renling = false
        // 计算认领金额
        this.claimAmount = ''
      }
    },
    onSwitch(e) {
      // 乐豆开关事件
      this.switchValue = !this.switchValue
      // // 显示抵扣乐豆
      localStorage.setItem('switchStatus', this.switchValue)
      if (this.switchValue) {
        this.payMoney()
        this.getEnableHappyCoin('1')
      } else {
        this.deductible = this.ledouBalance
        this.payBalance = this.personalValue
        this.getEnableHappyCoin('0')
      }
    },
    onCardSwitch(val) {
      // 储值卡开关事件
      this.cardSwitch = !this.cardSwitch
      if (val) {
        this.switchValue = false
      }
    },
    getEnableHappyCoin(num) {
      // 乐豆开关请求
      let param = {
        value: num
      }
      _api.enableHappyCoin(param).then((res) => {})
    },
    toGoPay() {
      // 确认支付/乐拼单事件
      if (this.btnDisabled) {
        return
      }
      // 个人买单支付跳转
      if (this.index === 0) {
        if (this.personalValue === '') {
          this.$toast.show({
            text: '请输入支付金额',
            position: 'center'
          })
          return
        }
        if (this.personalValue > 30000) {
          this.$toast.show({
            text: '单笔限额不能超过30000元',
            position: 'center'
          })
          return
        }

        if (this.cardSwitch) {
          if (!this.isSetPassword) {
            // 未设置密码
            this.confirmType = 1
            this.$refs.VConfirm.show('您尚未设置支付密码', {
              titleText: '',
              confirmText: '去设置',
              hideCancelBtn: true
            })
            return
          }
          this.$refs.cardPassword.show()
        } else {
          this.getWxpub_prePay()
        }
      }
      // 发起乐拼单跳转
      if (this.index === 1) {
        if (this.personalValue === '' || this.personalValue < 10) {
          this.$toast.show({
            text: '乐拼单金额不能小于10元',
            position: 'center'
          })
          return
        }
        if (this.personalValue > 5000) {
          this.$toast.show({
            text: '单笔限额不能超过5000元',
            position: 'center'
          })
          return
        }

        if (this.renling) {
          if (this.claimAmount > this.personalValue * this.maxClaimAmount) {
            this.$toast.show({
              text: '认领金额不能大于' + this.personalValue * this.maxClaimAmount + '元',
              position: 'center'
            })
            return
          }
          if (this.claimAmount < this.personalValue * this.minClaimAmount) {
            this.$toast.show({
              text: '认领金额不能小于' + this.personalValue * this.minClaimAmount + '元',
              position: 'center'
            })
            return
          }
        }
        this.gotoGroup()
      }
    },
    payMoney() {
      // 计算支付金额逻辑
      if (this.personalValue) {
        // 如果是香港环境
        if (this.isHongkong) {
          if (this.personalValue <= this.ledouBalance) {
            this.payBalance = 0
          } else if (this.personalValue > this.ledouBalance) {
            this.payBalance = (this.personalValue - this.ledouBalance).toFixed(2)
          }
        } else {
          if (this.ledouBalance === 0) {
            this.payBalance = this.personalValue
            return //无乐豆余额 不需要计算乐豆相关数据
          }
          // 输入金额小于或者等于乐豆余额的时候
          if (this.personalValue <= 1) {
            this.deductible = 0.0
            this.payBalance = this.personalValue
          } else if (this.personalValue - this.ledouBalance <= 1 || this.ledouBalance >= this.personalValue) {
            // 输入金额减去1之后小于等于乐豆余额时
            this.deductible = parseFloat(this.personalValue - 1).toFixed(2)
            this.payBalance = '1.00'
          } else {
            this.deductible = parseFloat(this.ledouBalance).toFixed(2)
            this.payBalance = parseFloat(this.personalValue - this.deductible).toFixed(2)
          }
        }
      } else {
        // 输入的金额为空时
        this.payBalance = 0
        this.deductible = 0
      }
    },
    personalValueChange(val) {
      // 消费金额赋值
      this.personalValue = val
    },
    claimAmountChange(val) {
      // 认领金额赋值
      this.claimAmount = val
    },
    getCardId() {
      // 获取商户充值卡id
      _api
        .findSingleCardGoodsByMerchantNo({
          merchantNo: this.merchantNo
        })
        .then((res) => {
          if (res.status == 1) {
            this.cardId = res.data && res.data.goodsInfoId
          }
        })
    },
    showRule() {
      // 显示乐拼单规则
      this.$refs.glpayRule.show()
    }
  },
  mounted() {
    this.bus.$emit('loading', true)
    window.history.pushState({ title: '商家扫码支付', url: window.location.href }, '商家扫码支付', '')
    window.addEventListener('popstate', function(e) {
      window.location.href = window.location.href
    })
  }
}
</script>
<style lang="scss">
body {
  margin: 0;
}
.localPay {
  background: #f5f5f5;
  width: 100%;
  height: 100%;
  min-height: 500px;
  overflow-y: auto;
  .m-view {
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    position: relative;
    z-index: 101;
  }
  // 支付方式
  .pay-method {
    // margin-top: 10px;
    .recharge {
      font-size: 12px;
      color: #ff6a00;
      text-decoration: underline;

      &.hide {
        visibility: hidden;
      }
    }
  }
  // 不可编辑消费金额输入框
  .input-readonly {
    width: 100%;
    height: 54px;
    line-height: 54px;
    border: 2px solid rgba(253, 107, 0, 1);
    border-radius: 10px;
    padding-right: 18px;
    font-size: 22px;
    text-align: right;
    box-sizing: border-box;
    color: #fe6900;
  }
  // 消费金额输入框&&获赠乐豆样式
  .localBox {
    .inputBox {
      padding: 10px 15px 2px;
      background: #fff;
      position: relative;
      &.spell {
        .numeric-input {
          border-color: #f5f5f5;
          background: #f5f5f5;
        }
      }
      .input-title {
        position: absolute;
        left: 30px;
        bottom: 5px;
        color: #fb6a00;
        font-size: 30px;
      }
      .spell-title {
        position: absolute;
        left: 30px;
        top: 24px;
        color: #666;
        font-size: 16px;
      }
    }
    // 获赠乐豆数
    .local-div {
      width: 100%;
      line-height: 40px;
      padding: 0 18px;
      background: #fff;
      box-sizing: border-box;
      span.local-tip:nth-child(1) {
        color: #333;
        font-size: 15px;
        font-weight: 400;
      }
      span.local-tip:nth-child(2) {
        color: #999;
        font-size: 12px;
        font-weight: 400;
        margin-left: 10px;
      }
      .dou {
        float: right;
        min-width: 58px;
        padding-right: 5px;
        height: 20px;
        border: 1px solid #ff6a00;
        line-height: 20px;
        border-radius: 4px;
        font-size: 10px;
        color: #ff6a00;
        margin-top: 8px;
        i {
          width: 20px;
          height: 20px;
          text-align: center;
          line-height: 20px;
          float: left;
          color: #fff;
          background: #ff6a00;
          font-size: 13px;
          margin-right: 5px;
        }
        span {
          font-size: 14px;
          color: #ff6a00;
          margin-left: inherit;
        }
      }
    }
  }
  // 乐拼单
  .localSpell {
    .renling-wrapper {
      background: #fff;
      margin-top: 10px;
      padding: 20px 0 30px;
    }
    .local-checkbox {
      padding-left: 20px;
      color: #fe6900;
      font-size: 12px;
      margin-top: 0px;
      .my_protocol {
        .input_agreement_protocol {
          appearance: none;
          -webkit-appearance: none;
          outline: none;
          display: none;
        }
        .input_agreement_protocol + span {
          width: 16px;
          height: 16px;
          background-color: red;
          display: inline-block;
          background: url(~@/assets/img/icon_gx_gray@2x.png) no-repeat;
          background-size: contain;
          position: relative;
          top: 3px;
          margin-right: 6px;
        }
        .input_agreement_protocol:checked + span {
          background: url(~@/assets/img/icon_lpd_gouxuan@2x.png) no-repeat;
          background-size: contain;
        }
      }
    }
    .input-wrap {
      position: relative;
      padding: 0 18px;
      box-sizing: border-box;
      margin-bottom: 10px;
      .input-title {
        position: absolute;
        left: 28px;
        bottom: 15px;
        color: #fb6a00;
      }
      .numeric-input {
        border-color: #fde4d4;
        background: #fde4d4;
      }
    }
    .localSpell-p {
      font-size: 12px;
      color: #999;
      padding-left: 15px;
      margin: 0px;
    }
  }
  // 支付按钮
  .local-pay-btn {
    width: 86%;
    background: #fff;
    position: fixed;
    bottom: 0;
    text-align: center;
    padding: 0 7%;
    p:nth-child(1) {
      text-align: center;
      color: #363636;
      font-size: 12px;
      margin-top: 12px;

      span {
        color: #a2a2a2;
        font-size: 12px;
        margin-left: 4px;

        &.sch5-question:before {
          color: #a2a2a2;
        }
      }
    }

    p.payMoney {
      font-size: 22px;
      color: #ff8305;
      margin-bottom: 4px;
    }

    button {
      width: 100%;
      height: 44px;
      background: linear-gradient(270deg, rgba(255, 143, 64, 1) 0%, rgba(255, 189, 64, 1) 100%);
      border-radius: 50px;
      margin: 0 auto;
      outline: none;
      border: none;
      margin-bottom: 32px;
      margin-top: 5px;
      color: #fff;
      font-size: 15px;

      &.disabled {
        opacity: 0.5;
      }
    }

    .lqd-tips {
      float: right;
      font-size: 12px;
      color: #ff6a00;
      text-decoration: underline;
      position: absolute;
      width: 90px;
      right: 20px;
      bottom: 8px;
    }
  }
}
</style>

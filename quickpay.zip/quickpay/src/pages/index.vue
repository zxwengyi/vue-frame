<template>
  <div>给乐生活扫码支付</div>
</template>
<script>

export default {
  name: 'home',
  components: {
  },
  data() {
    return {
      type: '',
      name: ''
    }
  },
  watch: {
  },
  created: function() {
    
  },
  methods: {
    // 执行下载APP广告状态隐藏
    
  },
  mounted() {
    
  }
}
</script>
<style lang="scss">
.mSyElastic {
 
}
</style>

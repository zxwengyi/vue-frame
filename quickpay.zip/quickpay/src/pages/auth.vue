<template>
  <div></div>
</template>
<script>
// import { setSessionStorage, getSessionStorage, getLocalStorage, setLocalStorage } from 'sa-common'
import { getCodeurl } from '@/api/index'
import { saBs } from '@/utils/base'

export default {
  name: 'auth',
  components: {
  },
  data() {
    return {
      type: '',
      name: '',
      querys: {},
    }
  },
  watch: {
  },
  created: function() {
    localStorage.setItem('initUrl', window.location.href)
    // this.getUrl()
    // this.gotoAuth()
  },
  methods: {
    // 旧的流程，从接口返回授权跳转的路径
    getUrl: function(){
      var par = this.$route.query
      debugger;
      if (par.qrcode) {
        par.cardVersion = 'v2'
        getCodeurl(par).then((res) => {
          // 喜欢状态查询
          if (res.data) {
            window.location.href = res.data;
          }else{
            console.log('授权失败')
          }
        })
      }else{
        alert('获取商家qrcode失败')
      }
    },
    getQuerys() {
      let url = this.$route.fullPath
      let queryStr = url.split('?')
      queryStr = queryStr && queryStr[1] ? queryStr[1] : ''
      let queryArr = queryStr.split('&')
      for (let i = 0; i < queryArr.length; i++) {
        let str = queryArr[i]
        let arr = str.split('=')
        this.querys[arr[0]] = arr[1]
      }
    },
    gotoAuth(){
      // quickpay/auth?qrcode=1707671000128 扫码支付访问地址
      // quickpay/auth?qrcode=1707671000128&outTokenId=11&outTokenType=11 B端系统套餐支付访问地址（包含outTokenId&&outTokenType）
      // quickpay/auth?payType=1&merchantNo=1707671000128&orderId=111 双渠道支付访问地址 （包含payType=1&orderId）
      let par = this.querys
      let code = par.qrcode || par.merchantNo
      let parArr = []
      for (let k in par) {
        if (k == 'qrcode' || k == 'merchantNo'){
         parArr.push(`qrcode=${par[k]}`)
        } else { // B端套餐支付会传outTokenId和outTokenType
          parArr.push(`${k}=${par[k]}`)
        }
      }
      let parStr = parArr.length ? '?' + parArr.join('&') : ''
      if (code) {
        let url = ''
        let redirect_uri = ''
        if (par.outTokenId && par.outTokenType) { // B端系统套餐支付
          redirect_uri = `${saBs.$locationLinkWX}/quickpay/systemPay${parStr}`
        } else {
          redirect_uri = `${saBs.$locationLinkWX}/quickpay/pay${parStr}`
        }
        let state =encodeURIComponent({
          merchantNo: par.qrcode || par.merchantNo,
          fromScan: par.fromScan
        })
        if (this.$client.ALIPAY) { // 支付宝授权
          url = `https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id=${saBs.$alipayAppid}&scope=auth_base&redirect_uri=${encodeURIComponent(redirect_uri)}&state=${state}`
        } else if (this.$client.WEIXIN) { // 微信授权
          url = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${saBs.$weixinAppid}&redirect_uri=${encodeURIComponent(redirect_uri)}&response_type=code&scope=snsapi_base&state=${state}#wechat_redirect`
        } else { // 云闪付授权
          url = `https://qr.95516.com/qrcGtwWeb-web/api/userAuth?version=1.0.0&redirectUrl=${encodeURIComponent(redirect_uri)}`
        }

        window.location.href=url

      }else{
        this.$toast.show({
            text: '商户号不能为空',
            position:'center'
        })
      }
      // let url1 = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${saBs.$weixinAppid}&redirect_uri=${redirect_uri}&response_type=code&scope=snsapi_userinfo&state=giftMall_#wechat_redirect`
    }
  },
  mounted() {
    this.getQuerys()
    this.gotoAuth()

  }
}
</script>
<style lang="scss">
</style>

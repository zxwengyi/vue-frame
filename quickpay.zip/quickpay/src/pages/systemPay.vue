<!-- B端系统套餐支付 -->
<template>
    <div class="localPay" style="transform: translateX(0px)">
        <div v-show="showView">
            <!-- 头部 -->
            <div class="localBox">
                <div class="inputBox">
                    <span class="input-title">￥</span>
                    <input readonly class="personInput" text-align="right" placeholder="请输入消费金额" type="text" @input="change(personalValue)"  v-model="personalValue" />
                </div>
                <div class="local-div local-pay-cash" @click="payMethod = 1" v-show="isWeixin">
                    <div class="pay-cash">
                        <span class="sch5-icon sch5-weixin"></span>
                        <span>微信支付</span>
                    </div>
                    <div class="pay-cash-img" :class="{active: payMethod == 1}">
                        <i class="i-circle"></i>
                        <i class="i-checked"></i>
                    </div>
                </div>
                <div class="local-div local-pay-cash" @click="payMethod = 2" v-show="isAlipay">
                    <div class="pay-cash">
                        <span class="sch5-icon sch5-alipay"></span>
                        <span>支付宝支付</span>
                    </div>
                    <div class="pay-cash-img" :class="{active: payMethod == 2}">
                        <i class="i-circle"></i>
                        <i class="i-checked"></i>
                    </div>
                </div>
              <div class="local-div local-pay-cash" @click="payMethod = 3" v-show="$client.UnionPay">
                <div class="pay-cash">
                  <span class="sch5-icon sch5-ysf"></span>
                  <span>银联云闪付</span>
                </div>
                <div class="pay-cash-img" :class="{active: payMethod == 2}">
                  <i class="i-circle"></i>
                  <i class="i-checked"></i>
                </div>
              </div>
            </div>
            <div class="local-pay-btn">
                <span class="pay-title">支付金额</span>
                <p>{{personalValue > 0 ? personalValue : 0}}元</p>
                <button @click="toGoPay">立即支付</button>
            </div>
        </div>
        <v-loading></v-loading>
        <v-confirm ref="VConfirm" @userBehavior="VConfirmClick"></v-confirm>
    </div>
</template>

<script>
import {prePay, queryOrderInfo, wxauth, weChatCredit, unionPayCredit, payType} from '@/api/index'
import { saBs } from '@/utils/base'
import axios from '@/utils/axios'
import VSwitch from '@/components/v_switch'
import VLoading from '@/components/v_loading'
import VConfirm from '@/components/v_confirm'
import { setCache, clearCache, setLocalStorage } from 'sa-common'

export default {
    name: 'localPay',
    components: {
       VSwitch,
       VLoading,
       VConfirm,
    },
    data (){
        return {
            loadingStep: 0,
            payMethod: '', // 支付方式 1|微信 2|支付宝
            showView: true,
            shopName: '', // 商户名称
            isWeixin: false,
            isAlipay: false,
            personalValue: ''
        }
    },
    created (){
        if (this.$client.WEIXIN) {
            this.payMethod = 1
            this.isWeixin = true
        } else if (this.$client.ALIPAY) {
            this.payMethod = 2
            this.isAlipay = true
        } else {
          this.payMethod = 3
        }
        clearCache("openId")
        clearCache('wxToken')
        this.getAuth();
        let bankUrl = location.href.split('?')[1]
        this.merchantNo = this.$route.query.merchantNo
        // this.getData();
    },
    methods:{
        VConfirmClick() {
            if (this.$client.WEIXIN) {
                WeixinJSBridge.invoke('closeWindow', {}, function(res) {});
            } else if (this.$client.ALIPAY) {
                AlipayJSBridge.call('closeWebview')
            }
            this.showView = true
        },
        getPayType() { //查询商家配置的支付渠道（weixin OR alipay）
            payType({merchantNo: this.merchantNo}).then(res => {
                if (res.result == '000000') {
                    if ((this.isWeixin && res.data.indexOf('weixin') < 0) || (this.isAlipay && res.data.indexOf('weixin') < 0)) {
                        this.$refs.VConfirm.show('暂不支持该种支付方式，<br>请尝试其他支付方式。', {
                            titleText: '',
                            confirmText: '知道了',
                            hideCancelBtn: true
                        })
                    } else {
                        this.showView = true
                    }
                }
            })
        },
        // hideLoading(){
        //     if(this.loadingStep){
        //         this.bus.$emit('loading', false);
        //     }else{
        //         this.loadingStep = 1
        //     }
        // },
        GetQueryString(url,name){
            var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
            // FIX ME:
            var r = url.match(reg);//search,查询？后面的参数，并匹配正则
            if(r!=null)return  unescape(r[2]); return null;
        },
        getAuth(){
            let query = this.$route.query
            query.merchantNo = query.merchantNo || query.qrcode
            let code = ''
            if (this.$client.WEIXIN) {
                code = query.code
            } else if (this.$client.ALIPAY) {
                code = query.auth_code
            } else {
              code = query.userAuthCode  // 云闪付
            }
            if(code){
              let getApi
              if (this.$client.UnionPay) {
                getApi = unionPayCredit({ code: code, officialAccountType: 'union', merchantNo: query.merchantNo })
              } else {
                getApi = weChatCredit({ code: code })
              }
              getApi.then((res) => {
                    let _data = res.data || { status: 0, data: {} }
                    if (_data.status === 1 && _data.data) {
                        query.openId = _data.data.openId
                        if (this.$client.WEIXIN) {
                            query.appId = saBs.$weixinAppid
                        } else if (this.$client.ALIPAY) {
                            query.appId = saBs.$alipayAppid
                        } else {
                          query.appId = ''
                        }
                        wxauth(query).then(result => {
                            console.log(result)
                            let userInfo = {
                                token: result.data.token,
                                userId: result.data.userId
                            }
                            this.openId = _data.data.openId
                            this.userId = result.data.userId
                            this.ledouBalance = result.data.beanBalance
                            this.operatorId = result.data.operatorId
                            this.unionId = result.data.unionId
                            this.noBenefitAmount = result.data.noBenefitAmount
                            this.terminal = result.data.terminal
                            setCache("openId", _data.data.openId);
                            setCache('wxToken', result.data.token)
                            setLocalStorage('userinfo', userInfo)
                            this.getData()
                            // this.hideLoading()
                        })
                    }
                })
            }

        },
        // 查询B端系统套餐订单详情
        getData (){
            let query = this.$route.query
            queryOrderInfo({
                outTokenId: query.outTokenId,
                outTokenType: 13
            }).then(res => {
                if(res.result === "000000"){
                    this.personalValue = res.data && res.data.totalAmount
                    this.getPayType()
                }else{
                    this.$toast.show({
                        text: res.description,
                        position:'center'
                    })
                }
                this.bus.$emit('loading', false);
            })
        },
        // 微信个人买单确认支付
        toGoPay (){
            let params = {
                'orderTitle': '系统套餐_消费',
                'totalAmount': this.personalValue,
                'operatorId': this.operatorId || '',
                'noBenefitAmount': this.noBenefitAmount || 0,
                'merchantNo': this.merchantNo,
                'paySence':  0,
                'scene': this.paySence || '',
                'terminal': this.terminal || '',
                "openId" : this.openId || '',
                "userId": this.userId || '',
                "outTokenId": this.$route.query.outTokenId,
                "outTokenType": 13
            }
            this.bus.$emit('loading', true)
            prePay(params).then(res =>{
                this.bus.$emit('loading', false)
                if(res.result === "000000" ){
                    let payInfo = JSON.parse(res.data.payInfo)
                    if (this.payMethod == 1) { // 微信支付
                        this.WxPlay(payInfo)
                    } else if (this.payMethod == 2) { // 支付宝支付
                        this.alipayFn(payInfo)
                    } else {
                      window.location.href = saBs.$locationLinkWX + '/index1.html' +  payInfo.callback_url;//支付成功后跳转处理
                    }
                }else{
                    this.$toast.show({
                        text: res.description,
                        position:'center'
                    })
                }
            })
        },
        alipayFn(data, errCallback) {
            var onBridgeReady = function () {
                AlipayJSBridge.call('tradePay', {
                    "tradeNO": data.tradeNO
                },
                function(result){
                    // 9000|订单支付成功 8000|正在处理中 4000|订单支付失败 6001|用户中途取消 6002|网络连接出错
                    if(result.resultCode == '9000'){
                        location.href = window.location.href = saBs.$locationLinkWX + '/index1.html' +  data.callback_url;//支付成功后跳转处理
                    } else if (result.resultCode != '8000') {
                        errCallback && errCallback(result)
                    }
                });
            }
            if (typeof WeixinJSBridge == "undefined") {
                if (document.addEventListener) {
                    document.addEventListener('AlipayJSBridgeReady', onBridgeReady, false);
                } else if (document.attachEvent) {
                    document.attachEvent('AlipayJSBridgeReady', onBridgeReady);
                    document.attachEvent('onAlipayJSBridgeReady', onBridgeReady);
                }
            } else {
                onBridgeReady();
            }
        },
        // 微信支付接口
        WxPlay (data){
            let _this = this
            let onBridgeReady = function(){
                WeixinJSBridge.invoke(
                    'getBrandWCPayRequest', {
                        "appId":data.appId,     //公众号名称，由商户传入
                        "timeStamp":data.timeStamp,         //时间戳，自1970年以来的秒数
                        "nonceStr":data.nonceStr, //随机串
                        "package":data.package,
                        "signType":data.signType,         //微信签名方式：
                        "paySign":data.paySign //微信签名
                    },
                    function(res){
                        if(res.err_msg == "get_brand_wcpay_request:ok" ) {
                            window.location.href = saBs.$locationLinkWX + '/index1.html' +  data.callback_url;
                        }
                    }
                );
            }
            if (typeof WeixinJSBridge == "undefined"){
                if( document.addEventListener ){
                    document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
                }else if (document.attachEvent){
                    document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
                    document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
                }
            }else{
                onBridgeReady();
            }
        },
    },
    mounted(){
        this.bus.$emit('loading', true);
        window.history.pushState({title:'商家扫码支付',url:window.location.href},"商家扫码支付","#")
        window.addEventListener("popstate",function(e){
            window.location.href=window.location.href
        })
    }
}
</script>
<style lang="scss">
    body{
        margin: 0;
    }
    .localPay{
        background: #F5F5F5;
        width: 100%;
        height: 100%;
        min-height: 500px;

        .localBox{
            .inputBox{
               padding: 10px 15px;
               margin-bottom: 10px;
               background: #fff;
               position: relative;
               .input-title{
                   position: absolute;
                   left: 30px;
                   top: 12px;
                   color:#FB6A00;
                   font-size: 30px;
               }
               .personInput{
                   width: 100%;
                   height: 54px;
                   border:2px solid rgba(253,107,0,1);
                   border-radius:10px;
                   padding-right: 18px;
                   font-size: 22px;
                   text-align: right;
                   box-sizing: border-box;
                   color: #fe6900;
                   outline: none;

                    -webkit-appearance: none; /*去除系统默认的样式*/

                    -webkit-tap-highlight-color: rgba(0, 0, 0, 0); /* 点击高亮的颜色*/
               }
               ::-webkit-input-placeholder { /* WebKit browsers */
                    color: #999;
                    font-size: 16px;
                }
                input:-moz-placeholder {
                    /* Mozilla Firefox 4 to 18 */
                    color: #666;
                }
                input::-moz-placeholder {
                    /* Mozilla Firefox 19+ */
                    color: #666;
                }
                input:-ms-input-placeholder {
                    /* Internet Explorer 10-11 */
                    color: #666;
                }
               .vux-no-group-title{
                   margin-top: 0;
               }
            }
            .local-div{
                width: 100%;
                // height: 50px;
                line-height: 40px;
                padding: 0 18px;
                background: #fff;
                box-sizing: border-box;
                span.local-tip:nth-child(1){
                    color: #333;
                    font-size: 15px;
                    font-weight: 400;
                }
                span.local-tip:nth-child(2){
                    color: #999;
                    font-size: 12px;
                    font-weight: 400;
                    margin-left: 10px;
                }
                .dou{
                    float: right;
                    min-width: 58px;
                    padding-right: 5px;
                    height: 20px;
                    border: 1px solid #FF6A00;
                    line-height: 20px;
                    border-radius: 4px;
                    font-size: 10px;
                    color: #FF6A00;
                    margin-top: 8px;
                    i{
                        width: 20px;
                        height: 20px;
                        text-align: center;
                        line-height: 20px;
                        float: left;
                        color: #fff;
                        background: #FF6A00;
                        font-size: 13px;
                        margin-right: 5px;
                    }
                    span{
                        font-size: 14px;
                        color: #FF6A00;
                        margin-left: inherit;
                    }
                }
            }
            // 现金支付
            .local-pay-cash{
                position: relative;
                .my_protocol:after{
                    display: block;
                    content: '';
                    clear: both;
                }
                img{
                    width: 16px;
                    height: 27px;
                    vertical-align: middle;
                    object-fit: cover;
                }
                .pay-cash{
                    color: #333;
                    font-size: 15px;
                    margin-left: 4px;
                    vertical-align: middle;
                }
                .pay-cash-img{
                    float: right;
                    .i-checked{
                        width: 20px;
                        height: 20px;
                        display: none;
                        font-size: 20px;
                        position: absolute;
                        background: url('~assets/img/checked.png');
                        background-size: contain;
                        top: 10px;
                        right: 18px;
                    }
                    .i-circle{
                        width: 18px;
                        height: 18px;
                        border-radius: 50%;
                        display: inline-block;
                        background: #EFF0F5;
                        border: solid 1px #E3E3E3;
                        position: absolute;
                        top: 10px;
                        right: 18px;
                    }
                    &.active{
                        .i-checked{
                            display: inline-block;
                        }
                        .i-circle{
                            display: none;
                        }
                    }
                }
                    .sch5-weixin{
                       font-size: 20px;
                       vertical-align: middle;
                       margin-right: 8px;
                       display: inline-block;
                       width: 20px;
                       height: 20px;
                       background: url(~@/assets/img/icon_wechat@2x.png) no-repeat;
                       background-size: contain;
                       vertical-align: middle;
                    }
                .sch5-alipay{
                        display: inline-block;
                        width: 20px;
                        height: 20px;
                        background: url(~@/assets/img/icon_zhifubao@2x.png) no-repeat;
                        background-size: contain;
                        vertical-align: middle;
                        margin-right: 8px;
                    }
                .input_agreement_protocol{
                    display: none;
                }
                .radioClass{
                    position: absolute;
                    top: 16px;
                    right: 18px;
                    width: 24px;
                    height: 24px;
                    background: url(~@/assets/img/yizhifu.png) no-repeat;
                    background-size: contain;
                    vertical-align: middle;
                }
                .weui-icon-circle{
                    color: #E3E3E3;
                }
            }
            .local-pay-box:after{
                border-bottom: 0;
            }
        }
        // 支付按钮
        .local-pay-btn{
            width: 100%;
            background: #fff;
            position: fixed;
            bottom: 0;
            text-align: center;
            .pay-title{
                font-size: 14px;
                color: #000;
                display: inline-block;
                margin-top: 6px;
            }
            p:nth-child(1){
                text-align: center;
                color: #FF8305;
                font-size: 22px;
                margin-top: 12px;
                span{
                    color: #A2A2A2;
                    font-size: 12px;
                    margin-left: 4px;
                    &.sch5-question:before{
                        color: #A2A2A2;
                    }
                }
            }
            p:nth-child(2){
                font-size: 26px;
                color: #FF8305;
                margin-bottom: 9px;
                margin-top: 0;
            }
            button {
                width: 335px;
                height: 44px;
                background:linear-gradient(270deg,rgba(255,143,64,1) 0%,rgba(255,189,64,1) 100%);
                border-radius: 50px;
                margin: 0 auto;
                outline: none;
                border: none;
                margin-bottom: 33px;
                color: #fff;
                font-size: 15px;
            }
        }
    }
</style>

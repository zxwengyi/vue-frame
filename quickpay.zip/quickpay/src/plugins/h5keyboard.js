/*
 * @Author: HotSuitor
 * @Date: 2019-09-17 11:38:35
 * @LastEditors: hs
 * @LastEditTime: 2019-09-17 12:28:35
 * @Description: hotsuitor@qq.com
 */
import H5Keyboard from '../components/keyboard.vue'

// TODO: 原生虚拟键盘插件
class VueH5KeyboardPlugin {
  install(Vue, options) {
    let keyboard = this
    // Vue.mixins(
    //   created() {
    //     this.$keyboard = keyboard
    //   }
    // )
      Vue.extends(H5Keyboard)
  }
}

const vueH5KeyboardPlugin = new VueH5KeyboardPlugin()
export default vueH5KeyboardPlugin

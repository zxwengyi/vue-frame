const saBs = {} // 基础功能

// 全局参数
saBs.$sitePath = '/'
saBs.$time = new Date()
saBs.$timeStr = '.r' + ('00' + saBs.$time.getHours()).substr(-2, 2) + ('00' + saBs.$time.getMinutes()).substr(-2, 2)
saBs.$version = '1.0.0'
saBs.$appVersion = '6.5.5' // App版本号

saBs.$weixinAppid = 'wx870a19ad52623f20' // 授权登录，开发者帐号appid
saBs.$alipayAppid = '2019101168313485' // 支付宝授权登录appid
saBs.$wxDebug = false // 微信jssdk的debug模式
saBs.$env = process.env.NODE_ENV // 环境
// saBs.$version = process.env.VERSION // 应用版本
// saBs.$debugIDs = ['45897b53660a4374b885066b2eb601f5', '6381f78302b142028438af3006166bd8']
saBs.$debugIDs = ['oyfG65kYYzamy5iwD6HqUaX2_Jqk', 'oyfG65mjtv-aYO4MznBK3btMIxx8']

// 开发环境
saBs.$locationLink = `http://127.0.0.1:8888${process.env.ROUTER_MODE === 'hash' ? '/#' : ''}`
saBs.$locationLinkWX = `http://127.0.0.1:8888`
saBs.$serverLinkWX = `http://192.168.0.145:18082/kstore/mobile/wx/code/redirect`
// 畅由注册地址
saBs.$cyRegisterLink = `https://test-m-stg.ppppoints.com/event/finance/blankPage/index.html` // 测试环境 (只提供了测试环境和生成环境)
saBs.$cyPartnerId = 'S1000509' // 畅由提供的商户编号,跳转畅由注册地址需要带过去(测试和生产都是同一个)
saBs.$cySecretKey = '123456' // 畅由商户密钥 跳转注册页需要(生产环境秘钥线下定期或不定期提供)

saBs.$apiServer = {
  node: '/nodeapi', // 商城nodeapi
  mock: '/mockapi/app/mock/18', // moke接口
  cMock: 'http://192.168.0.169:18286', // cfront moke接口

  sc_to: '/toolapi', // 商城java接口toolapi
  sc_h5: '/javaapi', // 商城java接口
  glsh_c: '/lifeapi', // 给乐生活C端接口,
  glsh_wx: '/lifeapi/wxpub', // 给乐生活wxpub接口

  xldn: 'https://192.168.0.136:8093',
  imh5: 'http://192.168.0.103:2001', // 聊天客服
  baiduAk: {
    // 百度API
    ak: 'YQ6Mfwo6oQMdzDSTlNN7xQuGldYBevPP',
    id: '192242'
  },
  baiduUrl: 'https://api.map.baidu.com/geosearch/v3/nearby',
  thirdAppId: {
    qq: '101575392'
  }
}
if (process.env.NODE_ENV === 'production_dev' || process.env.NODE_ENV === 'production_app_dev') {
  // 开发联调环境
  saBs.$version += saBs.$timeStr
  saBs.$weixinAppid = 'wxe8ba098bd98baba0' // 授权登录，开发者帐号appid 给乐生活测试号
  saBs.$alipayAppid = '2019101168313485' // 支付宝授权登录appid
  saBs.$locationLink = `https://sch5-dev.365gl.com${process.env.ROUTER_MODE === 'hash' ? '/#' : ''}`
  saBs.$locationLinkWX = `https://sch5-dev.365gl.com`
  saBs.$serverLinkWX = `https://loclife-dev.365gl.com/kstore/mobile/wx/code/redirect`
  saBs.$apiServer = {
    node: 'https://h5api-test.365gl.com', // 商城nodeapi
    mock: 'https://rap2.365gl.com:8000/app/mock/18', // moke接口
    cMock: 'http://192.168.0.169:18286', // cfront moke接口

    // 测试环境
    sc_to: 'https://t.365gl.com', // 短连接压缩接口的域名
    // sc_h5: 'http://192.168.0.62:18082', // 商城java接口
    // glsh_c: 'http://192.168.0.62:18082', // 给乐生活C端接口
    sc_h5: 'https://loclife-dev.365gl.com', // 商城java接口
    glsh_c: 'https://loclife-dev.365gl.com', // 给乐生活C端接口
    glsh_wx: 'https://pay.365gl.com/quick/devtest/wxauth/v2', // 给乐生活wxpub接口

    imh5: 'https://guest-test.365gl.com', // 聊天客服
    baiduAk: {
      // 百度API
      ak: 'YQ6Mfwo6oQMdzDSTlNN7xQuGldYBevPP',
      id: '192242'
    },
    baiduUrl: 'https://api.map.baidu.com/geosearch/v3/nearby',
    thirdAppId: {
      qq: '101575392'
    }
  }
} else if (process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_app_test') {
  // 测试环境
  saBs.$version += saBs.$timeStr
  saBs.$weixinAppid = 'wx870a19ad52623f20' // 授权登录，开发者帐号appid 给乐生活测试号
  saBs.$alipayAppid = '2019101168285499' // 支付宝授权登录appid
  saBs.$locationLink = `https://scapi-test.365gl.com${process.env.ROUTER_MODE === 'hash' ? '/#' : ''}`
  saBs.$locationLinkWX = `https://scapi-test.365gl.com`
  saBs.$serverLinkWX = `https://loclife.365gl.com/kstore/mobile/wx/code/redirect`
  saBs.$apiServer = {
    node: 'https://h5api-test.365gl.com', // 商城nodeapi
    mock: 'https://rap2.365gl.com:8000/app/mock/18', // moke接口
    cMock: 'http://192.168.0.169:18286', // cfront moke接口

    // 测试环境
    sc_to: 'https://t.365gl.com', // 短连接压缩接口的域名
    sc_h5: 'https://loclife.365gl.com', // 商城java接口
    glsh_c: 'https://loclife.365gl.com', // 给乐生活C端接口
    glsh_wx: 'https://pay.365gl.com/quick/loctest/wxauth/v2', // 给乐生活wxpub接口

    imh5: 'https://guest-test.365gl.com', // 聊天客服
    baiduAk: {
      // 百度API
      ak: 'YQ6Mfwo6oQMdzDSTlNN7xQuGldYBevPP',
      id: '192242'
    },
    baiduUrl: 'https://api.map.baidu.com/geosearch/v3/nearby',
    thirdAppId: {
      qq: '101575392'
    }
  }
} else if (process.env.NODE_ENV === 'production_uat' || process.env.NODE_ENV === 'production_app_uat') {
  // 测试环境
  saBs.$version += saBs.$timeStr
  saBs.$weixinAppid = 'wx250b902e56a43323' // 授权登录，开发者帐号appid 给乐生活测试号
  saBs.$alipayAppid = '2019101168285499' // 支付宝授权登录appid
  saBs.$locationLink = `https://scapi-uat.365gl.com${process.env.ROUTER_MODE === 'hash' ? '/#' : ''}`
  saBs.$locationLinkWX = `https://scapi-uat.365gl.com`
  saBs.$serverLinkWX = `https://test.365gl.com/cfront/kstore/mobile/wx/code/redirect`
  saBs.$apiServer = {
    node: 'https://h5api-test.365gl.com', // 商城nodeapi
    mock: 'https://rap2.365gl.com:8000/app/mock/18', // moke接口
    cMock: 'http://192.168.0.169:18286', // cfront moke接口

    // 测试环境
    sc_to: 'https://t.365gl.com', // 短连接压缩接口的域名
    sc_h5: 'https://test.365gl.com/cfront', // 商城java接口
    glsh_c: 'https://test.365gl.com/cfront', // 给乐生活C端接口
    glsh_wx: 'https://pay.365gl.com/quick/locuat/wxauth/v2', // 给乐生活wxpub接口

    imh5: 'https://guest-uat.365gl.com', // 聊天客服
    baiduAk: {
      // 百度API
      ak: 'YQ6Mfwo6oQMdzDSTlNN7xQuGldYBevPP',
      id: '192242'
    },
    baiduUrl: 'https://api.map.baidu.com/geosearch/v3/nearby',
    thirdAppId: {
      qq: '101583568'
    }
  }
} else if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_app') {
  // 生产环境
  // saBs.$weixinAppid = 'wx07213139a2987663' // 授权登录，开发者帐号appid 给乐商家
  saBs.$weixinAppid = 'wxf290902fec0f2fe5' // 授权登录，开发者帐号appid 给乐生活
  saBs.$alipayAppid = '2017090708604149' // 支付宝授权登录appid
  saBs.$locationLink = `https://m.365gl.com${process.env.ROUTER_MODE === 'hash' ? '/#' : ''}`
  saBs.$locationLinkWX = `https://m.365gl.com`
  saBs.$serverLinkWX = `https://life.365gl.com/kstore/mobile/wx/code/redirect`
  // 畅由注册地址
  saBs.$cyRegisterLink = `https://m.changyoyo.com/event/finance/blankPage/index.html` // 生产环境 (只提供了测试环境和生成环境)
  saBs.$cySecretKey = 'znuMpJlDA0MR3Ia5qmr3xAIVdf6SNIxL' // 畅由商户密钥 跳转注册页需要

  saBs.$apiServer = {
    node: 'https://h5api.365gl.com', // 商城nodeapi
    mock: 'https://rap2.365gl.com:8000/app/mock/18', // 商城moke接口
    cMock: 'http://192.168.0.169:18286', // cfront moke接口

    sc_to: 'https://t.365gl.com', // 短连接压缩接口的域名
    sc_h5: 'https://life.365gl.com', // 商城java接口
    glsh_c: 'https://life.365gl.com', // 给乐生活C端接口
    glsh_wx: 'https://pay.365gl.com/quick/prod/wxauth/v2', // 给乐生活wxpub接口

    imh5: 'https://im-wx.365gl.com', // 聊天客服
    baiduAk: {
      // 百度API
      // ak: '5c386b41caecdd8f9003871d2660ef2d',
      // id: '172778'
      ak: 'hEbCHFklzlNWe43gA7gAgxv2',
      id: '192684'
    },
    baiduUrl: 'https://api.map.baidu.com/geosearch/v3/nearby',
    thirdAppId: {
      qq: '101588350'
    }
  }
}

saBs.$api = {
  registerForTransfer: `${saBs.$apiServer.glsh_wx}/wxpubApi/user/registerForTransfer`, // 给乐商家账号迁移 老用户绑定手机

  // 微信相关
  getIp: `${saBs.$apiServer.node}/getip`, // get方法
  getJssdkConfig: `${saBs.$apiServer.node}/weixin/jssdk`, // post方法
  weChatCredit: `${saBs.$apiServer.sc_h5}/kstore/mobile/CreditController/weChatCredit`, // 通过微信code获取openid
  weChatCreditForShop: `${saBs.$apiServer.sc_h5}/kstore/mobile/CreditController/weChatCreditForShop`, // 通过微信code获取openid
  weChatJsSDK: `${saBs.$apiServer.sc_h5}/kstore/mobile/CreditController/weChatJsSDK`, // jssdk授权
  updateGoodsStatus: `${saBs.$apiServer.sc_h5}/kstore/mobile/gl/link/updateGoodsStatus`, // 转赠link分享完成（更新礼品状态）
  wxQueryMerchantInfoLBS: `${saBs.$apiServer.glsh_c}/wxpubApi/merchant/queryMerchantInfoLBS`, // 公众号 获取百度云接口
  appQueryMerchantInfoLBS: `${saBs.$apiServer.glsh_c}/lifeAPI/merchant/queryMerchantInfoLBS`, // APP 获取百度云接口
  getcommonPay: `${saBs.$apiServer.glsh_c}/lifeAPI/wxPay/commonPay` /* 小程序 */,
  checkToken: `${saBs.$apiServer.glsh_wx}/wxpubApi/t/validate` /* 校验微信token是否有效 */,
  wxauth: `${saBs.$apiServer.glsh_c}/lifeAPI/user/auth/v2`,
  unionPayCredit: `${saBs.$apiServer.glsh_wx}/wxpubApi/officialAccountCode2Session`, // 云闪付授权获取userid
//   乐拼单相关
  getBalance: `${saBs.$apiServer.glsh_wx}/wxpubApi/happyCoin/getBalance`, //查询乐豆余额
  rlAmountPro: `${saBs.$apiServer.glsh_wx}/wxpubApi/groupManagement/rlAmountPro`, //查询乐拼单认领金额占比
  commonPay: `${saBs.$apiServer.glsh_c}/lifeAPI/wxPay/commonPay`, //个人买单确认支付
  buildGroup: `${saBs.$apiServer.glsh_c}/lifeAPI/groupManagement/buildGroup`, //个发起乐拼单
  wxpub_prePay: `${saBs.$apiServer.glsh_wx}/wxpubApi/payment/wxpub_prePay`, //微信个人支付
  prePay: `${saBs.$apiServer.glsh_wx}/wxpubApi/payment/prePay`, //微信扫码个人支付
  enableHappyCoin: `${saBs.$apiServer.glsh_wx}/wxpubApi/user/enableHappyCoin`, //是否利用乐豆支付
  getCodeUrl4UserInfo: `${saBs.$apiServer.glsh_wx}/wxpubApi/getCodeUrl4UserInfo`, //微信扫码乐拼单
  merchantDetail: `${saBs.$apiServer.glsh_c}/lifeAPI/merchant/queryMerBaseInfo`, //商家详情
  merchant: `${saBs.$apiServer.glsh_c}/lifeAPI/merchant/detail`, //查询乐拼单商品详情
  payType  : `${saBs.$apiServer.glsh_c}/lifeAPI/payment/payType`, //查询商家配置的支付渠道（weixin OR alipay）
  queryBind: `${saBs.$apiServer.glsh_wx}/wxpubApi/user/queryBind`, // 判断用户是否绑定手机
  queryOrderInfo: `${saBs.$apiServer.glsh_c}/lifeAPI/wxPay/outOrder/queryOrderInfo`, // 查询第三方订单详情(B端系统套餐购买)
  getCheckToken: `${saBs.$apiServer.glsh_c}/lifeAPI/payPassword/getCheckToken`, // 获取验证支付密码Token
  isPayPassword: `${saBs.$apiServer.glsh_c}/lifeAPI/payPassword/isPayPassword`, // 是否已设置支付密码
  findSingleCardGoodsByMerchantNo: `${saBs.$apiServer.sc_h5}/kstore/mobile/gl/mobileGoods/findSingleCardGoodsByMerchantNo`, // 根据商户号查询储值卡id
  queryPayOrderInfo: `${saBs.$apiServer.glsh_c}/lifeAPI/wxPay/outOrder/queryPayOrderInfo`, // 根据C扫B返回tokenId查询订单信息


  // 微信授权相关
  getCodeurl: `${saBs.$apiServer.glsh_wx}/wxpubApi/getCodeUrl4OpenId`,

  // 绑定手机号相关
  wxpubApiverifySms: `${saBs.$apiServer.glsh_wx}/wxpubApi/sms/verifySms`, // 检验验证码
  userregister: `${saBs.$apiServer.glsh_wx}/wxpubApi/user/register`, // 引导注册
  info: `${saBs.$apiServer.glsh_c}/lifeAPI/user/info`, // 获取个人信息
  wxpubApisendSms: `${saBs.$apiServer.glsh_wx}/wxpubApi/sms/sendSms`, // 发送验证码
  sendSms: `${saBs.$apiServer.glsh_c}/lifeAPI/sms/sendSms`, // 发送验证码

  // 畅由相关接口
  checkCyBind: `${saBs.$apiServer.sc_h5}/lifeAPI/cy/checkCyBind`, // 查询用户是否绑定畅游会员
  updateCyFlag:`${saBs.$apiServer.sc_h5}/lifeAPI/cy/updateCyFlag`, // 修改畅游相关协议标志
  queryCmccPoints:`${saBs.$apiServer.sc_h5}/lifeAPI/cy/queryCmccPoints`, // 移动积分及兑换比例查询
  cmccSmsOrder:`${saBs.$apiServer.sc_h5}/lifeAPI/cy/cmccSmsOrder`, // 移动兑换下单接口
  sendCmccSms:`${saBs.$apiServer.sc_h5}/lifeAPI/cy/sendCmccSms`, // 移动短信下发接口
  addPoints:`${saBs.$apiServer.sc_h5}/lifeAPI/cy/addPoints`, // 移动兑分接口
  cyUserRegister: `${saBs.$apiServer.sc_h5}/lifeAPI/cy/userRegister`, // 关联畅由用户接口
  beanAmount: `${saBs.$apiServer.sc_h5}/lifeAPI/payment/user/beanAmount`, // 获取用户纯乐豆余额（用于畅由授权弹窗展示）
  notifyCyUserBind: `${saBs.$apiServer.sc_h5}/lifeAPI/cy/notifyCyUserBind`, // 通知后端绑定畅由会员成功

  getIpAddress: `${saBs.$apiServer.sc_h5}/lifeAPI/user/getIpAddress` // 获取用户ip地址

}

export { saBs }


import { getCache, getLocalStorage } from 'sa-common'
import { saBs } from '@/utils/base'

// 获取客户端ip
export const getUserIP = function (onNewIP) {
  let MyPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
  let pc = new MyPeerConnection({
    iceServers: []
  })
  let noop = () => {};
  let localIPs = {};
  let ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g;
  let iterateIP = (ip) => {
    if (!localIPs[ip]) onNewIP(ip);
    localIPs[ip] = true;
  }
  pc.createDataChannel('');
  pc.createOffer().then((sdp) => {
    sdp.sdp.split('\n').forEach(function (line) {
      if (line.indexOf('candidate') < 0) return;
      line.match(ipRegex).forEach(iterateIP);
    })
    pc.setLocalDescription(sdp, noop, noop);
  }).catch((reason) => {})
  pc.onicecandidate = (ice) => {
    if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
    ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
  }
}

/**
 * 返回畅由注册跳转链接
 */
export const returnCyRegisterLink = function (_this, ledouBalance) {
  let userinfo = getLocalStorage('userinfo')
  let userip = getLocalStorage('userip')
  let info = getCache('information')
  // ipAddress IP地址
  // partnerId 商户编号
  // requestId 商户请求号 (reqTime+随机生成的5位数数字)
  // reqTime 请求时间
  // mobile是用户手机号，
  // glUserId是用户唯一标识，
  // transTime给乐余额查询时间
  // cyldAmt给乐积分余额，
  // callbackUrl是回调地址，要encode后带过来 不然后面的参数会丢失
  // hmac 签名数据
  let strArr = []
  let reqTime = new Date().getTime()
  let url = '/quickpay' + _this.$route.fullPath
  if (url.indexOf('?') > -1) {
    // url = url + '&' + `mobile=${info.mobilePhone}&cyregister=1&cyrReturn=`
    url += '&'
  } else {
    // url = url + '?' + `mobile=${info.mobilePhone}&cyregister=1&cyrReturn=`
    url += '?'
  }
  url += 'cyregister=1&cyrReturn='
  let obj = {
    callbackUrl: encodeURIComponent(`${saBs.$locationLinkWX}${url}`),
    cyldAmt: String(parseFloat(_this._multiplicationFn(ledouBalance, 100))) || '0',
    glUserId: userinfo.userId,
    ipAddress: userip || '192.168.1.138',
    mobile: info.mobilePhone,
    partnerId: saBs.$cyPartnerId,
    reqTime: reqTime,
    requestId: reqTime + parseInt(Math.random()*100000),
    transTime: new Date(reqTime).Format('yyyyMMddhhmmss'),
    key: saBs.$cySecretKey
  }
  for (let k in obj) {
    if (obj[k]) strArr.push(`${k}=${obj[k]}`)
  }
  let string = strArr.join('&')
  let hmac = _this.$md5(string)
  let link = `${saBs.$cyRegisterLink}?${string}&hmac=${hmac}`
  return link
}
// import { delLocalStorage, getLocalStorage, setLocalStorage, setSessionStorage, setCache, getCache, clearCache, enWxJumpLink, deWxJumpLink } from 'sa-common'
// import { saBs } from '@/utils/base'
// // import store from '@/store/store'
// import qs from 'qs'
// // import { info } from '@/api/login'
// import { getBargainSign } from '@/api/bargain'
// // import { getLinks, executeBask } from '@/api/giftMall' // getLinks|加入分享计划， executeBask|执行晒单
// import { getRlAmountPro, qrCodeInGroup } from '@/api/index'
// // import { toSender, createDx } from '@/api/userCenter/lib'
// import { isClose } from '@/api/userCenter'
// // import { weChatJsSDK, updateGoodsStatus } from '@/api/giftShare/index'

// const ok = '000000'
// let HandleRedirect = function (_this) {
//   let query = _this.$route.query
//   if (!query.url) {
//     // if (_this.$client.GLSH_APP && flag && history.length > 1) {
//     //   // flag：注册、忘记密码、微信登录=false 登录=true
//     //   // 原生APP
//     //   history.back()
//     // } else {
//     if (_this.$client.WEIXIN) {
//       window.location.href = '/'
//     } else {
//       _this.$router.push({ name: 'home' })
//     }
//     // }
//   } else if (/^-?[1-9]\d*$/.test(query.url)) {
//     _this.$router.go(parseInt(query.url, 10))
//   } else if (query.url.indexOf('http') === 0) {
//     // 浏览器打开--有配置http地址
//     if (query.url.indexOf(saBs.$locationLinkWX) >= 0) {
//       self.location.href = query.url
//     } else {
//       console.log('非本站域名跳转到首页')
//       self.location.href = saBs.$locationLinkWX
//     }
//   } else if (query.url.indexOf('~') > -1) {
//     // 浏览器打开--有配置经过enWxJumpLink和qs编码的router对象
//     let routeObj = qs.parse(deWxJumpLink(decodeURIComponent(query.url)))
//     _this.$router.push(routeObj)
//   } else if (query.url.indexOf('name=') > -1 || query.url.indexOf('name%3D') > -1) {
//     // 浏览器打开--有配置经过enWxJumpLink和qs编码的router对象
//     let routeObj = qs.parse(query.url)
//     _this.$router.push(routeObj)
//   } else {
//     // 浏览器打开--有配置路由名称
//     if (_this.$client.WEIXIN) {
//       let url = '/' + query.url.replace(/-/g, '/')
//       window.location.href = url + '?' + setParam(query.r)
//     } else {
//       if (query.qry) {
//         let qry = JSON.parse(query.qry)
//         _this.$router.push({
//           name: query.url,
//           query: qry.query,
//           params: qry.params
//         })
//       } else {
//         _this.$router.push({
//           name: query.url,
//           query: {
//             r: query.r
//           }
//         })
//       }
//     }

//   } /* else {
//     // 浏览器打开--没有配置跳转地址
//     let href = 'index1.html?v=' + saBs.$version
//     if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev') {
//       href = location.origin + '/index1.html#/store_list//?v=' + saBs.$version
//     }
//     window.location.href = href
//   } */
// }

// export const getIsClose = function ({ _this, data }, callback) {
//   isClose(`?orderPresentId=${data.orderPresentId}`).then(e => {
//     if (!e.data.closed) {
//       callback && callback(true)
//     } else {
//       _this.$vux.toast.text(e.data.message)
//     }
//   })
// }

// // 获取击鼓传花加密接口请求参数
// export const getBargainEncParams = function (link, shareType) {
//   let typeObj = { // key通过路径参数shareType获取，value为需要传给后台分享渠道对应的值 0|微信 1|PC 2|qq 3|weibo 4|momo 5|乐友
//     1: 0, // 微信
//     2: 0, // 微信朋友圈
//     3: 2, // qq
//     4: 1, // 短信
//     5: 3, // 新浪微博
//     6: 4, // 陌陌
//     7: 1, // 复制链接
//     8: 5 // 乐友
//   }
//   let shareId = ''
//   let userId = ''
//   let type = typeObj[shareType] != undefined ? typeObj[shareType] : 1
//   let urlhead = 'url=' + saBs.$locationLinkWX
//   let lArr = link.split(urlhead)
//   let rUrl = lArr && lArr[1]
//   rUrl = rUrl.split('?')[1]
//   rUrl = rUrl.split('=')[1]
//   let rArr = rUrl ? rUrl.split('_') : ''
//   for (let i = 0; i < rArr.length; i++) {
//     let str = rArr[i]
//     if (str.indexOf('si') > -1) {
//       shareId = str.replace('si', '')
//     }
//     if (str.indexOf('uri') > -1) {
//       userId = str.replace('uri', '')
//     }
//   }
//   return {
//     channelFlag: type,
//     shareId: shareId
//   }
// }
// /*晒单/邀约分享*/
// export const shareOrderFn = async function ({ _this, datas }, callback, beforeglscallback, needShareType, wxCallback) {
//   /**
//   * @param {datas} 晒单/邀约分享所需数据
//   * {
//   *   goodsInfoId: '货品id',
//   *   goodsInfoName: '商品标题',
//   *   goodsSubtitle: '商品副标题',
//   *   goodsInfoImgId: '商品图片链接',
//   *   activityType: '活动类型 4|晒单 5|邀约',
//   *   baskMaxHappybean: '单次最大晒单获豆',
//   *   likeMinHappybean: '单次最小点赞获豆',
//   *   likeMaxHappybean: '单次最大点赞获豆',
//   *   goodsId: 'spuid', // 加入邀约计划请求需要传
//   *   genHappybean: '单次邀约成功获豆', //
//   *   baskNickId: '', // 晒单需传字段
//   *   bothParticipation: false // 是否同时参与晒单和邀约 
//   *   isBask: 0, // 是否已晒过单 0|否 1|是 如果已晒过单就不再请求执行晒单服务
//   *   isGoods: 0 // 是否需要显示分享引导页 1|不需要 0|需要
//   *   noReset：0  // 分享成功后是否需要做jdk签名动作 1|不需要 0|需要
//   *   isShareDetail: '', // 是否是晒单详情页
//   *   customerNickName: '' // 晒单人昵称（晒单详情微信分享用到）
//   * }
//   * @method callback app分享成功回调（app分享）
//   * @method beforeglscallback 选择分享渠道回调（app分享）
//   * @method needShareType 是否需要在链接上拼接分享渠道（app分享）已经写死成true了~~
//   * @method wxCallback 微信分享成功回调（微信分享）
//   */
//   datas = JSON.parse(JSON.stringify(datas))
//   datas.baskMaxHappybean = datas.baskMaxHappybean || datas.baskMaxHappyBean
//   datas.likeMaxHappybean = datas.likeMaxHappybean || datas.likeMaxHappyBean
//   datas.likeMinHappybean = datas.likeMinHappybean || datas.likeMinHappyBean
//   _this.$vux.loading.show()
//   let userInfo = getCache('information')
//   let _token = getCache('Token') || {}
//   let link = datas._shareLinks || ''
//   let meg = ''
//   let shareViewTips = ''
//   let shareViewTitle = ''
//   let desc = ''
//   let shareurname = ''

//   if (datas.isShareDetail) { // 晒单详情页
//     shareurname = datas.customerNickName || ''
//   } else {
//     shareurname = userInfo && userInfo.nickName ? userInfo.nickName : ''
//   }

//   // 执行晒单
// //   if (datas.activityType == 4 && datas.isBask != 1) {
// //     let res = await executeBask({ baskNickId: datas.baskNickId })
// //     if (res.status != 1) {
// //       _this.$vux.loading.hide()
// //       return
// //     }
// //   }

//   // 加入邀约计划
//   if (datas.bothParticipation || datas.activityType == 5) {
//     if (!datas.goodsId) {
//       _this.$vux.toast.show({
//         text: '缺少参数goodsId',
//         type: 'text',
//         width: '7em'
//       })
//     }

// //     let res = await getLinks({ goodsId: datas.goodsId })
// //     if (res.data.status == 1) {
// //       datas.genNo = res.data.data && res.data.data.genNo
// //     } else {
// //       _this.$vux.loading.hide()
// //       return
// //     }
// //   }
// //   _this.$vux.loading.hide()
  
//   if (datas.activityType == 4) {
//     link = link || `${saBs.$locationLinkWX}/weixin/auth?url=${saBs.$locationLinkWX}/userCenter/shareOrder/detail/${datas.baskNickId}?r=promotionId${datas.genNo || ''}_uri${_token.userId}`
//     meg = `${shareurname ?'【' + shareurname + '】' : ''}邀您给我新购买的宝贝点赞，可最多获赠${datas.likeMaxHappybean}乐豆 {links}`
//     // shareViewTips = `<p style="color:#999;">每得到1个好友点赞，\n您获赠<span style="color:#ff6a01;">${datas.baskMaxHappybean}</span>乐豆，好友${datas.likeMaxHappybean > datas.likeMinHappybean ? '随机' : ''}赠${datas.likeMinHappybean}${datas.likeMaxHappybean > datas.likeMinHappybean ? '~' + datas.likeMaxHappybean : ''}乐豆！</p>`
//     shareViewTips = `每得到1个好友点赞，\n您获赠${datas.baskMaxHappybean}乐豆，好友${datas.likeMaxHappybean > datas.likeMinHappybean ? '随机' : ''}赠${datas.likeMinHappybean}${datas.likeMaxHappybean > datas.likeMinHappybean ? '~' + datas.likeMaxHappybean : ''}乐豆！`
//     shareViewTitle = `获赠${datas.baskMaxHappybean}乐豆`
//     desc = `【1乐豆价值1元】\n${datas.goodsInfoName}`
//   } else {
//     link = `${saBs.$locationLinkWX}/weixin/auth?url=${saBs.$locationLinkWX}/giftMall/detail/${datas.goodsInfoId}?r=promotionId${datas.genNo || ''}_uri${_token.userId}`
//     meg = 'Hi，我在给乐生活发现一款很赞的礼品，送人送自己都很不错哦； {links} 赶快来看看吧！'
//     // shareViewTips = `<p style="color:#999;">每有1个好友成功购买，您可获赠<span style="color:#ff6a01;">${datas.genHappybean}</span>乐豆！</p>`
//     shareViewTips = `每有1个好友成功购买，您可获赠${datas.genHappybean}乐豆！`
//     shareViewTitle = `获赠${datas.genHappybean}乐豆`
//   }
//   let linkData = {
//     title: datas.activityType == 4 ?  `${shareurname ?'【' + shareurname + '】' : ''}邀您给我新购买的宝贝点赞，可最多获赠${datas.likeMaxHappybean}乐豆` : datas.goodsInfoName, // 分享标题
//     desc: desc || datas.goodsSubtitle || ' ', // 分享描述
//     imgUrl: datas.goodsInfoImgId ? datas.goodsInfoImgId.trim() : '', // 商品图片地址
//     links: link, // 分享链接
//     type: 'link', // 分享类型,music、video或link，不填默认为link
//     meg: meg, // 短信分享文案
//     activityType: datas.activityType,
//     goodsName: datas.goodsInfoName,
//     shareViewTips: shareViewTips,
//     shareViewTitle: shareViewTitle,
//     isGoods: datas.isGoods, // 是否需要显示分享引导页 1|不需要(微信分享)
//     noReset: datas.noReset // 1|分享成功后不再做jdk签名动作(微信分享)
//   }
//   // 处理图片
//   if (linkData.imgUrl.indexOf('@!') > -1) {
//     linkData.imgUrl = linkData.imgUrl.split('@!')[0]
//   }
//   console.log(linkData)
//   if (_this.$client.GLSH_APP) {
//     getAppShare({ _this: _this, data: linkData }, callback, beforeglscallback, true)
//   } else if (_this.$client.WEIXIN) {
//     if (datas.activityType == 5) {
//       linkData.links += '_fromWxShare' //用于详情页左上角返回按钮判断
//     }
//     _this.$vux.loading.show()
//     getShare({ _this: _this, arr: linkData, goodsData: false }, function (status, res) {
//       if (status === 'success') {
//         // store.dispatch('SET_WEIXIN_SHARE_VIEW', false)
//         wxCallback && wxCallback()
//       } else {
//         _this.$vux.toast.show({
//           text: res,
//           type: 'text',
//           width: '7em'
//         })
//       }
//     })
//   } else {
//     if (datas.activityType == 4) {
//       _this.$vux.toast.text('请下载给乐生活APP才能参与晒单点赞哦')
//     } else {
//       _this.$vux.toast.text('请下载给乐生活APP才能参与继续分享哦')
//     }
//   }
// }

// /*app分享自定义*/
// // export const getAppShare = function ({ _this, data, applink }, callback, beforeglscallback, needShareType) { // needShareType: 分享链接上是否需要拼接上shareType, 如needShareType为true,需保证原来的链接已有搜索参数
// //   /**
// //   * @method showShareView
// //   * @param {activityType} 1|分享礼品, 2|击鼓传花,3|商品详情,4|晒单,5|邀约
// //   * @param {giftNum} 送礼数量,有多少传多少,不涉及数量的统一传-1
// //   * @param {shareViewTips} 分享面板上需显示的提示 (需换行处用 /n 分割)
// //   * @param {shareViewTitle} 分享面板上需显示的标题
// //   */
// //   _this.$cordova('showShareView', [data.activityType || 1, data.giftNum || -1, data.shareViewTips || '', data.shareViewTitle || '']).then(async (dataView) => {
// //     if (dataView.status === 1) {
// //       let shareType = dataView.data && dataView.data.type // 分享渠道  1|微信 2|微信朋友圈  3|qq  4|短信 5|新浪微博 6|陌陌  7|复制链接  8|乐友
// //       if (needShareType && shareType) data.links += '_st' + shareType
// //       let lxUrl = ''
// //       let encStr = ''
// //       if (data.activityType === 2) { // 砍价加密
// //         let barPar = getBargainEncParams(data.links, shareType)
// //         let res = await getBargainSign(barPar)
// //         encStr = res.data ? '_enc' + res.data : ''
// //         data.links += encStr
// //       }
// //       if (shareType == 8) { // 乐友分享方式
// //         if (data.activityType != 1) {
// //           let urlhead = 'url=' + saBs.$locationLinkWX
// //           let lxArr = data.links.split(urlhead)
// //           lxUrl = lxArr && lxArr[1]
// //           lxUrl = 'index.html#' + lxUrl
// //           data.imgUrl = data.imgUrl.trim() + '!thumbnail-rule-400'
// //         } else {
// //           lxUrl = applink ? applink : ''
// //         }
// //       }
// //       createDx({ url: data.links }).then((res) => {
// //         if (res && res.data) {
// //           // data.links = 'https://t.365gl.com/' + res.data
// //           data.links = 'http://t.geilepay.cn/' + res.data
// //           let reg = /{([^}]+)}/
// //           if (reg.test(data.meg)) {
// //             data.meg = applyTpl(data.meg, data)
// //           } else {
// //             data.meg = 'Hi，我在给乐生活送了一份礼物给您；' + data.links + ' 赶快来领取吧！'
// //           }

// //           beforeglscallback && beforeglscallback(data, shareType, encStr)
// //           // 当分享类型为乐友时，第二个参数改为商品名称，其他分享方式不变(20190808把该判断去掉了)
// //           _this.$cordova('glShare', [data.title, data.desc, data.imgUrl, (shareType == 8 && lxUrl ? lxUrl : data.links), data.type, data.meg, dataView.data.type, data.wishes]).then((e) => {
// //             callback && callback(e, shareType, encStr) // 分享成功后的回调，只有短信分享才会执行，其他分享暂时没有做回调
// //           })
// //         }
// //       })
// //     } else {
// //       _this.$vux.toast.text(res.message)
// //     }
// //   })
// // }
// /* 微信分享自定义 */
// // export const getShare = function ({ _this, arr, goodsData }, callback) {
// //   _this.$wechatInit(
// //     {
// //       share: {
// //         title: arr.title,
// //         desc: arr.desc,
// //         link: arr.links,
// //         imgUrl: arr.imgUrl,
// //         type: arr.type, // 分享类型,music、video或link，不填默认为link
// //         dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
// //         qqShareLinks: arr.qqShareLinks, // 用作砍价链接qq分享
// //         activityType: arr.activityType, // 用作砍价链接qq分享
// //         isGoods: arr.isGoods,
// //         noReset: arr.noReset,
// //         success: function () {
// //           if (!arr.noReset) {
// //             _this.$wechatInit('')
// //           }
// //           // 用户确认分享后执行的回调函数
// //           // if(_this.type){
// //           if (goodsData) {
// //             callback && callback('goodsuccess', '分享成功')
// //             // _this.$router.push({name: 'giftMall-resultsGiving', query: goodsData})
// //           } else {
// //             callback && callback('success', '分享成功')
// //           }
// //         },
// //         cancel: function () {
// //           if (!arr.noReset) {
// //             _this.$wechatInit('')
// //           }
// //           // 用户取消分享后执行的回调函数
// //           callback && callback('cancel', '您取消了分享')
// //         },
// //         callback: function (res) {
// //           if (!arr.noReset) {
// //             _this.$wechatInit('')
// //           }
// //           callback && callback('callback', '您取消了分享')
// //         }
// //       }
// //     },
// //     _this
// //   )
//   /*压缩成短连接*/
//   // createDx({url:arr.links}).then(res=>{
//   //   if(res&&res.data){
//   //     arr.links=res.data
//   //     _this.$wechatInit(
//   //       {
//   //         share: {
//   //           title: arr.title,
//   //           desc: arr.desc,
//   //           link: 'https://t.365gl.com/' + arr.links,
//   //           imgUrl: arr.imgUrl,
//   //           type: arr.type, // 分享类型,music、video或link，不填默认为link
//   //           dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
//   //           success: function() {
//   //             _this.$wechatInit('')
//   //             // 用户确认分享后执行的回调函数
//   //             // if(_this.type){
//   //             if (goodsData) {
//   //               callback && callback('goodsuccess', '分享成功')
//   //               // _this.$router.push({name: 'giftMall-resultsGiving', query: goodsData})
//   //             } else {
//   //               callback && callback('success', '分享成功')
//   //             }
//   //           },
//   //           cancel: function() {
//   //             _this.$wechatInit('')
//   //             // 用户取消分享后执行的回调函数
//   //             callback && callback('cancel', '您取消了分享')
//   //           },
//   //           callback: function(res) {
//   //             _this.$wechatInit('')
//   //             callback && callback('callback', '您取消了分享')
//   //           }
//   //         }
//   //       },
//   //       '',
//   //       _this.$route.fullPath
//   //     )
//   //   }
//   // })
// // }

// export const handleRedirect = HandleRedirect
// //fn 登陆防止重复点击要用
// export const loginSuccess = function (res, mobile, _this, flag, fn) {
//   setLocalStorage('userinfo', res.data)
//   setLocalStorage('username', mobile)
//   setLocalStorage('loginStatus', 1)
//   console.log(getLocalStorage('loginStatus'))
//   delLocalStorage('loginOpen')
//   setCache('LoggedOn', true)
//   setCache('Token', res.data)
//   setCache('lastUser', mobile)

// //   if (_this.$client.GLSH_APP) {
// //     info().then((ress) => {
// //       if (ress.result === ok) {
// //         setCache('information', ress.data)
// //         _this.$cordova('login', [res.data.userId || '', res.data.token]).then((data) => {

// //           if (data.status == 1) {
// //             _this.$cordova('closePage', [999])
// //           } else {
// //             fn && fn(data);
// //             clearLoginStatus()
// //             _this.$vux.toast.text('登陆失败')
// //           }
// //         })
// //       } else {
// //         fn && fn(data);
// //       }
// //     })
// //   } else {
// //     info().then((ress) => {
// //       fn && fn(ress);
// //       if (ress.result === ok) {
// //         setCache('information', ress.data)

// //         // 处理跳转
// //         HandleRedirect(_this)
// //       }
// //     })
// //   }
// // }

// export const logoutSuccess = function (_this) {
//   delLocalStorage('userinfo')
//   delLocalStorage('username')
//   delLocalStorage('loginStatus')

//   clearCache('LoggedOn')
//   clearCache('Token')
//   clearCache('information')

//   if (_this.$client.GLSH_APP) {
//     _this.$cordova('loginout', [])
//     // _this.$cordova('closePage', [])
//   } else {
//     _this.$router.replace({ name: 'login' })
//   }
// }

// export const checkScan = function (result, _this) {
//   if (!result) {
//     // 原生只有type为2的返回值
//     let href = 'index1.html?from=glshapp#/tab/payment' + '?v=' + saBs.$version
//     if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev') {
//       // web
//       href = location.origin + '/index1.html#/tab/payment' + '?v=' + saBs.$version
//     }
//     self.location.href = href
//     // $state.go("tab.payment");
//     // } else if (data.data.type == 2) {
//   } else {
//     // 打赏员工地址
//     var url = result;
//     function GetUrlParam(paraName) {
//       var arrObj = url.split("?");

//       if (arrObj.length > 1) {
//         var arrPara = arrObj[1].split("&");
//         var arr;

//         for (var i = 0; i < arrPara.length; i++) {
//           arr = arrPara[i].split("=");

//           if (arr != null && arr[0] == paraName) {
//             return arr[1];
//           }
//         }
//         return "";
//       }
//       else {
//         return "";
//       }
//     }
//     var terminal = GetUrlParam('terminal')
//     var merchantNo = GetUrlParam('merchantNo')
//     setCache('scanDate', url)
//     // 不是quick的地址返回首页
//     // var reg = url.match(/\.365gl\.com\/quick/);
//     // if (reg == null) {
//     //   _this.$router.push({'name': 'home'})
//     //   return
//     // }
//     // 带qrcode的台账码扫描
//     var barCodeReg = /\.365gl\.com.+qrcode=/.test(url),
//       barCode = ''
//     if (barCodeReg) {
//       url.split('&').forEach(function (v) {
//         var reg = /qrcode=(.+)/.exec(v)
//         if (reg && reg[1]) {
//           barCode = reg[1]
//         }
//       })

//       if (barCode || terminal) {
//         let href = ''
//         if (_this.$client.GLSH_APP) {
//           href = 'index1.html#/tab/my_sweep/' + barCode + '////0/?v=' + saBs.$version + '&type=&terminal=' + barCode + '&fromScan=1'
//         } else {
//           href = 'index1.html#/my_sweep/' + barCode + '///0/?v=' + saBs.$version + '&type=&terminal=' + barCode + '&fromScan=1'
//         }
//         if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev') {
//           // web
//           if (_this.$client.GLSH_APP) {
//             href = location.origin + '/index1.html#/tab/my_sweep/' + barCode + '////0/?v=' + saBs.$version + '&type=&terminal=' + barCode + '&fromScan=1'

//           } else {
//             href = location.origin + '/index1.html#/my_sweep/' + barCode + '///0/?v=' + saBs.$version + '&type=&terminal=' + barCode + '&fromScan=1'
//           }

//         }

//         if (_this.$client.GLSH_APP) {
//           _this.$cordova('newOpen', [href])
//           return
//         } else {
//         self.location.href = href
//         }

//       } else {
//         _this.$router.push({ name: 'newHome' })
//       }
//       return
//     }

//     var sRegisterReg = /\.365gl\.com.+register\/c/.test(url)
//     if (sRegisterReg) {
//       // 如果是C端APP扫S端的注册二维码
//       _this.$vux.toast.show({
//         text: '您已是给乐用户，无需重复注册'
//       })
//       _this.$router.push({ name: 'home' })
//       // $state.go('tab.index_hasRegister', {
//       //   text: '您已是给乐用户，无需重复注册。'
//       // })
//       return
//     }
//     // 兼容微信和app取值
//     var reg_group = url.match(/\/groupPay/g)
//     var groupReg = url.split('?')
//     var regs = groupReg[groupReg.length - 1].split('&')
//     if (reg_group != null) {
//       console.log('reg_group', reg_group)
//       if (url.indexOf('type') > -1) {
//         var newgroupParam = {
//           groupId: '' // 群id
//         }
//         regs.forEach(function (v) {
//           var d = v.split('=')
//           newgroupParam[d[0]] = d[1]
//         })
//         // $state.go('tab.group_pay_active', {
//         //   type: newgroupParam.groupId,
//         //   hash: new Date().getTime()
//         // })
//         let href = 'index1.html?from=glshapp#/tab/group_pay_active/' + newgroupParam.groupId + '/' + new Date().getTime() + '?v=' + saBs.$version + '&fromScan=1'
//         // if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev') {
//         //   // web
//         //   href = location.origin + '/index1.html#/tab/group_pay_active/' + newgroupParam.groupId + '/' + new Date().getTime() + '?v=' + saBs.$version
//         // }
//         console.log('open', href)
//         if (_this.$client.GLSH_APP) {
//           _this.$cordova('newOpen', [href])
//           return
//         } else {
//           href = location.origin + '/index1.html#/tab/group_pay_active/' + newgroupParam.groupId + '/' + new Date().getTime() + '?v=' + saBs.$version
//         }
//         self.location.href = href
//         return
//       }

//       getRlAmountPro().then((_data) => {
//         // console.log(_data, 'getRlAmountPro')
//         console.log('getRlAmountPro')
//         var rlAmountPro = _data.data.countDownSec
//         var groupParam = {
//           groupId: '', // 群id
//           userId: '', // 建群人的ID
//           userName: '', // 发起人
//           totalAmount: '', // 总金额
//           rlAmount: '', // 认领金额
//           mainOrderNo: '', // 主订单号
//           merchantNo: '', // 商户号
//           glMerchantNo: '', // 给乐订单号
//           merchantName: '', // 商户简称
//           merchantImgUrl: '', // 商户头像
//           saleRate: '', // 返豆率
//           userType: '', // 0 -- 发起人，1==参与者
//           url: url, // 完整地址
//           countDownSec: rlAmountPro * 1000 || 60000 // 抽奖倒计时（毫秒）
//         }
//         regs.forEach(function (v) {
//           var d = v.split('=')
//           groupParam[d[0]] = d[1]
//         })
//         let _information = getCache('information') || {}
//         let _token = getCache('Token') || {}
//         qrCodeInGroup({
//           groupId: groupParam.groupId,
//           imgUrl: _information.photo || require('@/assets/img/df-u-img.png'),
//           userId: _token.userId,
//           userName: _information.realName || '',
//           apiVersion: 'V1.1.0'
//         }).then((data) => {
//           groupParam.userName = data.data.groupOwnerName
//           groupParam.totalAmount = data.data.totalAmount
//           groupParam.rlAmount = data.data.rlAmount
//           groupParam.mainOrderNo = data.data.mainOrderNo
//           groupParam.merchantNo = data.data.merchantNo
//           groupParam.glMerchantNo = data.data.glMerchantNo
//           groupParam.merchantName = data.data.merchantName
//           groupParam.merchantImgUrl = data.data.merchantImgUrl
//           groupParam.userType = 1
//           setCache(groupParam.groupId, groupParam)
//           // alert(groupParam.groupId)
//           let href = 'index1.html?v=' + saBs.$timeStr + '&from=glshapp#/tab/group_pay_start/' + groupParam.groupId + '?v=' + saBs.$version + '&fromScan=1'
//           if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev') {
//             // 通过微信公众号的扫一扫，扫乐拼单二维码跳转
//             href = result
//             // href = url
//           }
//           console.log('getRlAmountProhref', href)

//           if (_this.$client.GLSH_APP) {
//             console.log('openPage', href)
//             _this.$cordova('newOpen', [href])
//             return
//           } else {
//             self.location.href = href
//           }
//           // $state.go('tab.group_pay_start', {
//           //   groupId: groupParam.groupId
//           // })
//         })
//       })
//       return
//     }

//     var param = {
//       merchantNo: '',
//       userId: '',
//       cash: '',
//       fromPage: '',
//       index: '',
//       merchartTitle: '',
//       terminal: ''
//     }
//     regs.forEach(function (v) {
//       var d = v.split('=')
//       param[d[0]] = d[1]
//     })
//     //  $return.setCache('payScene', '2')
//     //   $state.go('tab.my_sweep', param);
//     // 旧的台卡扫描 #/wx_entry?type=1&merchantNo=1707671000128
//     if (param.merchantNo) {
//       setCache('payScene', '2')
//       let href = 'index1.html#/tab/my_sweep/' + param.merchantNo + '/' + param.userId + '/' + param.cash + '/' + param.fromPage + '/' + param.index + '/' + param.merchartTitle + '?v=' + saBs.$version + '&type=' + param.type + '&terminal=' + param.terminal + '&fromScan=1'
//       if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev') {
//         // web
//         // href = location.origin + '/index1.html#/tab/my_sweep/' + param.merchantNo + '/' + param.operatorId + '/' + param.cash + '?v=' + saBs.$version + '&type=' + param.type
//         href = url
//       }
//       if (_this.$client.GLSH_APP) {
//         console.log('openPage', href)
//         _this.$cordova('newOpen', [href])
//         return
//       } else {
//         self.location.href = href
//       }
//       // $state.go('tab.my_sweep', param);
//     } else {
//       // 如果是扫的乱七八糟的二维码
//       _this.$vux.toast.show({
//         text: '请扫【给乐商家】收款码',
//         position: 'bottom',
//         width: '10em'
//       })
//       // _this.$router.push({ name: 'home' })
//       // $state.go('tab.index_hasRegister', {
//       //   text: '请扫【给乐商家】收款码'
//       // })
//     }
//   }
// }

// export const applyTpl = function (tpl, value) {
//   var str = "", values = Array.isArray(value) ? value : [value], val;
//   values.forEach(function (el) {
//     str += tpl.replace(/{([^}]+)}/g, function ($0, $1) {
//       if ($1.indexOf(".") > -1) {
//         val = returnDeepVal($1, value)
//       } else {
//         val = el[$1] ? el[$1] : ""
//       }
//       return val
//     });
//   });
//   return str
// }
// /**
//  * 跳转其他工程目录页面方法
//  * _this -> vue实例
//  * rt -> rout路由地址
//  * paramArr -> 参数数组
//  */
// export const jumpOtherPage = function (_this, rt, paramArr = [], query) {
//   console.log(paramArr)
//   let paramStr
//   let queryStr
//   if (paramArr.length > 0) {
//     paramStr = paramArr.join('/')
//   } else {
//     paramStr = ''
//   }
//   if (query) {
//     let arr = []
//     for (let k in query) {
//       arr.push(k + '=' + query[k])
//     }
//     queryStr = arr.join('&')
//     queryStr = queryStr ? '?' + queryStr : ''
//   } else {
//     queryStr = ''
//   }
//   sessionStorage.setItem("home_goto_tab_store", "1")
//   // 判断如果在app里面,需要新开一个webView
//   if (_this.$client.GLSH_APP) {
//     let href = `index1.html?w=${saBs.$timeStr}&from=glshapp${rt}${paramStr}${queryStr}`
//     _this.$cordova('newOpen', [href])
//   } else {
//     let href = location.origin + `/index1.html?w=${saBs.$timeStr}${rt}${paramStr}${queryStr}`
//     location.href = href
//   }
// }

// /**
//  * 检验登陆跳转
//  * rt -> rout路由地址
//  * paramArr -> 参数数组
//  */
// export const checkLoginJump = function (_this, router, ) {
//   if (_this.$client.GLSH_APP) {
//     if (getLocalStorage('userinfo') && getLocalStorage('userinfo').token) {
//       _this.$router.push(router)
//     } else {
//       let href = "index.html#/login?from=glshapp"
//       _this.$cordova('newOpen', [href])
//     }
//   } else {
//     _this.$router.push(router)
//   }
// }

// /**
//  * 获取query，特殊处理，去掉#
//  */
// export const getUrlParams = function (paraName) {
//   var url = document.location.hash;

//   if (url.indexOf('#') !== -1) {
//     url = url.replace('#', '')
//   }
//   var arrPara = url.split("&");
//   var arr;

//   for (var i = 0; i < arrPara.length; i++) {
//     arr = arrPara[i].split("=");

//     if (arr != null && arr[0] == paraName) {
//       return arr[1];
//     }
//   }
//   return "";

// }


// export const cleanArray = function (actual) {
//   const newArray = []
//   for (let i = 0; i < actual.length; i++) {
//     if (actual[i]) {
//       newArray.push(actual[i])
//     }
//   }
//   return newArray
// }

// export const setParam = function (json) {
//   if (!json) return ''
//   return cleanArray(Object.keys(json).map(key => {
//     if (json[key] === undefined) return ''
//     return encodeURIComponent(key) + '=' +
//       encodeURIComponent(json[key])
//   })).join('&')
// }

// /**
//  * 获取小S userid
//  */
// export const getUri = function (query) {
//   let userid = query.userid || ''
//   // 有多个搜索参数时wx.config之后会只剩一个，所以userid以下横杠 _urixxx 的方式拼接 小S用户关系关联
//   if (!userid && query.url && query.url.indexOf('uri') > -1) {
//     let arr = query.url.split('uri')
//     if (arr && arr[1]) {
//       userid = arr && arr[1] ? arr[1] : ''
//       userid = userid.indexOf('_') > -1 ? userid.split('_')[0] : userid
//       userid = userid
//     }
//   } else if (!userid && query.qry && query.qry.indexOf('uri') > -1) {
//     let qry = JSON.parse(query.qry)
//     let r = qry.query && qry.query.r ? qry.query.r : ''
//     let arr = r.split('uri')
//     if (arr && arr[1]) {
//       userid = arr && arr[1] ? arr[1] : ''
//       userid = userid.indexOf('_') > -1 ? userid.split('_')[0] : userid
//       userid = userid
//     }
//   }
//   return userid
// }

// /**
//  * 清除登陆状态
//  */
// export const clearLoginStatus = function (type) {
//   delLocalStorage('userinfo')
//   clearCache('LoggedOn')
//   clearCache('Token')
//   clearCache('information')
//   delLocalStorage('wxToken')
//   delLocalStorage('glToken')
//   delLocalStorage('newGiftByCurrentTime') // 清除新人礼/我的砍价缓存数据
//   return
// }

// /**
//  * 
//  * 解决软键盘挡住输入框问题
//  */
// export const scrollIntoView = function (type) {
//   if (
//     document.activeElement.tagName === 'INPUT' ||
//     document.activeElement.tagName === 'TEXTAREA'
//   ) {
//     window.setTimeout(function () {
//       if ('scrollIntoView' in document.activeElement) {
//         document.activeElement.scrollIntoView();
//       } else {
//         document.activeElement.scrollIntoViewIfNeeded();
//       }
//     }, 0);
//   }
// }

// /**
//  * 
//  * 登陆跳转
//  */
// export const mainPageCheckLogin = function (_this) {
//   if (getLocalStorage('userinfo') && getLocalStorage('userinfo').token) {
//     return
//   } else {
//     if (_this.$client.WEIXIN) {
//       window.location.href = saBs.$locationLinkWX + '/weixin/auth?url=userCenter'
//     } else {
//       _this.$router.push({
//         name: 'login',
//         query: {
//           url: 'userCenter'
//         }
//       })
//     }
//   }
// }

// /**
//  * 
//  * 微信授权登陆跳转相关路由对象
//  */
// export const _routeObject = {
//   'giftMall-detail-goodsInfoId': '/giftMall/detail/:goodsInfoId', // 商品详情
//   'exMall-detail-goodsInfoId': '/exMall/detail/:goodsInfoId', // 礼品详情
//   'userCenter-order': '/userCenter/order', // 订单列表
//   'userCenter-trade-orderDetails': '/userCenter/trade/orderDetails', // 订单详情
//   'giftMall-bargain-goodsInfoId': '/giftMall/bargain/:goodsInfoId' // 砍价详情
// }

// /**
//  * 
//  * 微信授权登陆跳转路径拼接
//  */
// export const pathSplicing = function (obj) {
//   let queryArr = []
//   let url = _routeObject[obj.name]
//   let idx = url.indexOf(':')
//   if (idx > -1) { // params替换
//     url = url.replace(url.slice(idx), obj.params[url.slice(idx + 1)])
//   }

//   // 为了解决点击公众号推送消息进入详情页，点击左上角返没反应的问题
//   // if (obj.name == 'giftMall-detail-goodsInfoId') {
//   //   if (obj.query) {
//   //     obj.query.fromWxShare = 1
//   //   } else {
//   //     obj.query = {}
//   //     obj.query.fromWxShare = 1
//   //   }
//   // }

//   for (let k in obj.query) { // query拼接
//     queryArr.push(k + '=' + obj.query[k])
//   }
//   url += '?' + queryArr.join('&')
//   return saBs.$locationLinkWX + url
// }


// /**
//  * 
//  * 微信授权登陆跳转
//  */
// export const wxjump = function (query, _this) {
//   if (!query.url) {
//     // 浏览器打开--没有配置跳转地址
//     if (_this.$client.WEIXIN) {
//       self.location.href = saBs.$locationLinkWX + '/newHome'
//     } else {
//       _this.$router.push({ name: 'newHome' })
//     }
//   } else if (/^-?[1-9]\d*$/.test(query.url)) {
//     _this.$router.go(parseInt(query.url, 10))
//   } else if (query.url.indexOf('http') === 0) {
//     // 浏览器打开--有配置http地址
//     if (query.url.indexOf(saBs.$locationLinkWX) >= 0) {
//       self.location.href = query.url
//     } else {
//       console.log('非本站域名跳转到首页')
//       self.location.href = saBs.$locationLinkWX
//     }
//   } else if (query.url.indexOf('~') > -1) {
//     // 浏览器打开--有配置经过enWxJumpLink和qs编码的router对象
//     let routeObj = qs.parse(deWxJumpLink(query.url))
//     let url = pathSplicing(routeObj)
//     self.location.href = url
//     // _this.$router.push(routeObj)
//   } else if (query.url.indexOf('name=') > -1 || query.url.indexOf('name%3D') > -1) {
//     // 浏览器打开--有配置经过enWxJumpLink和qs编码的router对象
//     let routeObj = qs.parse(query.url)
//     let url = pathSplicing(routeObj)
//     self.location.href = url
//     // _this.$router.push(routeObj)
//   } else {
//     // 浏览器打开--有配置路由名称
//     if (_this.$client.WEIXIN) {
//       let url = '/' + query.url.replace(/-/g, '/')
//       window.location.href = url + (query.r && setParam(query.r) ? ('?' + setParam(query.r)) : '')
//     } else {
//       _this.$router.push({
//         name: query.url,
//         query: {
//           r: query.r
//         }
//       })
//     }
//   }
// }

// /**
//  * 
//  * 修改微信title
//  */
// export const wxSetTitle = function (title) {
//   document.title = title;
//   var mobile = navigator.userAgent.toLowerCase();
//   if (/iphone|ipad|ipod/.test(mobile)) {
//     var iframe = document.createElement('iframe');
//     iframe.style.visibility = 'hidden';
//     var iframeCallback = function () {
//       setTimeout(function () {
//         iframe.removeEventListener('load', iframeCallback);
//         document.body.removeChild(iframe);
//       }, 0);
//     };
//     iframe.addEventListener('load', iframeCallback);
//     document.body.appendChild(iframe);
//   }
// }

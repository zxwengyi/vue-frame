import Vue from 'vue'
import Router from 'vue-router'
import { getLocalStorage, setLocalStorage } from 'sa-common'

const Home = (resolve) => require(['@/pages/index'], resolve)
const pay = (resolve) => require(['@/pages/pay'], resolve)
const systemPay = (resolve) => require(['@/pages/systemPay'], resolve)
const auth = (resolve) => require(['@/pages/auth'], resolve)

Vue.use(Router)

const router = new Router({
  mode: process.env.ROUTER_MODE,
  base: '/quickpay/',
  scrollBehavior(to, from, savedPosition) {
    
  },
  routes: [
    {
      path: '/',
      name: 'home',
      // redirect: 'newHome',
      components: {
        default: Home
      },
      // alias: 'exMall',
      // component: Home,
      meta: {
        title: '商家扫码支付',
        keywords: '给乐，给乐科技，给乐篇，给乐礼品篇，给乐礼品篇官网，礼品网，礼品网站，网上礼品',
        description: '给乐礼品篇，海量精美礼品，提供各种生日礼物、结婚礼物、节日礼物和商务礼品等，数千款个性礼品满足您的送礼需求,让礼物传递爱和温情。',
        requireAuth: false,
        keepAlive: false
      }
    },
    {
      path: '/auth',
      name: 'auth',
      components:  {
        default: auth
      },
      meta: {
        title: '',
        requireAuth: false
      }
    },
    {
      path: '/pay',
      name: 'pay',
      components: {
        default: pay
      },
      meta: {
        title: '', // 商家扫码买单支付
        requireAuth: false
      }
    },
    {
      path: '/systemPay',
      name: 'systemPay',
      components: {
        default: systemPay
      },
      meta: {
        title: '系统套餐支付',
        requireAuth: false
      }
    }
  ]
})
router.beforeEach((to, from, next) => {
  console.log('to', to)
  console.log('from', from)
  if (from.path === '/pay' && to.path === '/auth') {
    
  }else{
    next() 
  }
  
  // if (from.fullPath !== '/' || to.query.setpath) {
  //   if (to.query && to.query.from === 'glshapp' || to.query.setpath) {
  //     store.commit('SET_OPEN_PAGE', { path: to.path, query: to.query })
  //     console.log('store', store.state.appOpenPage)
  //   }
  // }
})

router.afterEach((to, from) => {
  document.title = to.meta.title ? to.meta.title : '\u200E'
})

export default router

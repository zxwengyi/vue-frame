const mNavigation = (resolve) => require(['@/components/m_navigation'], resolve) // 导航栏

// 活动
const CommonChooseCity = (resolve) => require(['@/pages/common/chooseCity'], resolve) // 选择城市
const CommonChooseCities = (resolve) => require(['@/pages/common/chooseCities'], resolve) // 选择城市

const router = [
  // 选择城市
  {
    path: '/common/chooseCity',
    name: 'common-chooseCity',
    components: {
      default: CommonChooseCity,
      navigation: ''
    },
    meta: {
      title: '选择城市',
      requireAuth: false,
      //keepAlive: true
    }
  },
  {
    path: '/chooseCity',
    name: 'chooseCity',
    components: {
      default: CommonChooseCities,
      navigation: ''
    },
    meta: {
      title: '选择城市',
      requireAuth: false,
      //keepAlive: true
    }
  }
]

export default router

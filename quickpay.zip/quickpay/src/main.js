// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
// import objectAssign from 'object-assign'
import Vue from 'vue'
import FastClick from 'fastclick'
// import { sync } from 'vuex-router-sync'
import router from './router'
import App from './App'
import Toast from '@/plugins/toast'

// import Lazysizes from 'lazysizes'
import { saBs } from '@/utils/base'
import md5 from 'js-md5';
import { setLocalStorage, getLocalStorage, delLocalStorage, setSessionStorage, getSessionStorage, delSessionStorage, formatTime, getUrlParam } from 'sa-common'
// import { clearTimeout } from 'timers'
// import { loginKefu, queryCustomerOnline } from '@/api/login'
// import 'swiper/dist/css/swiper.css'
import '@/assets/fonts/icomoon.css'
// import { debug } from 'util'
const VueUploadComponent = require('vue-upload-component')
import  VConsole  from  'vconsole'
if (process.env.NODE_ENV === 'production_test' || process.env.NODE_ENV === 'production_dev'|| process.env.NODE_ENV === 'production_dev' || process.env.NODE_ENV === 'production_uat') {
  const vConsole = new VConsole()
  Vue.use(vConsole)
}
// export default {
//   components: {
//     Toast
//   }
// }
Vue.prototype.$md5 = md5;
Vue.use(Toast)
// Vue.use(VueAwesomeSwiper)
require('es6-promise').polyfill()

// Vue.component('mt-loadmore', Loadmore)
// Vue.use(InfiniteScroll)
// Vue.use(Lazyload);
// Vue.component('file-upload', VueUploadComponent)

// global VUX config
// Vue.use(ConfigPlugin, {
//   $layout: 'VIEW_BOX' // global config for VUX, since v2.5.12
// })

// ES6
// import vshare from 'vshare'

// Vue.use(vshare)


// plugins
// Vue.use(DevicePlugin)
// Vue.use(ToastPlugin)
// Vue.use(AlertPlugin)
// Vue.use(ConfirmPlugin)
// Vue.use(LoadingPlugin)
// Vue.use(WechatPlugin)
// Vue.use(AjaxPlugin)
// Vue.use(BusPlugin)
// Vue.use(DatetimePlugin)

// const wx = Vue.wechat
const http = Vue.http

if ('scrollRestoration' in history) {
  // 默认值为'auto'
  history.scrollRestoration = 'manual'
}

// 禁止浏览器默认滑屏切页
if (navigator.control && navigator.control.gesture) {
  navigator.control.gesture(false)
}

// userAgent client
const userAgent = navigator.appVersion
const userAgentL = userAgent.toLowerCase()
Vue.prototype.$client = Vue.client = {
  IE: userAgentL.indexOf('msie') > -1 && !userAgentL.indexOf('opera') > -1,
  GECKO: userAgentL.indexOf('gecko') > -1 && !userAgentL.indexOf('khtml') > -1, // 火狐内核
  WEBKIT: userAgentL.indexOf('applewebkit') > -1, // 苹果、谷歌内核
  OPERA: userAgentL.indexOf('opera') > -1 && userAgentL.indexOf('presto') > -1, // opera内核
  TRIDENT: userAgentL.indexOf('trident') > -1, // IE内核
  MOBILE: !!userAgent.match(/AppleWebKit.*Mobile.*/), // 是否为移动终端
  MOBILEDEVICE: !!userAgentL.match(/iphone|android|phone|mobile|wap|netfront|x11|java|opera mobi|opera mini|ucweb|windows ce|symbian|symbianos|series|webos|sony|blackberry|dopod|nokia|samsung|palmsource|xda|pieplus|meizu|midp|cldc|motorola|foma|docomo|up.browser|up.link|blazer|helio|hosin|huawei|novarra|coolpad|webos|techfaith|palmsource|alcatel|amoi|ktouch|nexian|ericsson|philips|sagem|wellcom|bunjalloo|maui|smartphone|iemobile|spice|bird|zte-|longcos|pantech|gionee|portalmmm|jig browser|hiptop|benq|haier|^lct|320x320|240x320|176x220/i), // 是否为移动终端
  IOS: !!userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
  ANDROID: userAgent.indexOf('Android') > -1 || userAgent.indexOf('Adr') > -1, // android终端或者uc浏览器
  IPHONE: userAgent.indexOf('iPhone') > -1, // 是否为iPhone或者QQHD浏览器
  IPAD: userAgent.indexOf('iPad') > -1, // 是否iPad
  // WEBAPP: !userAgent.indexOf('Safari') > -1, //是否web应该程序，没有头部与底部
  QQBROWSER: userAgent.indexOf('QQBrowser') > -1, // 是否QQ浏览器
  WEIXIN: userAgent.indexOf('MicroMessenger') > -1, // 是否微信
  // QQ: userAgent.match(/\sQQ/i) === ' qq', // 是否QQ
  QQ: userAgent.match(/QQ\/[0-9]/i) ? true : false, // 是否QQ
  GLSH_APP: userAgent.indexOf('GeiLe_SC_H5') > -1, // 给乐生活APP
  WEIBO: userAgent.match(/WeiBo/i) == "weibo", // 微博
  ALIPAY: userAgent.indexOf('AlipayClient') > -1, // 是否支付宝
  UnionPay: userAgent.indexOf('UnionPay') > -1 // 是否云闪付
}

if (!Vue.client.IOS || Vue.client.ALIPAY) {
  FastClick.attach(document.body)
}

let cId = Vue.client.WEIXIN ? 'glLive.app.weixin' : 'glLive.app.web'

Vue.prototype.bus = new Vue;
Vue.prototype.$sysInfo = Vue.sysInfo = {
  deviceInfo: {
    DeviceId: 'test',
    ClientId: cId,
    deviceName: 'test', // 设备名称
    deviceVersion: '12.0.0', // 设备系统版本
    deviceAppVersion: saBs.$appVersion, // app版本号
    ClientVer: saBs.$appVersion
  },
  statusBarHeight: 0,
  bottomSafeAreaHeight: 0
}
window.glapp = new Vue({
  router,
  render: (h) => h(App)
}).$mount('#app-box')


/**
 * 微信支付
 */
Vue.prototype._weixinPayFn = function (data) {
  var onBridgeReady = function () {
    WeixinJSBridge.invoke(
      'getBrandWCPayRequest', {
      "appId": data.appId,     //公众号名称，由商户传入
      "timeStamp": data.timeStamp,         //时间戳，自1970年以来的秒数
      "nonceStr": data.nonceStr, //随机串
      "package": data.package,
      "signType": data.signType,         //微信签名方式：
      "paySign": data.paySign //微信签名
    },
      function (res) {
        var i = 0;
        if (res.err_msg == "get_brand_wcpay_request:ok") {
          window.location.href = data.callback_url;
        }
      }
    );
  }
  if (typeof WeixinJSBridge == "undefined") {
    if (document.addEventListener) {
      document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
    } else if (document.attachEvent) {
      document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
      document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
    }
  } else {
    onBridgeReady();
  }
}

/**
 * 支付宝支付
 */
Vue.prototype._aliPayFn = function (data, errCallback) {
  var onBridgeReady = function () {
    AlipayJSBridge.call('tradePay', {
      "tradeNO": data.tradeNO
    },
      function (result) {
        // 9000|订单支付成功 8000|正在处理中 4000|订单支付失败 6001|用户中途取消 6002|网络连接出错
        if (result.resultCode == '9000') {
          location.href = data.callback_url;//支付成功后跳转处理
        } else if (result.resultCode != '8000') {
          errCallback && errCallback(result)
        }
      });
  }
  if (typeof WeixinJSBridge == "undefined") {
    if (document.addEventListener) {
      document.addEventListener('AlipayJSBridgeReady', onBridgeReady, false);
    } else if (document.attachEvent) {
      document.attachEvent('AlipayJSBridgeReady', onBridgeReady);
      document.attachEvent('onAlipayJSBridgeReady', onBridgeReady);
    }
  } else {
    onBridgeReady();
  }
}

// 减法精度计算
Vue.prototype._subtractionFn = function (arg1, arg2) {
  var r1, r2, m, n;
  try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
  try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
  m = Math.pow(10, Math.max(r1, r2));
  n = (r1 >= r2) ? r1 : r2;
  return ((arg1 * m - arg2 * m) / m).toFixed(n);
}

// 乘法精度计算
Vue.prototype._multiplicationFn = function (arg1, arg2) {
  var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
  try { m += s1.split(".")[1].length; } catch (e) { }
  try { m += s2.split(".")[1].length; } catch (e) { }
  return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
}

// 加法精度计算
Vue.prototype._additionFn = function (arg1, arg2) {
  var r1, r2, m;
  try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
  try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
  m = Math.pow(10, Math.max(r1, r2));
  return (arg1 * m + arg2 * m) / m;
}
Date.prototype.Format = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1,
    "d+": this.getDate(),
    "h+": this.getHours(),
    "m+": this.getMinutes(),
    "s+": this.getSeconds(),
    "q+": Math.floor((this.getMonth() + 3) / 3),
    "S": this.getMilliseconds()
  };
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  for (var k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return fmt;
}

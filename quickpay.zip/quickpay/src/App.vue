<template>
  <div id="app">
    <keep-alive>
      <router-view v-if="$route.meta.keepAlive" class="enterView" :key="key"></router-view>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive" class="enterView" :key="key"></router-view>

  </div>
</template>

<script>
import { getUrlParam, deWxJumpLink, setLocalStorage } from 'sa-common'
import { saBs } from '@/utils/base'
import { getIpAddress } from '@/api/user'

export default {
  name: 'app',
  components: {
  },
  computed: {
    key() {
      return this.$route.fullPath // .replace(/\//g, '_')
    }
  },
  created() {
    // 获取客户端ip
    getIpAddress().then(res => {
      if (res.result == '000000') {
        setLocalStorage('userip', res.data)
      }
    })
  },
  methods: {
  },
  mounted() {
  }
}
</script>

<style>
@import 'assets/css/common.css';
</style>

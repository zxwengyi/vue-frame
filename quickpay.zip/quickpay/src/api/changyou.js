/*
 * @Author: zhoulixia
 * @Date: 2020-02-19 19:24:04
 */
import axios from '@/utils/axios' // 引入加了拦截器的axios
import { saBs } from '@/utils/base'


// 查询用户是否绑定畅游会员
export const checkCyBind = (req) => {
  return axios.get(saBs.$api.checkCyBind, req).then((res) => {
    return Promise.resolve(res.data)
  })
}
// 修改畅游相关协议标志
export const updateCyFlag = (req) => {
  return axios.post(saBs.$api.updateCyFlag, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 移动积分及兑换比例查询
export const queryCmccPoints = (req) => {
  return axios.post(saBs.$api.queryCmccPoints, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 移动兑换下单接口
export const cmccSmsOrder = (req) => {
  return axios.post(saBs.$api.cmccSmsOrder, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 移动短信下发接口
export const sendCmccSms = (req) => {
  return axios.post(saBs.$api.sendCmccSms, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 移动兑分接口
export const addPoints = (req) => {
  return axios.post(saBs.$api.addPoints, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 移动兑分接口
export const cyUserRegister = (req) => {
  return axios.post(saBs.$api.cyUserRegister, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 通知后端绑定畅由会员成功
export const notifyCyUserBind = (req) => {
  return axios.post(saBs.$api.notifyCyUserBind, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 获取用户纯乐豆余额（用于畅由授权弹窗展示）
export const beanAmount = (req) => {
  return axios.get(saBs.$api.beanAmount, req).then((res) => {
    return Promise.resolve(res.data)
  })
}


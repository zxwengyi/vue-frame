/*
 * @Author: saqqdy
 * @Date: 2017-06-17 20:35:04
 * @Last Modified by: saqqdy
 * @Last Modified time: 2017-07-07 16:04:10
 */
import axios from '@/utils/axios' // 引入加了拦截器的axios
import { saBs } from '@/utils/base'

// // 我的喜欢 -- 喜欢的商家计算距离
// export const getOuterApiResource = (req) => {
//   return axios.post(`${saBs.$api.appQueryMerchantInfoLBS}`, req)
// }

// // 获取抽奖倒计时
// export const getRlAmountPro = (req) => {
//   return axios.get(`${saBs.$api.rlAmountPro}`)
// }

// // 获取群信息
// export const qrCodeInGroup = (req) => {
//   return axios.post(saBs.$api.qrCodeInGroup, req).then((res) => {
//     return Promise.resolve(res.data)
//   })
// }

// 获取授权登陆接口
export const getCodeurl = (req) => {
  return axios.post(saBs.$api.getCodeurl, req).then((res) => {
    return Promise.resolve(res.data)
  })
}
// 查询乐豆余额
export const getBalance = (req) => {
    return axios.get(saBs.$api.getBalance, {params: req}).then((res) => {
        return res.data
    })
  }

  // 查询乐拼单认领金额占比
export const rlAmountPro = (req) => {
    return axios.get(saBs.$api.rlAmountPro, req).then((res) => {
        return res.data
    })
  }

  // 查询乐拼单商品详情
export const merchant = (merchantNo,req) => {
    return axios.get(saBs.$api.merchant+"/"+merchantNo, req).then((res) => {
        return res.data
    })
  }
    // 查询乐拼单商品详情
export const merchantDetail = (req) => {
  return axios.get(saBs.$api.merchantDetail, {params:req}).then((res) => {
      return res.data
  })
}
  // 个人买单确认支付
export const commonPay = (req) => {
    return axios.post(saBs.$api.commonPay, req).then((res) => {
        return res.data
    })
  }
  // 微信静默授权
  export const wxauth = (req) => {
    let isalipay = navigator.appVersion.indexOf('AlipayClient') > -1
    let isMicroMessenger = navigator.appVersion.indexOf('MicroMessenger') > -1
    if (isalipay) { // 增加请求参数payType --20191111 zhoulixai
      req['payType'] = 'aliPay'
    } else if (isMicroMessenger) {
      req['payType'] = 'weixin'
    } else {
      req['payType'] = 'unionPay' // 云闪付
    }
    return axios.post(saBs.$api.wxauth, req).then((res) => {
        return res.data
    })
  }
  // 发起乐拼单
export const buildGroup = (req) => {
    return axios.post(saBs.$api.buildGroup, req).then((res) => {
        return res.data
    })
  }
//   微信个人买单确认支付
export const wxpub_prePay = (req) => {
    return axios.post(saBs.$api.wxpub_prePay, req).then((res) => {
        return res.data
    })
  }
  //   微信扫码个人买单确认支付
export const prePay = (req) => {
    return axios.post(saBs.$api.prePay, req).then((res) => {
        return res.data
    })
  }
//   是否启用乐豆
  export const enableHappyCoin = (req) => {
    return axios.post(saBs.$api.enableHappyCoin, req).then((res) => {
        return res.data
    })
  }
  //   微信扫码个人买单确认支付
  export const getCodeUrl4UserInfo = (req) => {
    return axios.post(saBs.$api.getCodeUrl4UserInfo, req).then((res) => {
        return res.data
    })
  }
// 通过微信code获取openid
export const weChatCredit = (req) => {
  return axios.post(`${saBs.$api.weChatCredit}`, req)
}
// 通过云闪付authcode获取userid
export const unionPayCredit = (req) => {
  return axios.post(`${saBs.$api.unionPayCredit}`, req)
}
// 查询商家配置的支付渠道（weixin OR alipay）
export const payType = (req) => {
  return axios.post(`${saBs.$api.payType}`, req).then((res) => {
      return res.data
  })
}
// 判断用户是否绑定手机
export const queryBind = (req) => {
  return axios.get(`${saBs.$api.queryBind}`, {params:req}).then((res) => {
    return res.data
  })
}
// 查询第三方订单详情(B端系统套餐购买)
export const queryOrderInfo = (req) => {
  return axios.post(`${saBs.$api.queryOrderInfo}`, req).then((res) => {
    return res.data
  })
}
// 获取验证支付密码Token
export const getCheckToken = () => {
  return axios.get(`${saBs.$api.getCheckToken}`).then((res) => {
    return res.data
  })
}
// 是否设置密码
export const isPayPassword = (req) => {
  return axios.get(saBs.$api.isPayPassword).then((res) => {
    return Promise.resolve(res.data)
  })
}
// 根据商户号查询储值卡id
export const findSingleCardGoodsByMerchantNo = (req) => {
  return axios.get(saBs.$api.findSingleCardGoodsByMerchantNo, {params:req}).then((res) => {
    return Promise.resolve(res.data)
  })
}
// 根据C扫B返回tokenId查询订单信息
export const queryPayOrderInfo = (req) => {
  return axios.post(saBs.$api.queryPayOrderInfo, req).then((res) => {
    return Promise.resolve(res.data)
  })
}

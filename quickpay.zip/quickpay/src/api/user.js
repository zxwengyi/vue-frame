/*
 * @Author: zhoulixia
 * @Date: 2020-02-18 19:02:04
 */
import axios from '@/utils/axios' // 引入加了拦截器的axios
import { saBs } from '@/utils/base'
// 校验验证码
export const wxpubApiverifySms = (req) => {
  let data = {
    businessType: 7,
    phoneNo: req.phoneNo,
    verifyCode: req.verifyCode,
    wxToken: req.wxToken
  }
  return axios.post(saBs.$api.wxpubApiverifySms, data).then((res) => {
    return Promise.resolve(res.data)
  })
}


// 引导注册
export const userregister = (req) => {
  let data = {
    active: '',
    activeId: '',
    // channel: 'wx', // 前端不用传，后台直接做判断
    merchantNo: '',
    mobilePhone: req.mobilePhone,
    source: '',
    userId: '',
    wxToken: req.wxToken
  }
  return axios.post(saBs.$api.userregister, data).then((res) => {
    return Promise.resolve(res.data)
  })
}

// 个人信息查询
export const info = (req) => {
  return axios.get(saBs.$api.info, { isLogin: true }).then((res) => {
    return Promise.resolve(res.data)
  })
}


// 发送验证码
export const wxpubApisendSms = (req) => {
  let data = {
    businessType: 7,
    phoneNo: req.phoneNo
  }
  return axios.post(saBs.$api.wxpubApisendSms, data).then((res) => {
    return Promise.resolve(res.data)
  })
}


// 发送验证码
export const sendSms = (req) => {
  const data = {
    businessType: req.businessType, // 0：注册1：修改手机号2：登录3：忘记登录密码 7 其他
    phoneNo: req.phoneNo
  }
  return axios.post(saBs.$api.sendSms, data).then((res) => {
    return Promise.resolve(res.data)
  })
}
// 获取用户ip地址
export const getIpAddress = (req) => {
  return axios.get(saBs.$api.getIpAddress, req).then((res) => {
    return Promise.resolve(res.data)
  })
}
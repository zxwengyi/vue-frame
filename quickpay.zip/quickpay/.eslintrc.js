module.exports = {
  root: true,
  parser: 'babel-eslint',
  parserOptions: {
    sourceType: 'module'
  },
  env: {
    browser: true,
    commonjs: true,
    es6: true
  },
  globals: {
    vue: true,
    wx: true
  },
  extends: 'standard',
  plugins: ['html', 'standard', 'promise', 'vue'],
  rules: {
    'arrow-parens': 1,
    'generator-star-spacing': 0,
    'no-debugger': process.env.NODE_ENV && process.env.NODE_ENV.indexOf('production') > -1 ? 2 : 0,
    'no-console': process.env.NODE_ENV && process.env.NODE_ENV.indexOf('production') > -1 ? 2 : 0, //禁止使用console
    'no-alert': process.env.NODE_ENV && process.env.NODE_ENV.indexOf('production') > -1 ? 2 : 0, //禁止使用alert confirm prompt

    'no-cond-assign': 2, //禁止在条件表达式中使用赋值语句
    'no-const-assign': 2, //禁止修改const声明的变量
    'no-constant-condition': 2, //禁止在条件中使用常量表达式 if(true) if(1)
    'no-dupe-keys': 2, //在创建对象字面量时不允许键重复 {a:1,a:1}
    'no-dupe-args': 2, //函数参数不能重复
    'no-duplicate-case': 2, //switch中的case标签不能重复
    'no-else-return': 2, //如果if语句里面有return,后面不能跟else语句
    'no-empty': 2, //块语句中的内容不能为空
    'no-empty-character-class': 2, //正则表达式中的[]内容不能为空
    'no-eq-null': 2, //禁止对null使用==或!=运算符
    'no-eval': 1, //禁止使用eval
    'no-ex-assign': 2, //禁止给catch语句中的异常参数赋值
    'no-extra-bind': 2, //禁止不必要的函数绑定
    'no-extra-boolean-cast': 2, //禁止不必要的bool转换
    'no-extra-parens': 2, //禁止非必要的括号
    'no-extra-semi': 2, //禁止多余的冒号
    'no-fallthrough': 1, //禁止switch穿透
    'no-func-assign': 2, //禁止重复的函数声明
    'no-invalid-regexp': 2, //禁止无效的正则表达式
    'no-invalid-this': 2, //禁止无效的this，只能用在构造器，类，对象字面量
    'no-irregular-whitespace': 2, //不能有不规则的空格
    'no-lonely-if': 2, //禁止else语句内只有if语句
    'no-loop-func': 1, //禁止在循环中使用函数（如果没有引用外部变量不形成闭包就可以）
    'no-mixed-spaces-and-tabs': [2, false], //禁止混用tab和空格
    'no-multi-spaces': 1, //不能用多余的空格
    'no-multiple-empty-lines': [
      1,
      {
        max: 1
      }
    ], //空行最多不能超过2行
    'no-redeclare': 2, //禁止重复声明变量
    'no-regex-spaces': 2, //禁止在正则表达式字面量中使用多个空格 /foo bar/
    'no-spaced-func': 2, //函数调用时 函数名与()之间不能有空格
    'no-trailing-spaces': 1, //一行结束后面不要有空格
    'no-undef-init': 2, //变量初始化时不能直接给它赋值为undefined
    'no-undefined': 2, //不能使用undefined
    'no-unreachable': 2, //不能有无法执行的代码
    'no-unused-expressions': 0, //禁止无用的表达式
    'no-unused-vars': [
      0,
      {
        // "vars": "all",
        // "args": "after-used"
        vars: 'local',
        args: 'none'
      }
    ], //不能有声明后未被使用的变量或参数
    'no-void': 2, //禁用void操作符
    'no-var': 0, //禁用var，用let和const代替

    'array-bracket-spacing': [2, 'never'], //是否允许非空数组里面有多余的空格
    camelcase: 0, //强制驼峰法命名
    'comma-dangle': [2, 'never'], //对象字面量项尾不能有逗号
    'comma-spacing': 0, //逗号前后的空格
    'comma-style': [2, 'last'], //逗号风格，换行时在行首还是行尾
    complexity: [0, 11], //循环复杂度
    curly: [2, 'all'], //必须使用 if(){} 中的{}
    'default-case': 2, //switch语句最后必须有default
    eqeqeq: 2, //必须使用全等
    'func-names': 0, //函数表达式必须有名字
    indent: [2, 2], //缩进风格
    // "init-declarations": 0, //声明时必须赋初值
    'key-spacing': [
      0,
      {
        beforeColon: false,
        afterColon: true
      }
    ], //对象字面量中冒号的前后空格
    'lines-around-comment': 0, //行前/行后备注
    'object-curly-spacing': [0, 'never'], //大括号内是否允许不必要的空格
    'prefer-const': 0, //首选const
    'prefer-spread': 0, //首选展开运算
    'prefer-reflect': 0, //首选Reflect的方法
    'id-match': 0, //命名检测
    // "require-yield": 0, //生成器函数必须有yield
    semi: [2, 'never'], //语句强制分号结尾
    'semi-spacing': [
      0,
      {
        before: false,
        after: true
      }
    ], //分号前后空格
    'space-before-blocks': [0, 'always'], //不以新行开始的块{前面要不要有空格
    'space-before-function-paren': [0, 'always'], //函数定义时括号前面要不要有空格
    'space-in-parens': [0, 'never'], //小括号里面要不要有空格
    'space-infix-ops': 0, //中缀操作符周围要不要有空格
    'space-unary-ops': [
      0,
      {
        words: true,
        nonwords: false
      }
    ], //一元运算符的前/后要不要加空格
    'spaced-comment': 1, //注释风格要不要有空格什么的
    strict: 2, //使用严格模式
    'valid-typeof': 2 //必须使用合法的typeof的值
  }
}

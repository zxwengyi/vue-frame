# Transfer App

A transfer application for demonstrating the usage of numeric keyboard.

All you need to do is fill in the amount and confirm your password.

## Run the development version

```shell
yarn dev
```

http://localhost:4040/vanilla.html

http://localhost:4040/react.html

http://localhost:4040/vue.html

http://localhost:4040/angular.html

## Run the publish version

```shell
yarn start
```

http://localhost:4141/vanilla.html

http://localhost:4141/react.html

http://localhost:4141/vue.html

http://localhost:4141/angular.html

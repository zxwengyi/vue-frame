module.exports = {
  ROUTER_MODE: '"history"',
  BUILD_TYPE: '"web"',
  NODE_ENV: '"production_uat"'
}

module.exports = {
  ROUTER_MODE: '"hash"',
  BUILD_TYPE: '"app"',
  NODE_ENV: '"production_app"'
}

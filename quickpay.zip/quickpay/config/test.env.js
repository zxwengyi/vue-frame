const merge = require('webpack-merge')
const devEnv = require('./dev.env')

module.exports = merge(devEnv, {
  // ROUTER_MODE: '"hash"',
  ROUTER_MODE: '"history"',
  BUILD_TYPE: '"web"',
  NODE_ENV: '"testing"'
})

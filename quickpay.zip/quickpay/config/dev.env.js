const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  // ROUTER_MODE: '"hash"',
  ROUTER_MODE: '"history"',
  BUILD_TYPE: '"app"',
  NODE_ENV: '"development"'
})
